// Behavioral Security Test Cases for The Folded Page Firestore Rules
// Verified invariants across unauthenticated, reader, and owner actors.

export const FIRESTORE_SECURITY_TEST_CASES = [
  {
    name: 'Unauthenticated user can read PUBLISHED article',
    actor: null,
    operation: 'get',
    path: '/articles/story-01',
    resourceData: { status: 'PUBLISHED' },
    expected: 'ALLOW',
  },
  {
    name: 'Unauthenticated user cannot read DRAFT article',
    actor: null,
    operation: 'get',
    path: '/articles/draft-01',
    resourceData: { status: 'DRAFT' },
    expected: 'DENY',
  },
  {
    name: 'Reader cannot escalate own role to EDITORIAL_OWNER on create',
    actor: { uid: 'reader-1', email: 'reader@example.com', email_verified: true },
    operation: 'create',
    path: '/users/reader-1',
    requestData: { uid: 'reader-1', role: 'EDITORIAL_OWNER', isPermanentOwner: true, status: 'ACTIVE' },
    expected: 'DENY',
  },
  {
    name: 'Reader cannot mutate role on profile update',
    actor: { uid: 'reader-1', email: 'reader@example.com', email_verified: true },
    operation: 'update',
    path: '/users/reader-1',
    requestData: { role: 'OWNER' },
    expected: 'DENY',
  },
  {
    name: 'Reader cannot read another user private PII or saved stories',
    actor: { uid: 'reader-1', email: 'reader@example.com', email_verified: true },
    operation: 'get',
    path: '/users/reader-2/private/info',
    expected: 'DENY',
  },
  {
    name: 'Verified owner email arjunjareda1355@gmail.com can manage articles and view subscribers',
    actor: { uid: 'owner-1', email: 'arjunjareda1355@gmail.com', email_verified: true },
    operation: 'list',
    path: '/subscribers',
    expected: 'ALLOW',
  },
  {
    name: 'Verified owner email arjunjareda2007@gmail.com can publish articles and read audit logs',
    actor: { uid: 'owner-2', email: 'arjunjareda2007@gmail.com', email_verified: true },
    operation: 'list',
    path: '/auditLogs',
    expected: 'ALLOW',
  },
  {
    name: 'Unverified owner email cannot assume admin access',
    actor: { uid: 'spoof-1', email: 'arjunjareda1355@gmail.com', email_verified: false },
    operation: 'list',
    path: '/apiKeys',
    expected: 'DENY',
  },
  {
    name: 'Even admin cannot update or delete immutable audit logs',
    actor: { uid: 'owner-1', email: 'arjunjareda1355@gmail.com', email_verified: true },
    operation: 'delete',
    path: '/auditLogs/log-1',
    expected: 'DENY',
  },
];
