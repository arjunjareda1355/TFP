# Security Specification — The Folded Page

## Phase 0: Core Invariants
1. **Default Deny**: Root catch-all `match /{document=**} { allow read, write: if false; }` is declared first.
2. **Verified Authentication**: Every authenticated privilege requires `request.auth != null && request.auth.token.email_verified == true`.
3. **Permanent Owner Authority**: Only verified emails `arjunjareda1355@gmail.com` and `arjunjareda2007@gmail.com` evaluate `isAdmin() == true`.
4. **Strict PII Isolation**:
   - `users/{userId}` stores only non-PII (`uid`, `displayName`, `photoURL`, `role`, `status`, `isPermanentOwner`, `bio`, `createdAt`, `updatedAt`, `lastLogin`).
   - `users/{userId}/private/{docId}` holds PII (`email`, `customPermissions`, `twoFactorEnabled`) and is readable/writable ONLY by `isOwner(userId)` or `isAdmin()`.
   - `subscribers/{subscriberId}` and `contacts/{contactId}` are NEVER readable/listable by non-admins; public users may only `create` with validated fields.
5. **Privilege Escalation Prevention**:
   - Non-admin user self-registration on `users/{userId}` MUST force `role == 'READER'`, `isPermanentOwner == false`, and `status == 'ACTIVE'`.
   - Non-admin user profile updates MUST NOT mutate `role`, `isPermanentOwner`, `status`, `uid`, or `createdAt`.
6. **Draft & Private Content Protection**:
   - `articles/{articleId}` is readable/listable by public ONLY when `resource.data.status == 'PUBLISHED'`. Unpublished `DRAFT`, `IN_REVIEW`, `SCHEDULED`, and `ARCHIVED` articles are strictly `isAdmin()` only.
7. **Governance & Audit Integrity**:
   - `auditLogs`, `trash`, `apiKeys`, and `invitations` are restricted to `isAdmin()`. `auditLogs` are immutable (`allow update, delete: if false;`).
8. **Zero `get()`/`exists()` in `allow list`**:
   - `isAdmin()` uses `request.auth.token.email` directly so `allow list` never performs document lookups.

## Dirty Dozen Attack Scenarios (Verified Blocked)
1. Unauthenticated read of `/users/{uid}/private/info` -> **DENY**
2. Reader A reading Reader B's `/users/{B}/saved/{id}` or `/users/{B}/private/info` -> **DENY**
3. Reader self-creating `/users/{uid}` with `role: 'EDITORIAL_OWNER'` or `isPermanentOwner: true` -> **DENY**
4. Reader updating `/users/{uid}` to elevate `role: 'OWNER'` -> **DENY**
5. Unauthenticated `list` or `get` on draft article (`status == 'DRAFT'`) -> **DENY**
6. Non-admin creating/modifying/deleting `/articles/{id}` or `/siteSettings/{id}` -> **DENY**
7. Unauthenticated or non-admin reading `/subscribers/{id}` or `/contacts/{id}` -> **DENY**
8. Non-admin updating or deleting `/auditLogs/{id}` -> **DENY**
9. Non-admin reading or creating `/apiKeys/{id}` -> **DENY**
10. Invalid document ID (e.g. `.`, `..`, `__foo__`, >128 chars) on single-doc create -> **DENY**
11. Unverified email account attempting `isAdmin()` or authenticated writes -> **DENY**
12. Payload spoofing `createdAt != request.time` on create or overwriting `createdAt` on update -> **DENY**
