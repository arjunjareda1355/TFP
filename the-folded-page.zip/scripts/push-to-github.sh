#!/usr/bin/env bash
# The Folded Page - GitHub Push Helper Script
# Uses an isolated temporary GIT_DIR in /tmp so /app/applet never retains
# conflicting .git lockfiles or read-only objects, respects .gitignore,
# supports GitHub Organization & SAML SSO repositories via PAT, and preserves
# remote branch history for protected branches without requiring force-push.
#
# Usage:
#   ./scripts/push-to-github.sh <github-repo-url> [personal-access-token] [branch]
#   GITHUB_TOKEN=ghp_xxx ./scripts/push-to-github.sh <github-repo-url>

set -euo pipefail

RAW_REPO_URL="${1:-}"
TOKEN="${2:-${GITHUB_TOKEN:-}}"
BRANCH="${3:-${GITHUB_BRANCH:-main}}"
REPO_DIR="$(pwd)"

if [ -z "$RAW_REPO_URL" ]; then
  echo "Usage: ./scripts/push-to-github.sh <REPO_URL> [GITHUB_TOKEN] [BRANCH]"
  exit 1
fi

# Strip trailing slashes from repo URL and ensure clean .git suffix for git transport
REPO_URL="${RAW_REPO_URL%/}"

TEMP_GIT_DIR="$(mktemp -d /tmp/tfp-git-XXXXXX)"
cleanup() {
  rm -rf "$TEMP_GIT_DIR"
}
trap cleanup EXIT

export GIT_TERMINAL_PROMPT=0

# Build ephemeral HTTP Basic auth header if PAT is supplied
GIT_AUTH_ARGS=(-c "safe.directory=$REPO_DIR" -c "credential.helper=")
if [ -n "$TOKEN" ]; then
  AUTH_B64="$(printf 'x-access-token:%s' "$TOKEN" | base64 | tr -d '\n')"
  GIT_AUTH_ARGS+=(-c "http.https://github.com/.extraheader=AUTHORIZATION: basic ${AUTH_B64}")
fi

run_git() {
  git "${GIT_AUTH_ARGS[@]}" --git-dir="$TEMP_GIT_DIR" --work-tree="$REPO_DIR" "$@"
}

echo "[1/4] Preparing isolated workspace snapshot on branch '${BRANCH}'..."
git init -q --bare "$TEMP_GIT_DIR"
run_git config user.name "Arjun Jareda"
run_git config user.email "arjunjareda1355@gmail.com"
run_git config core.bare false
run_git config core.worktree "$REPO_DIR"
run_git remote add origin "$REPO_URL"

echo "[2/4] Checking remote branch '${BRANCH}'..."
REMOTE_EXISTS=0
if run_git ls-remote --exit-code --heads origin "$BRANCH" >/dev/null 2>&1; then
  REMOTE_EXISTS=1
  run_git fetch --depth=1 origin "$BRANCH"
  run_git update-ref "refs/heads/${BRANCH}" FETCH_HEAD
  run_git symbolic-ref HEAD "refs/heads/${BRANCH}"
  # Sync temporary index to remote HEAD without altering any working tree files
  run_git read-tree "refs/heads/${BRANCH}"
else
  run_git symbolic-ref HEAD "refs/heads/${BRANCH}"
fi

echo "[3/4] Staging current workspace files..."
run_git add -A

if [ "$REMOTE_EXISTS" -eq 1 ]; then
  if run_git diff --cached --quiet; then
    echo "Remote branch '${BRANCH}' is already up to date with the workspace."
    exit 0
  fi
  run_git commit -m "Update The Folded Page application"
else
  run_git commit -m "Initial commit: The Folded Page"
fi

echo "[4/4] Pushing commit to GitHub (${REPO_URL} -> ${BRANCH})..."
if ! run_git push -u origin "$BRANCH"; then
  echo "Standard push rejected; retrying with --force-with-lease..."
  run_git push -u origin "$BRANCH" --force-with-lease
fi

echo "Successfully pushed changes to GitHub (${REPO_URL}) on branch '${BRANCH}'."
