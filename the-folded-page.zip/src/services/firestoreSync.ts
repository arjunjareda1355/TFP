import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  serverTimestamp,
  writeBatch,
  orderBy,
  limit,
  Timestamp,
} from 'firebase/firestore';
import type { User as FirebaseUser } from 'firebase/auth';
import {
  db,
  auth,
  OperationType,
  handleFirestoreError,
  isOwnerEmail,
  resolveRoleForEmail,
} from '../lib/firebase';
import type {
  Article,
  CategoryInfo,
  Author,
  EditorialSeries,
  MagazineIssue,
  HomepageLayoutConfig,
  MediaItem,
  User,
  UserRole,
  NewsletterSubscriber,
  ContactSubmission,
  SocialChannel,
  ActivityLog,
  TrashItem,
  ApiKey,
  NavigationItem,
  AboutPageConfig,
  WebItem,
} from '../types';

function truncate(val: unknown, maxLen: number): string {
  const s = typeof val === 'string' ? val : val == null ? '' : String(val);
  return s.length > maxLen ? s.slice(0, maxLen) : s;
}

function cleanForFirestore<T>(obj: T): T {
  if (obj === null || obj === undefined) return obj;
  if (Array.isArray(obj)) {
    return obj
      .filter((item) => item !== undefined)
      .map((item) => cleanForFirestore(item)) as unknown as T;
  }
  if (typeof obj === 'object' && !(obj instanceof Timestamp)) {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      if (v !== undefined) {
        out[k] = cleanForFirestore(v);
      }
    }
    return out as T;
  }
  return obj;
}

function toIsoString(val: unknown): string {
  if (!val) return new Date().toISOString();
  if (typeof val === 'string') return val;
  if (val instanceof Timestamp) return val.toDate().toISOString();
  if (typeof (val as { toDate?: () => Date }).toDate === 'function') {
    return (val as { toDate: () => Date }).toDate().toISOString();
  }
  return new Date().toISOString();
}

function sanitizeArticleForFirestore(article: Article): Record<string, unknown> {
  // Keep revisions lightweight (max 2 entries without nested data payloads) to stay well under Firestore 1MB doc cap
  const compactRevisions = Array.isArray(article.revisions)
    ? article.revisions.slice(0, 2).map((r) => ({
        id: truncate(r.id || `rev-${Date.now()}`, 80),
        savedAt: r.savedAt || new Date().toISOString(),
        authorName: truncate(r.authorName || 'Editorial Staff', 120),
        title: truncate(r.title || article.title, 300),
        blocksCount: r.blocksCount || 0,
        wordCount: r.wordCount || 0,
        note: truncate(r.note || 'Saved update', 200),
      }))
    : [];

  return cleanForFirestore({
    ...article,
    id: truncate(article.id, 128),
    slug: truncate(article.slug || article.id, 200),
    title: truncate(article.title || 'Untitled Dispatch', 300),
    subtitle: truncate(article.subtitle || '', 500),
    deck: truncate(article.deck || '', 1000),
    category: truncate(article.category || 'Essays', 100),
    status: article.status || 'PUBLISHED',
    heroImage: truncate(article.heroImage || '', 2048),
    revisions: compactRevisions,
    createdAt: article.createdAt || new Date().toISOString(),
    updatedAt: article.updatedAt || new Date().toISOString(),
  });
}

// ============================================================================
// USER PROFILE & PRIVATE PII SYNC
// ============================================================================
export async function syncUserSessionToFirestore(fbUser: FirebaseUser): Promise<User> {
  const uid = fbUser.uid;
  const email = (fbUser.email || '').trim().toLowerCase();
  const ownerFlag = isOwnerEmail(email) && fbUser.emailVerified;
  const userPath = `users/${uid}`;
  const privatePath = `users/${uid}/private/info`;

  let existingRole: UserRole | undefined;
  let existingBio = '';
  let existingCreatedAt: unknown = null;

  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (snap.exists()) {
      const data = snap.data();
      existingRole = data.role as UserRole | undefined;
      existingBio = typeof data.bio === 'string' ? data.bio : '';
      existingCreatedAt = data.createdAt || null;
    }
  } catch (err) {
    // Handle quietly if offline, otherwise surface structured context
    console.warn('[FirestoreSync] Read user profile notice:', err);
  }

  const resolvedRole = resolveRoleForEmail(email, existingRole);
  const displayName = truncate(
    fbUser.displayName || (ownerFlag ? 'Arjun Jareda' : email.split('@')[0] || 'Reader'),
    120
  );
  const photoURL = truncate(fbUser.photoURL || '', 2048);
  const bio = truncate(
    existingBio ||
      (resolvedRole === 'EDITORIAL_OWNER'
        ? 'Editorial Owner & Editor-in-Chief'
        : resolvedRole === 'OPERATIONS_OWNER'
        ? 'Operations Owner & Publication Director'
        : 'Verified Reader'),
    500
  );

  try {
    if (existingCreatedAt) {
      await updateDoc(doc(db, 'users', uid), {
        displayName,
        photoURL,
        bio,
        ...(ownerFlag
          ? {
              role: resolvedRole,
              status: 'ACTIVE',
              isPermanentOwner: true,
            }
          : {}),
        updatedAt: serverTimestamp(),
        lastLogin: serverTimestamp(),
      });
    } else {
      await setDoc(doc(db, 'users', uid), {
        uid,
        displayName,
        photoURL,
        role: ownerFlag ? resolvedRole : 'READER',
        status: 'ACTIVE',
        isPermanentOwner: ownerFlag,
        bio,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        lastLogin: serverTimestamp(),
      });
    }
  } catch (err) {
    try {
      handleFirestoreError(err, existingCreatedAt ? OperationType.UPDATE : OperationType.CREATE, userPath);
    } catch {
      // Logged with full context; allow auth session to continue
    }
  }

  if (email) {
    try {
      const privSnap = await getDoc(doc(db, 'users', uid, 'private', 'info'));
      if (privSnap.exists()) {
        await updateDoc(doc(db, 'users', uid, 'private', 'info'), {
          email,
          updatedAt: serverTimestamp(),
        });
      } else {
        await setDoc(doc(db, 'users', uid, 'private', 'info'), {
          uid,
          email,
          updatedAt: serverTimestamp(),
        });
      }
    } catch (err) {
      try {
        handleFirestoreError(err, OperationType.WRITE, privatePath);
      } catch {
        // Logged
      }
    }
  }

  return {
    id: uid,
    email,
    name: displayName,
    role: resolvedRole,
    status: 'ACTIVE',
    isPermanentOwner: ownerFlag,
    avatar: photoURL || undefined,
    bio,
    lastLogin: new Date().toISOString(),
  };
}

export async function fetchAllUsersFromFirestore(): Promise<User[]> {
  try {
    const snap = await getDocs(collection(db, 'users'));
    const users = await Promise.all(
      snap.docs.map(async (d) => {
        const data = d.data();
        let email = '';
        let customPermissions: string[] | undefined;
        try {
          const privSnap = await getDoc(doc(db, 'users', d.id, 'private', 'info'));
          if (privSnap.exists()) {
            const p = privSnap.data();
            email = p.email || '';
            customPermissions = Array.isArray(p.customPermissions) ? p.customPermissions : undefined;
          }
        } catch {}
        return {
          id: data.uid || d.id,
          email,
          name: data.displayName || 'Reader',
          role: (data.role as UserRole) || 'READER',
          status: (data.status as User['status']) || 'ACTIVE',
          isPermanentOwner: Boolean(data.isPermanentOwner),
          avatar: data.photoURL || undefined,
          bio: data.bio || undefined,
          customPermissions,
          createdAt: toIsoString(data.createdAt),
          lastLogin: data.lastLogin ? toIsoString(data.lastLogin) : undefined,
        } satisfies User;
      })
    );
    return users;
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.LIST, 'users');
    } catch {}
    return [];
  }
}

export async function updateUserRoleInFirestore(
  userId: string,
  role: UserRole,
  customPermissions?: string[]
): Promise<void> {
  try {
    await updateDoc(doc(db, 'users', userId), {
      role,
      updatedAt: serverTimestamp(),
    });
    if (customPermissions !== undefined) {
      const privRef = doc(db, 'users', userId, 'private', 'info');
      const privSnap = await getDoc(privRef);
      if (privSnap.exists()) {
        await updateDoc(privRef, {
          customPermissions,
          updatedAt: serverTimestamp(),
        });
      }
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
  }
}

export async function updateUserStatusInFirestore(
  userId: string,
  status: User['status']
): Promise<void> {
  try {
    await updateDoc(doc(db, 'users', userId), {
      status,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${userId}`);
  }
}

// ============================================================================
// SAVED STORIES & READING HISTORY (Per-User Persistent Storage)
// ============================================================================
export async function fetchUserSavedStoriesFromFirestore(
  uid: string
): Promise<{ articleId: string; savedAt: string; notes?: string }[]> {
  try {
    const q = query(collection(db, 'users', uid, 'saved'), orderBy('savedAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        articleId: data.articleId || d.id,
        savedAt: toIsoString(data.savedAt),
        notes: typeof data.notes === 'string' ? data.notes : undefined,
      };
    });
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.LIST, `users/${uid}/saved`);
    } catch {}
    return [];
  }
}

export async function saveStoryToFirestore(
  uid: string,
  article: { id: string; slug?: string; title?: string; category?: string }
): Promise<void> {
  try {
    await setDoc(doc(db, 'users', uid, 'saved', truncate(article.id, 128)), {
      articleId: truncate(article.id, 128),
      slug: truncate(article.slug || article.id, 200),
      title: truncate(article.title || '', 300),
      category: truncate(article.category || '', 80),
      savedAt: serverTimestamp(),
    });
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.CREATE, `users/${uid}/saved/${article.id}`);
    } catch {}
  }
}

export async function removeSavedStoryFromFirestore(uid: string, articleId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'users', uid, 'saved', truncate(articleId, 128)));
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.DELETE, `users/${uid}/saved/${articleId}`);
    } catch {}
  }
}

export async function clearUserSavedStoriesFromFirestore(uid: string): Promise<void> {
  try {
    const snap = await getDocs(collection(db, 'users', uid, 'saved'));
    if (snap.empty) return;
    const batch = writeBatch(db);
    snap.docs.forEach((d) => batch.delete(d.ref));
    await batch.commit();
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.DELETE, `users/${uid}/saved`);
    } catch {}
  }
}

export async function saveReadingHistoryToFirestore(
  uid: string,
  articleId: string,
  progressPercent: number
): Promise<void> {
  try {
    const cleanPct = Math.max(0, Math.min(100, Math.round(progressPercent)));
    await setDoc(doc(db, 'users', uid, 'history', truncate(articleId, 128)), {
      articleId: truncate(articleId, 128),
      progressPercent: cleanPct,
      readAt: serverTimestamp(),
    });
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.WRITE, `users/${uid}/history/${articleId}`);
    } catch {}
  }
}

// ============================================================================
// ARTICLES & EDITORIAL CONTENT COLLECTIONS
// ============================================================================
export async function fetchPublishedArticlesFromFirestore(): Promise<Article[]> {
  try {
    // Public queries MUST filter by status == 'PUBLISHED' to satisfy Firestore allow list rules
    const q = query(collection(db, 'articles'), where('status', '==', 'PUBLISHED'));
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as Article);
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.LIST, 'articles');
    } catch {}
    return [];
  }
}

export async function fetchAllArticlesFromFirestore(): Promise<Article[]> {
  try {
    const snap = await getDocs(collection(db, 'articles'));
    return snap.docs.map((d) => d.data() as Article);
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.LIST, 'articles');
    } catch {}
    return [];
  }
}

export async function saveArticleToFirestore(article: Article): Promise<void> {
  if (!auth.currentUser) return;
  try {
    const sanitized = sanitizeArticleForFirestore(article);
    await setDoc(doc(db, 'articles', String(sanitized.id)), sanitized);
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.WRITE, `articles/${article.id}`);
    } catch {}
  }
}

export async function deleteArticleFromFirestore(articleId: string): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await deleteDoc(doc(db, 'articles', truncate(articleId, 128)));
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.DELETE, `articles/${articleId}`);
    } catch {}
  }
}

export async function fetchCategoriesFromFirestore(): Promise<CategoryInfo[]> {
  try {
    const snap = await getDocs(collection(db, 'categories'));
    return snap.docs.map((d) => d.data() as CategoryInfo);
  } catch {
    return [];
  }
}

export async function saveCategoryToFirestore(category: CategoryInfo): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'categories', truncate(category.id, 128)), cleanForFirestore(category));
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.WRITE, `categories/${category.id}`);
    } catch {}
  }
}

export async function deleteCategoryFromFirestore(id: string): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await deleteDoc(doc(db, 'categories', truncate(id, 128)));
  } catch {}
}

export async function fetchAuthorsFromFirestore(): Promise<Author[]> {
  try {
    const snap = await getDocs(collection(db, 'authors'));
    return snap.docs.map((d) => d.data() as Author);
  } catch {
    return [];
  }
}

export async function saveAuthorToFirestore(author: Author): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'authors', truncate(author.id, 128)), cleanForFirestore(author));
  } catch {}
}

export async function deleteAuthorFromFirestore(id: string): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await deleteDoc(doc(db, 'authors', truncate(id, 128)));
  } catch {}
}

export async function fetchSeriesFromFirestore(): Promise<EditorialSeries[]> {
  try {
    const snap = await getDocs(collection(db, 'series'));
    return snap.docs.map((d) => d.data() as EditorialSeries);
  } catch {
    return [];
  }
}

export async function saveSeriesToFirestore(s: EditorialSeries): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'series', truncate(s.id, 128)), cleanForFirestore(s));
  } catch {}
}

export async function deleteSeriesFromFirestore(id: string): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await deleteDoc(doc(db, 'series', truncate(id, 128)));
  } catch {}
}

export async function fetchIssuesFromFirestore(): Promise<MagazineIssue[]> {
  try {
    const snap = await getDocs(collection(db, 'issues'));
    return snap.docs.map((d) => d.data() as MagazineIssue);
  } catch {
    return [];
  }
}

export async function saveIssueToFirestore(issue: MagazineIssue): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'issues', truncate(issue.id, 128)), cleanForFirestore(issue));
  } catch {}
}

export async function deleteIssueFromFirestore(id: string): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await deleteDoc(doc(db, 'issues', truncate(id, 128)));
  } catch {}
}

export async function fetchMediaFromFirestore(): Promise<MediaItem[]> {
  try {
    const snap = await getDocs(collection(db, 'media'));
    return snap.docs.map((d) => d.data() as MediaItem);
  } catch {
    return [];
  }
}

export async function saveMediaToFirestore(item: MediaItem): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'media', truncate(item.id, 128)), cleanForFirestore(item));
  } catch {}
}

export async function deleteMediaFromFirestore(id: string): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await deleteDoc(doc(db, 'media', truncate(id, 128)));
  } catch {}
}

// ============================================================================
// SITE SETTINGS (Homepage layout, Social Channels, Navigation, About, WebItems)
// ============================================================================
export async function fetchSiteSettingFromFirestore<T>(settingId: string): Promise<T | null> {
  try {
    const snap = await getDoc(doc(db, 'siteSettings', settingId));
    if (!snap.exists()) return null;
    const data = snap.data();
    return (data.payload ?? data) as T;
  } catch {
    return null;
  }
}

export async function saveSiteSettingToFirestore(settingId: string, payload: unknown): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'siteSettings', truncate(settingId, 128)), {
      id: truncate(settingId, 128),
      payload: cleanForFirestore(payload),
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.WRITE, `siteSettings/${settingId}`);
    } catch {}
  }
}

// ============================================================================
// SUBSCRIBERS, CONTACTS, AUDIT LOGS, TRASH, API KEYS
// ============================================================================
export async function saveSubscriberToFirestore(
  sub: Partial<NewsletterSubscriber> & { email: string; edition: 'weekly' | 'all' }
): Promise<void> {
  const id = truncate(sub.id || `sub-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, 128);
  try {
    await setDoc(doc(db, 'subscribers', id), {
      id,
      email: truncate(sub.email.trim().toLowerCase(), 254),
      edition: sub.edition === 'all' ? 'all' : 'weekly',
      status: sub.status === 'pending' ? 'pending' : 'active',
      subscribedAt: serverTimestamp(),
    });
  } catch (err) {
    try {
      handleFirestoreError(err, OperationType.CREATE, `subscribers/${id}`);
    } catch {}
  }
}

export async function fetchSubscribersFromFirestore(): Promise<NewsletterSubscriber[]> {
  try {
    const snap = await getDocs(collection(db, 'subscribers'));
    return snap.docs.map((d) => {
      const data = d.data();
      return {
        id: data.id || d.id,
        email: data.email || '',
        edition: data.edition || 'weekly',
        status: data.status || 'active',
        subscribedAt: toIsoString(data.subscribedAt),
      };
    });
  } catch {
    return [];
  }
}

export async function saveContactToFirestore(contact: ContactSubmission): Promise<void> {
  const id = truncate(contact.id || `contact-${Date.now()}`, 128);
  try {
    await setDoc(doc(db, 'contacts', id), {
      id,
      name: truncate(contact.name, 120),
      email: truncate(contact.email, 254),
      subject: truncate(contact.subject, 200),
      message: truncate(contact.message, 5000),
      status: 'unread',
      submittedAt: serverTimestamp(),
    });
  } catch {}
}

export async function fetchAuditLogsFromFirestore(): Promise<ActivityLog[]> {
  try {
    const q = query(collection(db, 'auditLogs'), orderBy('timestamp', 'desc'), limit(100));
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as ActivityLog);
  } catch {
    return [];
  }
}

export async function saveAuditLogToFirestore(log: ActivityLog): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'auditLogs', truncate(log.id, 128)), cleanForFirestore(log));
  } catch {}
}

export async function fetchTrashFromFirestore(): Promise<TrashItem[]> {
  try {
    const snap = await getDocs(collection(db, 'trash'));
    return snap.docs.map((d) => d.data() as TrashItem);
  } catch {
    return [];
  }
}

export async function saveTrashItemToFirestore(item: TrashItem): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'trash', truncate(item.id, 128)), cleanForFirestore(item));
  } catch {}
}

export async function deleteTrashItemFromFirestore(id: string): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await deleteDoc(doc(db, 'trash', truncate(id, 128)));
  } catch {}
}

export async function fetchApiKeysFromFirestore(): Promise<ApiKey[]> {
  try {
    const snap = await getDocs(collection(db, 'apiKeys'));
    return snap.docs.map((d) => d.data() as ApiKey);
  } catch {
    return [];
  }
}

export async function saveApiKeyToFirestore(key: ApiKey): Promise<void> {
  if (!auth.currentUser) return;
  try {
    await setDoc(doc(db, 'apiKeys', truncate(key.id, 128)), cleanForFirestore(key));
  } catch {}
}

// ============================================================================
// ONE-TIME SILENT SEEDING WHEN FIRESTORE IS EMPTY (Owner session only)
// ============================================================================
let seedInProgress = false;
export async function seedFirestoreIfNeeded(seed: {
  articles: Article[];
  categories: CategoryInfo[];
  authors: Author[];
  series: EditorialSeries[];
  issues: MagazineIssue[];
  homepageLayout: HomepageLayoutConfig | null;
  socialChannels: SocialChannel[];
  navigation?: NavigationItem[];
  aboutConfig?: AboutPageConfig;
  webItems?: WebItem[];
}): Promise<void> {
  if (seedInProgress || !auth.currentUser || !isOwnerEmail(auth.currentUser.email)) return;
  seedInProgress = true;
  try {
    const existingArticles = await getDocs(query(collection(db, 'articles'), limit(1)));
    if (existingArticles.empty && seed.articles.length > 0) {
      const batch = writeBatch(db);
      for (const art of seed.articles.slice(0, 50)) {
        const sanitized = sanitizeArticleForFirestore(art);
        batch.set(doc(db, 'articles', String(sanitized.id)), sanitized);
      }
      await batch.commit();
    }

    const existingCats = await getDocs(query(collection(db, 'categories'), limit(1)));
    if (existingCats.empty && seed.categories.length > 0) {
      const batch = writeBatch(db);
      for (const cat of seed.categories) {
        batch.set(doc(db, 'categories', truncate(cat.id, 128)), cleanForFirestore(cat));
      }
      await batch.commit();
    }

    const existingAuthors = await getDocs(query(collection(db, 'authors'), limit(1)));
    if (existingAuthors.empty && seed.authors.length > 0) {
      const batch = writeBatch(db);
      for (const au of seed.authors) {
        batch.set(doc(db, 'authors', truncate(au.id, 128)), cleanForFirestore(au));
      }
      await batch.commit();
    }

    const existingSeries = await getDocs(query(collection(db, 'series'), limit(1)));
    if (existingSeries.empty && seed.series.length > 0) {
      const batch = writeBatch(db);
      for (const s of seed.series) {
        batch.set(doc(db, 'series', truncate(s.id, 128)), cleanForFirestore(s));
      }
      await batch.commit();
    }

    const existingIssues = await getDocs(query(collection(db, 'issues'), limit(1)));
    if (existingIssues.empty && seed.issues.length > 0) {
      const batch = writeBatch(db);
      for (const iss of seed.issues) {
        batch.set(doc(db, 'issues', truncate(iss.id, 128)), cleanForFirestore(iss));
      }
      await batch.commit();
    }

    if (seed.homepageLayout) {
      const hpSnap = await getDoc(doc(db, 'siteSettings', 'homepage'));
      if (!hpSnap.exists()) {
        await saveSiteSettingToFirestore('homepage', seed.homepageLayout);
      }
    }

    if (seed.socialChannels.length > 0) {
      const socSnap = await getDoc(doc(db, 'siteSettings', 'socialChannels'));
      if (!socSnap.exists()) {
        await saveSiteSettingToFirestore('socialChannels', seed.socialChannels);
      }
    }
  } catch (err) {
    console.warn('[FirestoreSync] Background seed notice:', err);
  } finally {
    seedInProgress = false;
  }
}
