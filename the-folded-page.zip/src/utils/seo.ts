/**
 * SEO & Social Metadata Utility
 * Conforms with applet-seo skill and search engine indexing standards.
 * Dynamically manages <title>, meta description, canonical URLs,
 * OpenGraph, Twitter cards, and Schema.org structured data (JSON-LD).
 */

export interface BreadcrumbItem {
  name: string;
  path: string;
}

export interface SeoConfig {
  title?: string;
  description?: string;
  canonicalPath?: string;
  ogType?: 'website' | 'article' | 'profile';
  ogImage?: string;
  ogImageAlt?: string;
  authorName?: string;
  publishedTime?: string;
  modifiedTime?: string;
  section?: string;
  tags?: string[];
  keywords?: string[];
  noIndex?: boolean;
  breadcrumbs?: BreadcrumbItem[];
  structuredData?: object;
}

const DEFAULT_ORIGIN = 'https://foldedpage.in';
const DEFAULT_TITLE = "The Folded Page – What's Worth Knowing | Digital Editorial Magazine";
const DEFAULT_DESC =
  'A modern digital editorial magazine discovering noteworthy stories, cultural perspectives, human curiosities, and timeless insights from around the world. What\'s worth knowing.';
const DEFAULT_IMAGE = `${DEFAULT_ORIGIN}/logo.svg`;

function setMetaTag(selector: string, attrName: 'content', value: string) {
  let element = document.querySelector(selector) as HTMLMetaElement | null;
  if (!element) {
    element = document.createElement('meta');
    if (selector.startsWith('meta[name=')) {
      const name = selector.match(/name="([^"]+)"/)?.[1];
      if (name) element.setAttribute('name', name);
    } else if (selector.startsWith('meta[property=')) {
      const prop = selector.match(/property="([^"]+)"/)?.[1];
      if (prop) element.setAttribute('property', prop);
    }
    document.head.appendChild(element);
  }
  element.setAttribute(attrName, value);
}

function removeMetaTag(selector: string) {
  const element = document.querySelector(selector);
  if (element) {
    element.remove();
  }
}

function setCanonical(url: string) {
  let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', 'canonical');
    document.head.appendChild(link);
  }
  link.setAttribute('href', url);
}

function setStructuredData(data?: object) {
  const SCRIPT_ID = 'dynamic-seo-ldjson';
  let script = document.getElementById(SCRIPT_ID) as HTMLScriptElement | null;
  if (!data) {
    if (script) script.remove();
    return;
  }
  if (!script) {
    script = document.createElement('script');
    script.id = SCRIPT_ID;
    script.type = 'application/ld+json';
    document.head.appendChild(script);
  }
  script.textContent = JSON.stringify(data, null, 2);
}

export function updatePageSeo(config: SeoConfig) {
  if (typeof document === 'undefined') return;

  const origin =
    typeof window !== 'undefined' && window.location.origin && !window.location.origin.includes('localhost')
      ? window.location.origin
      : DEFAULT_ORIGIN;

  const title = config.title ? `${config.title} — The Folded Page` : DEFAULT_TITLE;
  const description = config.description || DEFAULT_DESC;
  const canonicalUrl = config.canonicalPath
    ? `${origin}${config.canonicalPath.startsWith('/') ? config.canonicalPath : `/${config.canonicalPath}`}`
    : typeof window !== 'undefined'
    ? `${origin}${window.location.pathname}`
    : DEFAULT_ORIGIN;

  const image = config.ogImage
    ? config.ogImage.startsWith('http')
      ? config.ogImage
      : `${origin}${config.ogImage.startsWith('/') ? config.ogImage : `/${config.ogImage}`}`
    : DEFAULT_IMAGE;

  // 1. Page Title
  document.title = title;

  // 2. Canonical URL
  setCanonical(canonicalUrl);

  // 3. Meta Description
  setMetaTag('meta[name="description"]', 'content', description);

  // 4. Meta Keywords
  const combinedKeywords = Array.from(
    new Set([
      ...(config.keywords || []),
      ...(config.tags || []),
      'The Folded Page',
      'Editorial Magazine',
      'What is worth knowing',
      'Culture',
      'Storytelling',
      'Longform Journalism',
    ])
  ).join(', ');
  setMetaTag('meta[name="keywords"]', 'content', combinedKeywords);

  // 5. Search Engine Robots & Crawlers Directives
  if (config.noIndex) {
    setMetaTag('meta[name="robots"]', 'content', 'noindex, follow');
    setMetaTag('meta[name="googlebot"]', 'content', 'noindex, follow');
    setMetaTag('meta[name="bingbot"]', 'content', 'noindex, follow');
  } else {
    setMetaTag(
      'meta[name="robots"]',
      'content',
      'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1'
    );
    setMetaTag(
      'meta[name="googlebot"]',
      'content',
      'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1'
    );
    setMetaTag(
      'meta[name="bingbot"]',
      'content',
      'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1'
    );
  }

  // 6. OpenGraph Tags
  setMetaTag('meta[property="og:site_name"]', 'content', 'The Folded Page');
  setMetaTag('meta[property="og:title"]', 'content', title);
  setMetaTag('meta[property="og:description"]', 'content', description);
  setMetaTag('meta[property="og:url"]', 'content', canonicalUrl);
  setMetaTag('meta[property="og:type"]', 'content', config.ogType || 'website');
  setMetaTag('meta[property="og:image"]', 'content', image);
  setMetaTag('meta[property="og:locale"]', 'content', 'en_US');
  if (config.ogImageAlt) {
    setMetaTag('meta[property="og:image:alt"]', 'content', config.ogImageAlt);
  }

  // Article-specific OpenGraph metadata
  if (config.ogType === 'article') {
    if (config.publishedTime) {
      setMetaTag('meta[property="article:published_time"]', 'content', config.publishedTime);
    }
    if (config.modifiedTime) {
      setMetaTag('meta[property="article:modified_time"]', 'content', config.modifiedTime);
    }
    if (config.section) {
      setMetaTag('meta[property="article:section"]', 'content', config.section);
    }
    if (config.authorName) {
      setMetaTag('meta[property="article:author"]', 'content', config.authorName);
    }
  } else {
    removeMetaTag('meta[property="article:published_time"]');
    removeMetaTag('meta[property="article:modified_time"]');
    removeMetaTag('meta[property="article:section"]');
    removeMetaTag('meta[property="article:author"]');
  }

  // 7. Twitter Card Tags
  setMetaTag('meta[name="twitter:card"]', 'content', 'summary_large_image');
  setMetaTag('meta[name="twitter:site"]', 'content', '@thefoldedpage');
  setMetaTag('meta[name="twitter:creator"]', 'content', '@thefoldedpage');
  setMetaTag('meta[name="twitter:title"]', 'content', title);
  setMetaTag('meta[name="twitter:description"]', 'content', description);
  setMetaTag('meta[name="twitter:image"]', 'content', image);
  if (config.ogImageAlt) {
    setMetaTag('meta[name="twitter:image:alt"]', 'content', config.ogImageAlt);
  }

  // 8. Dynamic Schema.org JSON-LD Graph Generation
  let structuredData = config.structuredData;
  if (!structuredData && !config.noIndex) {
    // Generate default enriched schema graph
    const graph: any[] = [
      {
        '@type': 'NewsMediaOrganization',
        '@id': `${origin}/#organization`,
        name: 'The Folded Page',
        url: `${origin}/`,
        logo: {
          '@type': 'ImageObject',
          url: `${origin}/logo.svg`,
          caption: 'The Folded Page',
        },
        description: DEFAULT_DESC,
        slogan: "What's Worth Knowing.",
        contactPoint: {
          '@type': 'ContactPoint',
          contactType: 'customer support',
          email: 'support@foldedpage.in',
          availableLanguage: ['English', 'Hindi'],
        },
      },
      {
        '@type': 'WebSite',
        '@id': `${origin}/#website`,
        url: `${origin}/`,
        name: 'The Folded Page',
        publisher: {
          '@id': `${origin}/#organization`,
        },
        potentialAction: {
          '@type': 'SearchAction',
          target: {
            '@type': 'EntryPoint',
            urlTemplate: `${origin}/explore?q={search_term_string}`,
          },
          'query-input': 'required name=search_term_string',
        },
      },
    ];

    if (config.breadcrumbs && config.breadcrumbs.length > 0) {
      graph.push({
        '@type': 'BreadcrumbList',
        itemListElement: config.breadcrumbs.map((b, idx) => ({
          '@type': 'ListItem',
          position: idx + 1,
          name: b.name,
          item: b.path.startsWith('http') ? b.path : `${origin}${b.path.startsWith('/') ? b.path : `/${b.path}`}`,
        })),
      });
    }

    structuredData = {
      '@context': 'https://schema.org',
      '@graph': graph,
    };
  } else if (structuredData && config.breadcrumbs && config.breadcrumbs.length > 0) {
    // Append breadcrumbs to structured data graph if present
    const existing: any = structuredData;
    if (existing['@graph'] && Array.isArray(existing['@graph'])) {
      existing['@graph'].push({
        '@type': 'BreadcrumbList',
        itemListElement: config.breadcrumbs.map((b, idx) => ({
          '@type': 'ListItem',
          position: idx + 1,
          name: b.name,
          item: b.path.startsWith('http') ? b.path : `${origin}${b.path.startsWith('/') ? b.path : `/${b.path}`}`,
        })),
      });
    }
  }

  setStructuredData(structuredData);
}

export function resetToDefaultSeo() {
  updatePageSeo({
    title: undefined,
    description: DEFAULT_DESC,
    canonicalPath: '/',
    ogType: 'website',
    breadcrumbs: [{ name: 'Home', path: '/' }],
  });
}
