import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { onIdTokenChanged, signInWithPopup, signOut, User as FirebaseUser } from 'firebase/auth';
import {
  Article,
  CategoryInfo,
  Author,
  EditorialSeries,
  MagazineIssue,
  HomepageLayoutConfig,
  User,
  SocialChannel,
} from '../types';
import { ARTICLES } from '../data/articles';
import { CATEGORIES } from '../data/categories';
import { AUTHORS } from '../data/authors';
import { EDITORIAL_SERIES } from '../data/series';
import { MAGAZINE_ISSUES } from '../data/issues';
import { DEFAULT_SOCIAL_CHANNELS } from '../data/social';
import { api, setAuthSession } from '../services/api';
import { magazineAudio } from '../utils/audioEngine';
import {
  auth,
  googleProvider,
  testConnection,
  isOwnerEmail,
  resolveRoleForEmail,
  isOwnerRole,
  isStaffRole,
} from '../lib/firebase';
import {
  syncUserSessionToFirestore,
  fetchUserSavedStoriesFromFirestore,
  saveStoryToFirestore,
  removeSavedStoryFromFirestore,
  clearUserSavedStoriesFromFirestore,
  saveReadingHistoryToFirestore,
  fetchPublishedArticlesFromFirestore,
  fetchAllArticlesFromFirestore,
  fetchCategoriesFromFirestore,
  fetchAuthorsFromFirestore,
  fetchSeriesFromFirestore,
  fetchIssuesFromFirestore,
  fetchSiteSettingFromFirestore,
  seedFirestoreIfNeeded,
} from '../services/firestoreSync';

export interface SavedStoryItem {
  articleId: string;
  savedAt: string;
  notes?: string;
}

export interface ReadingHistoryItem {
  articleId: string;
  readAt: string;
  progressPercent: number;
}

interface MagazineContextType {
  // Dynamic Data collections
  articles: Article[];
  categories: CategoryInfo[];
  authors: Author[];
  deleteAuthor: (id: string) => Promise<void>;
  series: EditorialSeries[];
  issues: MagazineIssue[];
  homepageLayout: HomepageLayoutConfig | null;
  isLoading: boolean;
  refreshArticles: () => Promise<void>;
  refreshAll: () => Promise<void>;

  // Editorial Section Derived helpers
  coverStory: Article | null;
  trendingStories: Article[];
  foldStories: Article[];
  popularStories: Article[];
  uniqueStories: Article[];
  specialStories: Article[];
  editorsPicks: Article[];

  // Saved & Reading History
  savedStories: SavedStoryItem[];
  savedArticles: Article[];
  toggleSave: (articleId: string) => void;
  toggleSaveArticle: (articleOrId: Article | string) => void;
  isSaved: (articleId: string) => boolean;
  isArticleSaved: (articleId: string) => boolean;
  clearSaved: () => void;
  readingHistory: ReadingHistoryItem[];
  addToHistory: (articleId: string, progress?: number) => void;

  // UI Modals & Overlays
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isSavedDrawerOpen: boolean;
  setIsSavedDrawerOpen: (open: boolean) => void;
  isNewsletterOpen: boolean;
  setIsNewsletterOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authModalMode: 'login' | 'signup';
  setAuthModalMode: (mode: 'login' | 'signup') => void;
  openAuthModal: (mode?: 'login' | 'signup') => void;
  closeAuthModal: () => void;
  shareArticle: Article | null;
  setShareArticle: (article: Article | null) => void;
  subscriberCount: number;
  refreshSubscribers: () => Promise<void>;

  // Reader Preferences
  fontSize: 'sm' | 'base' | 'lg' | 'xl';
  setFontSize: (size: 'sm' | 'base' | 'lg' | 'xl') => void;
  readerTheme: 'paper' | 'white' | 'dark';
  setReaderTheme: (theme: 'paper' | 'white' | 'dark') => void;

  // Audio Narration
  activeAudioArticle: Article | null;
  isPlayingAudio: boolean;
  playAudio: (article: Article) => void;
  pauseAudio: () => void;
  toggleAudioPlay: () => void;
  stopAudio: () => void;
  audioProgress: number;
  setAudioProgress: (progress: number) => void;
  audioSpeed: number;
  setAudioSpeed: (speed: number) => void;

  // Social Channels & Feeds
  socialChannels: SocialChannel[];
  updateSocialChannels: (channels: SocialChannel[]) => Promise<void>;
  updateSocialChannel: (id: string, updates: Partial<SocialChannel>) => Promise<void>;
  addSocialChannel: (channel: Omit<SocialChannel, 'id'>) => Promise<void>;
  deleteSocialChannel: (id: string) => Promise<void>;
  resetSocialChannels: () => Promise<void>;

  // Unified Authentication & Role State
  currentUser: User | null;
  isAuthReady: boolean;
  authError: string | null;
  clearAuthError: () => void;
  isAuthenticated: boolean;
  isOwner: boolean;
  isStaff: boolean;
  signInWithGoogle: () => Promise<User | null>;
  logoutAdmin: () => Promise<void>;
  logout: () => Promise<void>;
}

const MagazineContext = createContext<MagazineContextType | undefined>(undefined);

function mapFirebaseUserFallback(fbUser: FirebaseUser): User {
  const email = (fbUser.email || '').trim().toLowerCase();
  const verifiedOwner = isOwnerEmail(email) && fbUser.emailVerified;
  const role = verifiedOwner ? resolveRoleForEmail(email) : 'READER';
  return {
    id: fbUser.uid,
    email,
    name: fbUser.displayName || (email ? email.split('@')[0] : 'Reader'),
    role,
    status: 'ACTIVE',
    isPermanentOwner: verifiedOwner,
    avatar: fbUser.photoURL || undefined,
    bio:
      role === 'EDITORIAL_OWNER'
        ? 'Editorial Owner & Editor-in-Chief'
        : role === 'OPERATIONS_OWNER'
        ? 'Operations Owner & Publication Director'
        : 'Verified Reader',
    lastLogin: new Date().toISOString(),
  };
}

export const MagazineProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Collections state with persistent local cache
  const [articles, setArticles] = useState<Article[]>(() => {
    try {
      const cached = localStorage.getItem('tfp_cached_articles');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {}
    return ARTICLES;
  });
  const [categories, setCategories] = useState<CategoryInfo[]>(CATEGORIES);
  const [authors, setAuthors] = useState<Author[]>(Object.values(AUTHORS));
  const [series, setSeries] = useState<EditorialSeries[]>(EDITORIAL_SERIES);
  const [issues, setIssues] = useState<MagazineIssue[]>(MAGAZINE_ISSUES);
  const [homepageLayout, setHomepageLayout] = useState<HomepageLayoutConfig | null>(null);
  const [socialChannels, setSocialChannels] = useState<SocialChannel[]>(() => {
    try {
      const saved = localStorage.getItem('tfp_social_channels');
      return saved ? JSON.parse(saved) : DEFAULT_SOCIAL_CHANNELS;
    } catch {
      return DEFAULT_SOCIAL_CHANNELS;
    }
  });
  const [isLoading, setIsLoading] = useState(false);
  const [subscriberCount, setSubscriberCount] = useState<number>(() => {
    try {
      const cached = localStorage.getItem('tfp_cached_subscribers');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed)) return parsed.length;
      }
    } catch {}
    return 0;
  });

  // Authentication state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const clearAuthError = useCallback(() => setAuthError(null), []);

  // Silent Firestore connection verification on mount
  useEffect(() => {
    testConnection().catch(() => {});
  }, []);

  const refreshSubscribers = useCallback(async () => {
    try {
      const subs = await api.getNewsletterSubscribers();
      if (Array.isArray(subs)) {
        setSubscriberCount(subs.length);
        try {
          localStorage.setItem('tfp_cached_subscribers', JSON.stringify(subs));
        } catch {}
      }
    } catch {
      // Quietly ignore for public visitors without owner permissions
    }
  }, []);

  // Keep articles cached to localStorage
  useEffect(() => {
    if (articles && articles.length > 0) {
      try {
        localStorage.setItem('tfp_cached_articles', JSON.stringify(articles));
      } catch {}
    }
  }, [articles]);

  // Saved & Reading History state
  const [savedStories, setSavedStories] = useState<SavedStoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('tfp_saved_stories');
      if (!saved) return [];
      const parsed = JSON.parse(saved);
      if (!Array.isArray(parsed)) return [];

      const normalized: SavedStoryItem[] = parsed
        .map((item: any) => {
          if (typeof item === 'string') {
            return { articleId: item, savedAt: new Date().toISOString() };
          }
          if (item && typeof item === 'object' && item.articleId) {
            return { articleId: String(item.articleId), savedAt: item.savedAt || new Date().toISOString() };
          }
          return null;
        })
        .filter((item): item is SavedStoryItem => Boolean(item));

      const hasCleanedLegacy = localStorage.getItem('tfp_saved_cleaned_v2');
      if (!hasCleanedLegacy) {
        localStorage.setItem('tfp_saved_cleaned_v2', 'true');
        if (normalized.length === 1 && normalized[0].articleId === 'story-01') {
          localStorage.setItem('tfp_saved_stories', JSON.stringify([]));
          return [];
        }
      }

      return normalized;
    } catch {
      return [];
    }
  });

  const [readingHistory, setReadingHistory] = useState<ReadingHistoryItem[]>(() => {
    try {
      const hist = localStorage.getItem('tfp_reading_history');
      return hist ? JSON.parse(hist) : [];
    } catch {
      return [];
    }
  });

  // UI state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSavedDrawerOpen, setIsSavedDrawerOpen] = useState(false);
  const [isNewsletterOpen, setIsNewsletterOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup'>('login');
  const [shareArticle, setShareArticle] = useState<Article | null>(null);

  const openAuthModal = useCallback((mode: 'login' | 'signup' = 'login') => {
    setAuthError(null);
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  }, []);

  const closeAuthModal = useCallback(() => {
    setIsAuthModalOpen(false);
  }, []);

  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg' | 'xl'>('base');
  const [readerTheme, setReaderTheme] = useState<'paper' | 'white' | 'dark'>('white');

  // Audio player state
  const [activeAudioArticle, setActiveAudioArticle] = useState<Article | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const [audioSpeed, setAudioSpeed] = useState(1);

  const mergeArticleLists = useCallback((primary: Article[], secondary: Article[]): Article[] => {
    const map = new Map<string, Article>();
    for (const item of secondary) {
      if (item && item.id) map.set(item.id, item);
    }
    for (const item of primary) {
      if (!item || !item.id) continue;
      const existing = map.get(item.id);
      if (!existing) {
        map.set(item.id, item);
      } else {
        const tPrimary = new Date(item.updatedAt || item.publishedAt || 0).getTime() || 0;
        const tExisting = new Date(existing.updatedAt || existing.publishedAt || 0).getTime() || 0;
        map.set(item.id, tPrimary >= tExisting ? item : existing);
      }
    }
    return Array.from(map.values());
  }, []);

  // Refresh articles from API + silent background Firestore persistence
  const refreshArticles = useCallback(async () => {
    const canReadAll = Boolean(auth.currentUser?.email && isOwnerEmail(auth.currentUser.email) && auth.currentUser.emailVerified);
    try {
      const [apiRes, fsRes] = await Promise.allSettled([
        api.getArticles({ includeDrafts: canReadAll }),
        canReadAll ? fetchAllArticlesFromFirestore() : fetchPublishedArticlesFromFirestore(),
      ]);

      const apiList = apiRes.status === 'fulfilled' && Array.isArray(apiRes.value.articles) ? apiRes.value.articles : [];
      const fsList = fsRes.status === 'fulfilled' && Array.isArray(fsRes.value) ? fsRes.value : [];
      const combined = mergeArticleLists(apiList, fsList);

      if (combined.length > 0) {
        setArticles((prev) => {
          const remoteIds = new Set(combined.map((a) => a.id));
          const localDraftsOnly = prev.filter((a) => !remoteIds.has(a.id) && a.status === 'DRAFT');
          const merged = [...combined, ...localDraftsOnly];
          try {
            localStorage.setItem('tfp_cached_articles', JSON.stringify(merged));
          } catch {}
          return merged;
        });
      }
    } catch {
      // Quiet fallback to existing state
    }
  }, [mergeArticleLists]);

  const refreshAll = useCallback(async () => {
    setIsLoading(true);
    const canReadAll = Boolean(auth.currentUser?.email && isOwnerEmail(auth.currentUser.email) && auth.currentUser.emailVerified);
    try {
      const [artRes, fsArtRes, catRes, fsCatRes, auRes, fsAuRes, serRes, fsSerRes, issRes, fsIssRes, layoutRes, fsLayoutRes, socialRes, fsSocialRes] =
        await Promise.allSettled([
          api.getArticles({ includeDrafts: canReadAll }),
          canReadAll ? fetchAllArticlesFromFirestore() : fetchPublishedArticlesFromFirestore(),
          api.getCategories(),
          fetchCategoriesFromFirestore(),
          api.getAuthors(),
          fetchAuthorsFromFirestore(),
          api.getSeries(),
          fetchSeriesFromFirestore(),
          api.getIssues(),
          fetchIssuesFromFirestore(),
          api.getHomepageLayout(),
          fetchSiteSettingFromFirestore<HomepageLayoutConfig>('homepage'),
          api.getSocialChannels(),
          fetchSiteSettingFromFirestore<SocialChannel[]>('socialChannels'),
        ]);

      const apiArts = artRes.status === 'fulfilled' && Array.isArray(artRes.value.articles) ? artRes.value.articles : [];
      const fsArts = fsArtRes.status === 'fulfilled' && Array.isArray(fsArtRes.value) ? fsArtRes.value : [];
      const combinedArts = mergeArticleLists(apiArts, fsArts);
      if (combinedArts.length > 0) {
        setArticles((prev) => {
          const remoteIds = new Set(combinedArts.map((a) => a.id));
          const localDraftsOnly = prev.filter((a) => !remoteIds.has(a.id) && a.status === 'DRAFT');
          const merged = [...combinedArts, ...localDraftsOnly];
          try {
            localStorage.setItem('tfp_cached_articles', JSON.stringify(merged));
          } catch {}
          return merged;
        });
      }

      const nextCats =
        catRes.status === 'fulfilled' && Array.isArray(catRes.value) && catRes.value.length > 0
          ? catRes.value
          : fsCatRes.status === 'fulfilled' && Array.isArray(fsCatRes.value) && fsCatRes.value.length > 0
          ? fsCatRes.value
          : null;
      if (nextCats) setCategories(nextCats);

      const nextAuthors =
        auRes.status === 'fulfilled' && Array.isArray(auRes.value) && auRes.value.length > 0
          ? auRes.value
          : fsAuRes.status === 'fulfilled' && Array.isArray(fsAuRes.value) && fsAuRes.value.length > 0
          ? fsAuRes.value
          : null;
      if (nextAuthors) setAuthors(nextAuthors);

      const nextSeries =
        serRes.status === 'fulfilled' && Array.isArray(serRes.value) && serRes.value.length > 0
          ? serRes.value
          : fsSerRes.status === 'fulfilled' && Array.isArray(fsSerRes.value) && fsSerRes.value.length > 0
          ? fsSerRes.value
          : null;
      if (nextSeries) setSeries(nextSeries);

      const nextIssues =
        issRes.status === 'fulfilled' && Array.isArray(issRes.value) && issRes.value.length > 0
          ? issRes.value
          : fsIssRes.status === 'fulfilled' && Array.isArray(fsIssRes.value) && fsIssRes.value.length > 0
          ? fsIssRes.value
          : null;
      if (nextIssues) setIssues(nextIssues);

      const nextLayout =
        layoutRes.status === 'fulfilled' && layoutRes.value
          ? layoutRes.value
          : fsLayoutRes.status === 'fulfilled' && fsLayoutRes.value
          ? fsLayoutRes.value
          : null;
      if (nextLayout) setHomepageLayout(nextLayout);

      const nextSocial =
        socialRes.status === 'fulfilled' && Array.isArray(socialRes.value) && socialRes.value.length > 0
          ? socialRes.value
          : fsSocialRes.status === 'fulfilled' && Array.isArray(fsSocialRes.value) && fsSocialRes.value.length > 0
          ? fsSocialRes.value
          : null;
      if (nextSocial) {
        setSocialChannels(nextSocial);
        try {
          localStorage.setItem('tfp_social_channels', JSON.stringify(nextSocial));
        } catch {}
      }

      if (canReadAll) {
        await refreshSubscribers();
      }
    } catch {
      // Quiet fallback
    } finally {
      setIsLoading(false);
    }
  }, [mergeArticleLists, refreshSubscribers]);

  // Listen to real-time authentication state and automatically detect readers vs owners
  useEffect(() => {
    let active = true;
    const unsubscribe = onIdTokenChanged(auth, async (fbUser) => {
      if (!active) return;

      if (!fbUser) {
        setAuthSession(null, null);
        setCurrentUser(null);
        setIsAuthReady(true);
        return;
      }

      try {
        const idToken = await fbUser.getIdToken();
        if (!active) return;

        setAuthSession(idToken, fbUser.email);

        const [fsResult, apiResult] = await Promise.allSettled([
          syncUserSessionToFirestore(fbUser),
          api.syncFirebaseSession(idToken),
        ]);

        if (!active) return;

        const fsUser = fsResult.status === 'fulfilled' ? fsResult.value : null;
        const apiSync = apiResult.status === 'fulfilled' ? apiResult.value : null;
        const fallbackUser = mapFirebaseUserFallback(fbUser);

        const mergedUser: User = apiSync?.user
          ? {
              ...fallbackUser,
              ...fsUser,
              ...apiSync.user,
              id: fbUser.uid,
              email: fbUser.email || apiSync.user.email || fallbackUser.email,
              avatar: fbUser.photoURL || apiSync.user.avatar || fsUser?.avatar,
            }
          : fsUser || fallbackUser;

        const verifiedOwner = Boolean(
          fbUser.email && isOwnerEmail(fbUser.email) && fbUser.emailVerified
        );
        if (verifiedOwner) {
          mergedUser.role = resolveRoleForEmail(fbUser.email);
          mergedUser.isPermanentOwner = true;
          mergedUser.status = 'ACTIVE';
        }

        setCurrentUser(mergedUser);
        setIsAuthReady(true);

        // Hydrate & sync saved stories across devices
        fetchUserSavedStoriesFromFirestore(fbUser.uid)
          .then((remoteSaved) => {
            if (!active) return;
            setSavedStories((prevLocal) => {
              const remoteMap = new Map(remoteSaved.map((item) => [item.articleId, item]));
              const localOnly = prevLocal.filter((item) => !remoteMap.has(item.articleId));

              for (const localItem of localOnly) {
                const art = articles.find((a) => a.id === localItem.articleId);
                saveStoryToFirestore(fbUser.uid, {
                  id: localItem.articleId,
                  slug: art?.slug,
                  title: art?.title,
                  category: art?.category,
                }).catch(() => {});
              }

              const combined = [...remoteSaved, ...localOnly];
              return combined;
            });
          })
          .catch(() => {});

        // Silently ensure background store is seeded & owner collections refreshed when owner signs in
        if (verifiedOwner) {
          seedFirestoreIfNeeded({
            articles,
            categories,
            authors,
            series,
            issues,
            homepageLayout,
            socialChannels,
          }).catch(() => {});
          refreshArticles();
          refreshSubscribers();
        }
      } catch (err) {
        console.warn('[Auth] Session resolution notice:', err);
        if (active) {
          setCurrentUser(mapFirebaseUserFallback(fbUser));
          setIsAuthReady(true);
        }
      }
    });

    return () => {
      active = false;
      unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const deleteAuthor = useCallback(
    async (id: string) => {
      const cleanId = (id || '').trim();
      setAuthors((prev) => prev.filter((a) => a.id !== cleanId && a.slug !== cleanId));
      try {
        await api.deleteAuthor(cleanId);
      } catch (err) {
        console.error('Failed to delete author via API:', err);
      }
      await refreshAll();
    },
    [refreshAll]
  );

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  // Cross-tab synchronization
  useEffect(() => {
    let bc: BroadcastChannel | null = null;
    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        bc = new BroadcastChannel('tfp_magazine_sync');
        bc.onmessage = (event) => {
          const data = event?.data;
          if (!data) return;
          if (data.type === 'ARTICLE_DELETED' && data.payload?.id) {
            setArticles((prev) => prev.filter((a) => a.id !== data.payload.id && a.slug !== data.payload.id));
          } else if (data.type === 'ARTICLE_CREATED' && data.payload) {
            setArticles((prev) => [data.payload, ...prev.filter((a) => a.id !== data.payload.id)]);
          } else if ((data.type === 'ARTICLE_UPDATED' || data.type === 'ARTICLE_PUBLISHED') && data.payload) {
            setArticles((prev) => {
              const exists = prev.some((a) => a.id === data.payload.id);
              if (exists) {
                return prev.map((a) => (a.id === data.payload.id ? data.payload : a));
              }
              return [data.payload, ...prev];
            });
          }
          if (data.type?.startsWith('ARTICLE_') || data.type?.startsWith('USER_')) {
            refreshArticles();
          }
        };
      }
    } catch {}

    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'tfp_cached_articles' && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setArticles(parsed);
          }
        } catch {}
      } else if (e.key === 'tfp_sync_signal') {
        refreshArticles();
      }
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        refreshArticles();
      }
    };

    const handleFocus = () => {
      refreshArticles();
    };

    window.addEventListener('storage', handleStorage);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleFocus);

    const interval = setInterval(() => {
      refreshArticles();
    }, 15000);

    return () => {
      if (bc) bc.close();
      window.removeEventListener('storage', handleStorage);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocus);
      clearInterval(interval);
    };
  }, [refreshArticles]);

  // Sync saved to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('tfp_saved_stories', JSON.stringify(savedStories));
    } catch {}
  }, [savedStories]);

  // Sync history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('tfp_reading_history', JSON.stringify(readingHistory));
    } catch {}
  }, [readingHistory]);

  // Save / Bookmark operations (local + background account persistence)
  const toggleSave = (articleId: string) => {
    const art = articles.find((a) => a.id === articleId);
    const uid = auth.currentUser?.uid;

    setSavedStories((prev) => {
      const exists = prev.some((item) => item.articleId === articleId);
      if (exists) {
        if (uid) {
          removeSavedStoryFromFirestore(uid, articleId).catch(() => {});
        }
        return prev.filter((item) => item.articleId !== articleId);
      } else {
        api.trackEvent('save', articleId);
        if (uid) {
          saveStoryToFirestore(uid, {
            id: articleId,
            slug: art?.slug,
            title: art?.title,
            category: art?.category,
          }).catch(() => {});
        }
        return [{ articleId, savedAt: new Date().toISOString() }, ...prev];
      }
    });
  };

  const toggleSaveArticle = (articleOrId: Article | string) => {
    const id = typeof articleOrId === 'string' ? articleOrId : articleOrId.id;
    toggleSave(id);
  };

  const isSaved = (articleId?: string) => {
    if (!articleId) return false;
    return savedStories.some((item) => item.articleId === articleId);
  };

  const isArticleSaved = isSaved;

  const clearSaved = () => {
    setSavedStories([]);
    const uid = auth.currentUser?.uid;
    if (uid) {
      clearUserSavedStoriesFromFirestore(uid).catch(() => {});
    }
  };

  const addToHistory = (articleId: string, progress = 100) => {
    api.trackEvent('view', articleId);
    const uid = auth.currentUser?.uid;
    if (uid) {
      saveReadingHistoryToFirestore(uid, articleId, progress).catch(() => {});
    }
    setReadingHistory((prev) => {
      const filtered = prev.filter((h) => h.articleId !== articleId);
      return [{ articleId, readAt: new Date().toISOString(), progressPercent: progress }, ...filtered].slice(0, 30);
    });
  };

  const savedArticles = savedStories
    .map((s) => articles.find((a) => a.id === s.articleId))
    .filter((a): a is Article => Boolean(a));

  // Audio controls powered by magazineAudio
  const playAudio = (article: Article) => {
    try {
      setActiveAudioArticle(article);
      setAudioProgress(0);
      setIsPlayingAudio(true);

      magazineAudio.play(
        article,
        {
          onProgress: (percent) => {
            setAudioProgress(percent);
          },
          onEnd: () => {
            setIsPlayingAudio(false);
            setAudioProgress(100);
          },
          onError: (err) => {
            console.error('Audio engine playback notice:', err);
          },
          onStateChange: (playing) => {
            setIsPlayingAudio(playing);
          },
        },
        audioSpeed
      );
    } catch (err) {
      console.error('Failed to start audio playback:', err);
      setIsPlayingAudio(false);
    }
  };

  const pauseAudio = () => {
    try {
      magazineAudio.pause();
      setIsPlayingAudio(false);
    } catch {}
  };

  const toggleAudioPlay = () => {
    try {
      if (isPlayingAudio) {
        magazineAudio.pause();
        setIsPlayingAudio(false);
      } else if (activeAudioArticle) {
        magazineAudio.resume();
        setIsPlayingAudio(true);
      }
    } catch {}
  };

  const stopAudio = () => {
    try {
      magazineAudio.stop();
      setIsPlayingAudio(false);
      setActiveAudioArticle(null);
      setAudioProgress(0);
    } catch {}
  };

  const handleSetAudioProgress = (progress: number) => {
    try {
      setAudioProgress(progress);
      magazineAudio.seek(progress);
    } catch {}
  };

  const handleSetAudioSpeed = (speed: number) => {
    try {
      setAudioSpeed(speed);
      magazineAudio.setSpeed(speed);
    } catch {}
  };

  // Unified Sign-In with Google (identifies readers vs verified owners automatically)
  const signInWithGoogle = useCallback(async (): Promise<User | null> => {
    setAuthError(null);
    try {
      const credential = await signInWithPopup(auth, googleProvider);
      const fbUser = credential.user;
      const idToken = await fbUser.getIdToken();
      setAuthSession(idToken, fbUser.email);

      const [fsResult, apiResult] = await Promise.allSettled([
        syncUserSessionToFirestore(fbUser),
        api.syncFirebaseSession(idToken),
      ]);

      const fsUser = fsResult.status === 'fulfilled' ? fsResult.value : null;
      const apiSync = apiResult.status === 'fulfilled' ? apiResult.value : null;
      const fallbackUser = mapFirebaseUserFallback(fbUser);

      const resolved: User = apiSync?.user
        ? {
            ...fallbackUser,
            ...fsUser,
            ...apiSync.user,
            id: fbUser.uid,
            email: fbUser.email || apiSync.user.email || fallbackUser.email,
            avatar: fbUser.photoURL || apiSync.user.avatar || fsUser?.avatar,
          }
        : fsUser || fallbackUser;

      const verifiedOwner = Boolean(
        fbUser.email && isOwnerEmail(fbUser.email) && fbUser.emailVerified
      );
      if (verifiedOwner) {
        resolved.role = resolveRoleForEmail(fbUser.email);
        resolved.isPermanentOwner = true;
        resolved.status = 'ACTIVE';
      }

      setCurrentUser(resolved);
      return resolved;
    } catch (err: any) {
      const code = err?.code || '';
      let message = 'Unable to sign in right now. Please try again.';
      if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
        message = 'Sign-in window was closed before completing authentication.';
      } else if (code === 'auth/popup-blocked') {
        message = 'Pop-up was blocked by your browser. Please allow pop-ups for this site and try again.';
      } else if (code === 'auth/unauthorized-domain') {
        message = 'This domain is not yet authorized for sign-in. Contact the publication owner.';
      } else if (err?.message) {
        message = err.message;
      }
      setAuthError(message);
      return null;
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await signOut(auth);
    } catch {}
    api.logout();
    setCurrentUser(null);
    setAuthError(null);
  }, []);

  // Social Channels management methods
  const updateSocialChannels = async (newChannels: SocialChannel[]) => {
    setSocialChannels(newChannels);
    try {
      localStorage.setItem('tfp_social_channels', JSON.stringify(newChannels));
      await api.updateSocialChannels(newChannels);
    } catch {}
  };

  const updateSocialChannel = async (id: string, updates: Partial<SocialChannel>) => {
    const next = socialChannels.map((ch) => (ch.id === id ? { ...ch, ...updates } : ch));
    setSocialChannels(next);
    try {
      localStorage.setItem('tfp_social_channels', JSON.stringify(next));
      await api.updateSocialChannel(id, updates);
    } catch {}
  };

  const addSocialChannel = async (channelData: Omit<SocialChannel, 'id'>) => {
    const newChannel: SocialChannel = {
      ...channelData,
      id: `custom-channel-${Date.now()}`,
      order: (socialChannels.length || 0) + 1,
      isActive: channelData.isActive !== undefined ? channelData.isActive : true,
    };
    const next = [...socialChannels, newChannel];
    await updateSocialChannels(next);
  };

  const deleteSocialChannel = async (id: string) => {
    const next = socialChannels.filter((c) => c.id !== id);
    await updateSocialChannels(next);
  };

  const resetSocialChannels = async () => {
    await updateSocialChannels(DEFAULT_SOCIAL_CHANNELS);
  };

  // Editorial Section Derived helpers
  const publishedArticles = [...articles]
    .filter((a) => a.status === 'PUBLISHED' || !a.status)
    .sort((a, b) => {
      const timeA = new Date(a.publishedAt || a.updatedAt || a.createdAt || a.publishedDate || 0).getTime();
      const timeB = new Date(b.publishedAt || b.updatedAt || b.createdAt || b.publishedDate || 0).getTime();
      return (isNaN(timeB) ? 0 : timeB) - (isNaN(timeA) ? 0 : timeA);
    });

  const coverStory =
    (homepageLayout?.coverStoryId
      ? publishedArticles.find((a) => a.id === homepageLayout.coverStoryId)
      : null) ||
    publishedArticles.find((a) => a.isCoverStory) ||
    publishedArticles[0] ||
    articles[0];

  const mergeWithRecent = (baseList: Article[], maxItems = 6): Article[] => {
    const list: Article[] = [];
    const seen = new Set<string>();

    for (const art of baseList) {
      if (art && !seen.has(art.id) && (!coverStory || art.id !== coverStory.id)) {
        seen.add(art.id);
        list.push(art);
      }
    }

    for (const art of publishedArticles) {
      if (art && !seen.has(art.id) && (!coverStory || art.id !== coverStory.id)) {
        seen.add(art.id);
        list.push(art);
      }
    }

    return list.slice(0, maxItems);
  };

  const baseTrending = homepageLayout?.trendingStoryIds?.length
    ? homepageLayout.trendingStoryIds
        .map((id) => publishedArticles.find((a) => a.id === id))
        .filter((a): a is Article => Boolean(a))
    : publishedArticles.filter((a) => a.isTrending);
  const trendingStories = mergeWithRecent(baseTrending, 6);

  const baseFold = homepageLayout?.foldStoryIds?.length
    ? homepageLayout.foldStoryIds
        .map((id) => publishedArticles.find((a) => a.id === id))
        .filter((a): a is Article => Boolean(a))
    : publishedArticles.filter((a) => a.seriesName === 'THE FOLD' || a.isEditorsPick);
  const foldStories = mergeWithRecent(baseFold, 6);

  const basePopular = homepageLayout?.popularStoryIds?.length
    ? homepageLayout.popularStoryIds
        .map((id) => publishedArticles.find((a) => a.id === id))
        .filter((a): a is Article => Boolean(a))
    : [...publishedArticles].sort((a, b) => (a.popularityRank || 99) - (b.popularityRank || 99));
  const popularStories = mergeWithRecent(basePopular, 6);

  const uniqueStories = homepageLayout?.uniqueStoryIds?.length
    ? homepageLayout.uniqueStoryIds
        .map((id) => publishedArticles.find((a) => a.id === id))
        .filter((a): a is Article => Boolean(a))
    : publishedArticles.filter((a) => a.isUnique || a.category === 'Unique');

  const specialStories = homepageLayout?.specialStoryIds?.length
    ? homepageLayout.specialStoryIds
        .map((id) => publishedArticles.find((a) => a.id === id))
        .filter((a): a is Article => Boolean(a))
    : publishedArticles.filter((a) => a.isSpecial || a.category === 'Special');

  const baseEditorsPicks = homepageLayout?.editorsPickIds?.length
    ? homepageLayout.editorsPickIds
        .map((id) => publishedArticles.find((a) => a.id === id))
        .filter((a): a is Article => Boolean(a))
    : publishedArticles.filter((a) => a.isEditorsPick);
  const editorsPicks = mergeWithRecent(baseEditorsPicks, 4);

  const computedIsOwner = Boolean(currentUser && isOwnerRole(currentUser.role, currentUser.email));
  const computedIsStaff = Boolean(currentUser && isStaffRole(currentUser.role, currentUser.email));

  return (
    <MagazineContext.Provider
      value={{
        articles,
        categories,
        authors,
        deleteAuthor,
        series,
        issues,
        homepageLayout,
        isLoading,
        refreshArticles,
        refreshAll,
        coverStory,
        trendingStories: trendingStories.length > 0 ? trendingStories : publishedArticles.slice(0, 4),
        foldStories: foldStories.length > 0 ? foldStories : publishedArticles.slice(0, 4),
        popularStories: popularStories.length > 0 ? popularStories : publishedArticles.slice(0, 6),
        uniqueStories: uniqueStories.length > 0 ? uniqueStories : publishedArticles.slice(0, 3),
        specialStories: specialStories.length > 0 ? specialStories : publishedArticles.slice(0, 3),
        editorsPicks: editorsPicks.length > 0 ? editorsPicks : publishedArticles.slice(0, 3),
        savedStories,
        savedArticles,
        toggleSave,
        toggleSaveArticle,
        isSaved,
        isArticleSaved,
        clearSaved,
        readingHistory,
        addToHistory,
        isSearchOpen,
        setIsSearchOpen,
        isSavedDrawerOpen,
        setIsSavedDrawerOpen,
        isNewsletterOpen,
        setIsNewsletterOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authModalMode,
        setAuthModalMode,
        openAuthModal,
        closeAuthModal,
        shareArticle,
        setShareArticle,
        fontSize,
        setFontSize,
        readerTheme,
        setReaderTheme,
        activeAudioArticle,
        isPlayingAudio,
        playAudio,
        pauseAudio,
        toggleAudioPlay,
        stopAudio,
        audioProgress,
        setAudioProgress: handleSetAudioProgress,
        audioSpeed,
        setAudioSpeed: handleSetAudioSpeed,
        currentUser,
        isAuthReady,
        authError,
        clearAuthError,
        isAuthenticated: Boolean(currentUser),
        isOwner: computedIsOwner,
        isStaff: computedIsStaff,
        signInWithGoogle,
        logoutAdmin: logout,
        logout,
        socialChannels,
        updateSocialChannels,
        updateSocialChannel,
        addSocialChannel,
        deleteSocialChannel,
        resetSocialChannels,
        subscriberCount,
        refreshSubscribers,
      }}
    >
      {children}
    </MagazineContext.Provider>
  );
};

export const useMagazine = () => {
  const context = useContext(MagazineContext);
  if (!context) {
    throw new Error('useMagazine must be used within a MagazineProvider');
  }
  return context;
};
