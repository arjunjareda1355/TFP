import React, { useState, useEffect } from 'react';
import {
  Search,
  Bookmark,
  Menu,
  X,
  ArrowRight,
  Sparkles,
  BookOpen,
  Compass,
  Flame,
  TrendingUp,
  Mail,
  ShieldCheck,
  User,
  UserPlus,
  LogOut,
} from 'lucide-react';
import { useMagazine } from '../context/MagazineContext';
import { BrandLogo } from './BrandLogo';
import { CATEGORIES } from '../data/categories';
import { AdminTab } from './admin/AdminLayout';

interface NavbarProps {
  onNavigateHome: () => void;
  onNavigateCategory: (slug: string) => void;
  onNavigateToday: () => void;
  onNavigateExplore: () => void;
  onNavigateIssues: () => void;
  onNavigateSeries: () => void;
  onNavigateAbout: () => void;
  onNavigateSaved: () => void;
  onNavigateAdmin?: (tab?: AdminTab) => void;
  onNavigateNewsletter?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onNavigateHome,
  onNavigateCategory,
  onNavigateToday,
  onNavigateExplore,
  onNavigateIssues,
  onNavigateAbout,
  onNavigateSaved,
  onNavigateAdmin,
  onNavigateNewsletter,
}) => {
  const {
    savedStories,
    setIsSearchOpen,
    setIsNewsletterOpen,
    openAuthModal,
    isOwner,
    isAuthenticated,
    currentUser,
    logout,
  } = useMagazine();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMenuOpen) {
        setIsMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMenuOpen]);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMenuOpen]);

  const navLinks = [
    { label: 'Home', action: onNavigateHome },
    { label: 'Trending', action: () => onNavigateCategory('trending'), icon: Flame },
    { label: 'Popular', action: () => onNavigateCategory('popular'), icon: TrendingUp },
    { label: 'Unique', action: () => onNavigateCategory('unique'), icon: Sparkles },
    { label: 'Special', action: () => onNavigateCategory('special'), icon: Bookmark },
    { label: 'Explore', action: onNavigateExplore, icon: Compass },
    { label: 'Issues', action: onNavigateIssues, icon: BookOpen },
    { label: 'Today', action: onNavigateToday },
    { label: 'About', action: onNavigateAbout },
    {
      label: 'Newsletter',
      action: () => {
        if (onNavigateNewsletter) {
          onNavigateNewsletter();
        } else {
          setIsNewsletterOpen(true);
        }
      },
      icon: Mail,
    },
  ];

  const handleOpenOwnerDashboard = () => {
    setIsMenuOpen(false);
    if (onNavigateAdmin) {
      onNavigateAdmin('overview');
    } else {
      window.location.hash = '/admin/overview';
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 w-full transition-all duration-300 bg-[#FFFFFF]">
        {/* Top micro-bar */}
        <div className="bg-[#FAFAFA] text-[#55524B] text-[11px] py-1.5 px-4 sm:px-8 border-b border-[#E8E5DF] font-mono-editorial hidden md:flex justify-between items-center tracking-wide">
          <div className="flex items-center gap-4">
            <span className="font-semibold text-[#111110]">VOL. 04 — NO. 88</span>
            <span className="text-[#D4CEBF]">•</span>
            <span>AUGUST 31, 2026</span>
            <span className="text-[#D4CEBF]">•</span>
            <span className="text-[#111110] italic font-serif-editorial">"What's worth knowing."</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-[#736E65]">GLOBAL DIGITAL EDITION</span>
            <span className="text-[#D4CEBF]">•</span>
            <button
              id="top-bar-newsletter-btn"
              onClick={() => setIsNewsletterOpen(true)}
              className="text-[#111110] font-semibold hover:text-[#EA580C] transition-colors underline-offset-2 hover:underline flex items-center gap-1 whitespace-nowrap shrink-0"
            >
              <Mail className="w-3 h-3 text-[#EA580C]" />
              <span>Join The Folded Letter</span>
            </button>
          </div>
        </div>

        {/* Main navigation bar */}
        <div
          className={`w-full transition-all duration-300 border-b border-[#E8E5DF] bg-[#FFFFFF] ${
            isScrolled ? 'py-2.5 shadow-[0_4px_20px_rgba(0,0,0,0.06)]' : 'py-3.5 sm:py-4'
          }`}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-2">
            {/* Logo */}
            <div className="flex items-center gap-4 shrink-0">
              <button
                id="brand-logo-btn"
                onClick={() => {
                  onNavigateHome();
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="group flex items-center text-left focus:outline-none transition-opacity hover:opacity-90"
                title="The Folded Page — Home"
                aria-label="The Folded Page Home"
              >
                <BrandLogo variant="header-brand" size={isScrolled ? 34 : 40} theme="light" />
              </button>
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden xl:flex items-center space-x-0.5 text-xs font-semibold uppercase tracking-wider text-[#55524B]">
              {navLinks.map((item, idx) => (
                <button
                  key={idx}
                  id={`nav-link-${item.label.toLowerCase()}`}
                  onClick={() => {
                    item.action();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-2 py-1.5 rounded-xs transition-colors text-[#55524B] hover:text-[#111110] hover:bg-[#F5F4F0] whitespace-nowrap shrink-0"
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Right Action Controls */}
            <div className="flex items-center gap-2 shrink-0">
              {/* Search Trigger */}
              <button
                id="search-trigger-btn"
                onClick={() => setIsSearchOpen(true)}
                className="px-2.5 py-1.5 text-[#55524B] hover:text-[#111110] hover:bg-[#F5F4F0] transition-colors rounded-xs border border-[#E8E5DF] hover:border-[#111110] flex items-center gap-1.5 text-xs font-medium group whitespace-nowrap shrink-0"
                title="Search The Folded Page (Ctrl + K)"
                aria-label="Search articles"
              >
                <Search className="w-3.5 h-3.5 text-[#6E6A62] group-hover:text-[#111110]" />
                <span className="hidden sm:inline text-[11px] font-mono-editorial">Search</span>
                <kbd className="hidden md:inline-flex items-center text-[9px] font-mono text-[#8E8A81] bg-[#F5F4F0] px-1 py-0.5 rounded-xs border border-[#E8E5DF]">
                  ⌘K
                </kbd>
              </button>

              {/* Saved Stories Trigger */}
              <button
                id="saved-stories-trigger-btn"
                onClick={onNavigateSaved}
                className="p-2 text-[#55524B] hover:text-[#111110] hover:bg-[#F5F4F0] transition-colors rounded-xs relative border border-[#E8E5DF] shrink-0"
                title="Saved Stories"
                aria-label="Saved Stories"
              >
                <Bookmark className="w-4 h-4" />
                {savedStories.length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 px-1 bg-[#EA580C] text-white text-[9px] font-mono-editorial font-bold rounded-xs flex items-center justify-center tabular-nums">
                    {savedStories.length}
                  </span>
                )}
              </button>

              {/* Header Authentication Controls */}
              {!isAuthenticated ? (
                <div className="hidden md:flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    id="header-signin-btn"
                    onClick={() => openAuthModal('login')}
                    className="inline-flex items-center gap-1.5 text-xs font-mono-editorial text-[#111110] hover:bg-[#F5F4F0] px-2.5 py-1.5 border border-[#E8E5DF] hover:border-[#111110] rounded-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <User className="w-3.5 h-3.5 text-[#55524B]" />
                    <span>Sign In</span>
                  </button>
                  <button
                    type="button"
                    id="header-signup-btn"
                    onClick={() => openAuthModal('signup')}
                    className="inline-flex items-center gap-1.5 text-xs font-mono-editorial font-semibold bg-[#111110] hover:bg-[#EA580C] text-white px-2.5 py-1.5 rounded-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Sign Up</span>
                  </button>
                </div>
              ) : (
                <div className="hidden md:flex items-center gap-2 shrink-0">
                  {isOwner && (
                    <button
                      type="button"
                      id="header-owner-dashboard-btn"
                      onClick={handleOpenOwnerDashboard}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-[#FFF7ED] hover:bg-[#FFEDD5] border border-[#FED7AA] text-[#C2410C] text-[11px] font-mono-editorial font-bold uppercase tracking-wider rounded-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-[#EA580C]" />
                      <span>Owner Desk</span>
                    </button>
                  )}

                  <div className="flex items-center gap-2 pl-1.5 border-l border-[#E8E5DF]">
                    {currentUser?.avatar ? (
                      <img
                        src={currentUser.avatar}
                        alt={currentUser.name}
                        referrerPolicy="no-referrer"
                        className="w-7 h-7 rounded-full object-cover border border-[#E8E5DF] shrink-0"
                      />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-[#111110] text-white flex items-center justify-center text-xs font-bold font-serif-editorial shrink-0">
                        {currentUser?.name?.charAt(0) || 'R'}
                      </div>
                    )}
                    <button
                      type="button"
                      id="header-signout-btn"
                      onClick={() => {
                        logout();
                      }}
                      className="inline-flex items-center gap-1 text-[11px] font-mono-editorial text-[#55524B] hover:text-[#DC2626] px-2 py-1 border border-[#E8E5DF] hover:border-[#FECACA] rounded-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
                    >
                      <LogOut className="w-3 h-3" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Header Subscribe Button */}
              <button
                id="header-subscribe-btn"
                type="button"
                onClick={() => setIsNewsletterOpen(true)}
                className="hidden lg:inline-flex items-center gap-1.5 bg-[#EA580C] hover:bg-[#C2410C] text-white text-xs font-semibold uppercase tracking-wider px-3 py-1.5 transition-colors rounded-xs cursor-pointer whitespace-nowrap shrink-0"
                title="Subscribe to The Folded Letter"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Subscribe</span>
              </button>

              {/* Site Menu Toggle */}
              <button
                id="three-line-menu-toggle"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className={`p-2 transition-colors rounded-xs border shrink-0 ${
                  isMenuOpen
                    ? 'bg-[#111110] text-white border-[#111110]'
                    : 'bg-[#F9F8F6] text-[#111110] border-[#E8E5DF] hover:bg-[#EAE8E2]'
                }`}
                title="Open Site Menu"
                aria-label="Toggle Complete Navigation Menu"
                aria-expanded={isMenuOpen}
              >
                {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Slide-over Full Site Menu Drawer */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
            onClick={() => setIsMenuOpen(false)}
            aria-hidden="true"
          />

          <div className="relative ml-auto w-full max-w-md bg-[#FFFFFF] border-l border-[#E8E5DF] h-full overflow-y-auto p-6 sm:p-8 flex flex-col justify-between z-10 shadow-2xl">
            <div>
              {/* Drawer Top Bar */}
              <div className="flex items-center justify-between pb-5 border-b border-[#E8E5DF] mb-5">
                <BrandLogo variant="header-brand" size={34} theme="light" />
                <button
                  onClick={() => setIsMenuOpen(false)}
                  className="p-2 text-[#55524B] hover:text-[#111110] bg-[#F5F4F0] hover:bg-[#EAE8E2] transition-colors rounded-xs"
                  aria-label="Close navigation drawer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Site Menu Account & Sign In / Sign Up Panel */}
              <div className="mb-6 p-4 bg-[#FAF9F6] border border-[#E8E5DF] rounded-xs">
                {isAuthenticated && currentUser ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5 min-w-0">
                        {currentUser.avatar ? (
                          <img
                            src={currentUser.avatar}
                            alt={currentUser.name}
                            referrerPolicy="no-referrer"
                            className="w-9 h-9 rounded-full object-cover border border-[#E8E5DF] shrink-0"
                          />
                        ) : (
                          <div className="w-9 h-9 rounded-full bg-[#111110] text-white flex items-center justify-center text-sm font-bold font-serif-editorial shrink-0">
                            {currentUser.name?.charAt(0) || 'R'}
                          </div>
                        )}
                        <div className="min-w-0">
                          <span className="text-sm font-medium text-[#111110] block truncate">
                            {currentUser.name}
                          </span>
                          <span className="text-[11px] font-mono-editorial text-[#6E6A62] block truncate">
                            {currentUser.email}
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        id="menu-signout-btn"
                        onClick={() => {
                          logout();
                          setIsMenuOpen(false);
                        }}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-[#FFFFFF] border border-[#E8E5DF] hover:border-[#DC2626] text-[11px] font-mono-editorial text-[#55524B] hover:text-[#DC2626] rounded-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
                      >
                        <LogOut className="w-3 h-3" />
                        <span>Sign Out</span>
                      </button>
                    </div>

                    <div className="pt-2.5 border-t border-[#E8E5DF] flex items-center justify-between text-[11px] font-mono-editorial">
                      <span className="text-[#6E6A62] uppercase">Account Status</span>
                      <span className={`font-bold uppercase ${isOwner ? 'text-[#EA580C]' : 'text-[#111110]'}`}>
                        {isOwner ? 'Publication Owner' : 'Reader'}
                      </span>
                    </div>

                    {/* Owner Dashboard Button — strictly visible ONLY for authenticated owner emails */}
                    {isOwner && (
                      <button
                        type="button"
                        id="menu-staff-cms-desk-button"
                        onClick={handleOpenOwnerDashboard}
                        className="w-full flex items-center justify-between p-3 bg-[#111110] hover:bg-[#EA580C] text-white rounded-xs transition-colors text-left cursor-pointer"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <ShieldCheck className="w-4 h-4 text-[#F59E0B] shrink-0" />
                          <div className="min-w-0">
                            <span className="text-xs font-mono-editorial font-bold uppercase tracking-wider block">
                              Owner Dashboard
                            </span>
                            <span className="text-[11px] text-[#D4CEBF] font-sans-editorial block truncate">
                              Manage stories, users & publication settings
                            </span>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 shrink-0" />
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div>
                      <span className="text-[10px] font-mono-editorial font-bold uppercase tracking-wider text-[#6E6A62] block">
                        Member & Owner Access
                      </span>
                      <p className="text-xs text-[#55524B] mt-0.5 font-sans-editorial">
                        Sign in or create an account to sync saved reading lists. Owner emails unlock the Owner Dashboard automatically.
                      </p>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        id="menu-signin-btn"
                        onClick={() => {
                          setIsMenuOpen(false);
                          openAuthModal('login');
                        }}
                        className="flex items-center justify-center gap-1.5 py-2 px-3 bg-[#FFFFFF] hover:bg-[#F0EDE6] border border-[#E8E5DF] hover:border-[#111110] text-[#111110] text-xs font-mono-editorial uppercase font-semibold rounded-xs transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <User className="w-3.5 h-3.5" />
                        <span>Sign In</span>
                      </button>
                      <button
                        type="button"
                        id="menu-signup-btn"
                        onClick={() => {
                          setIsMenuOpen(false);
                          openAuthModal('signup');
                        }}
                        className="flex items-center justify-center gap-1.5 py-2 px-3 bg-[#111110] hover:bg-[#EA580C] text-white text-xs font-mono-editorial uppercase font-semibold rounded-xs transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Sign Up</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Search Bar */}
              <div className="mb-6">
                <button
                  onClick={() => {
                    setIsMenuOpen(false);
                    setIsSearchOpen(true);
                  }}
                  className="w-full flex items-center justify-between px-3.5 py-2.5 bg-[#F9F8F6] border border-[#E8E5DF] hover:border-[#111110] rounded-xs text-left transition-colors group"
                >
                  <div className="flex items-center gap-2.5 text-xs text-[#6E6A62]">
                    <Search className="w-4 h-4 text-[#EA580C]" />
                    <span className="font-serif-editorial text-sm text-[#111110]">Search all stories & topics...</span>
                  </div>
                  <kbd className="text-[10px] font-mono bg-[#FFFFFF] px-1.5 py-0.5 rounded-xs border border-[#E8E5DF] text-[#8E8A81]">
                    ⌘K
                  </kbd>
                </button>
              </div>

              {/* Editorial Sections */}
              <div className="space-y-1 mb-6">
                <span className="text-[11px] font-mono-editorial font-bold uppercase text-[#8E8A81] tracking-wider block mb-2 px-2">
                  Editorial Sections
                </span>
                {navLinks.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        item.action();
                        setIsMenuOpen(false);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="w-full flex items-center justify-between px-3 py-2 text-left font-serif-editorial text-lg rounded-xs text-[#111110] hover:bg-[#F5F4F0] hover:text-[#EA580C] transition-colors group"
                    >
                      <span className="flex items-center gap-3">
                        {Icon && <Icon className="w-4 h-4 text-[#EA580C]" />}
                        <span className="font-medium">{item.label}</span>
                      </span>
                      <span className="text-xs font-mono-editorial text-[#A8A49C] group-hover:text-[#EA580C] tabular-nums">
                        0{idx + 1}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Topics Grid */}
              <div className="pt-4 border-t border-[#E8E5DF] mb-6">
                <span className="text-[11px] font-mono-editorial font-bold uppercase text-[#8E8A81] tracking-wider block mb-3 px-2">
                  Browse by Subject
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {CATEGORIES.slice(0, 8).map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        onNavigateCategory(cat.slug);
                        setIsMenuOpen(false);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="text-left px-3 py-2 bg-[#F9F8F6] hover:bg-[#F0EDE6] rounded-xs text-xs text-[#111110] hover:text-[#EA580C] transition-colors border border-[#E8E5DF] truncate"
                    >
                      <span className="font-medium">{cat.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom Drawer Newsletter & Copyright */}
            <div className="pt-4 border-t border-[#E8E5DF] space-y-3">
              <div className="space-y-1.5">
                <button
                  type="button"
                  id="menu-subscribe-button"
                  onClick={() => {
                    setIsMenuOpen(false);
                    setIsNewsletterOpen(true);
                  }}
                  className="w-full bg-[#EA580C] hover:bg-[#C2410C] text-white py-3 text-center text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 rounded-xs transition-colors cursor-pointer"
                >
                  <Mail className="w-4 h-4" />
                  <span>Subscribe to The Folded Letter</span>
                </button>
                {onNavigateNewsletter && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsMenuOpen(false);
                      onNavigateNewsletter();
                    }}
                    className="w-full text-center text-[11px] text-[#6E6A62] hover:text-[#EA580C] font-mono-editorial transition-colors py-1 cursor-pointer"
                  >
                    Or read past dispatches archive &rarr;
                  </button>
                )}
              </div>

              <div className="flex items-center justify-between text-xs text-[#6E6A62] font-mono-editorial pt-1 px-1">
                <span>The Folded Page © 2026</span>
                <span className="text-[#EA580C]">What's worth knowing.</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
