import React, { useEffect, useState } from 'react';
import { X, AlertCircle, ShieldCheck, Loader2, ArrowRight, BookmarkCheck } from 'lucide-react';
import { useMagazine } from '../../context/MagazineContext';
import { BrandLogo } from '../BrandLogo';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalMode,
    setAuthModalMode,
    currentUser,
    isOwner,
    signInWithGoogle,
    authError,
    clearAuthError,
  } = useMagazine();

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Handle ESC key and scroll lock
  useEffect(() => {
    if (!isAuthModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeAuthModal();
    };
    window.addEventListener('keydown', handleKeyDown);
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = originalOverflow;
    };
  }, [isAuthModalOpen, closeAuthModal]);

  const handleGoogleContinue = async () => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    try {
      const user = await signInWithGoogle();
      if (user) {
        // Brief pause if owner so user sees confirmation, otherwise close cleanly
        const isUserOwner =
          user.isPermanentOwner ||
          user.role === 'EDITORIAL_OWNER' ||
          user.role === 'OPERATIONS_OWNER' ||
          user.role === 'OWNER';
        if (!isUserOwner) {
          closeAuthModal();
        }
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isAuthModalOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 bg-[#111110]/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeAuthModal();
      }}
    >
      <div
        className="relative w-full max-w-[420px] my-auto bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs shadow-2xl overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-labelledby="auth-modal-heading"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={closeAuthModal}
          className="absolute top-3.5 right-3.5 p-1.5 text-[#8E8A81] hover:text-[#111110] hover:bg-[#F5F4F0] rounded-xs transition-colors cursor-pointer z-10"
          aria-label="Close sign in dialog"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="pt-6 pb-4 px-6 text-center bg-[#FAF9F6] border-b border-[#E8E5DF]">
          <div className="flex justify-center mb-3">
            <BrandLogo variant="header-brand" size={32} theme="light" />
          </div>

          <div className="flex bg-[#EFECE6] p-0.5 rounded-xs max-w-[240px] mx-auto">
            <button
              type="button"
              id="auth-tab-login"
              onClick={() => {
                setAuthModalMode('login');
                clearAuthError();
              }}
              className={`flex-1 py-1.5 text-xs font-mono-editorial uppercase tracking-wider font-semibold transition-colors rounded-xs cursor-pointer whitespace-nowrap ${
                authModalMode === 'login'
                  ? 'bg-[#FFFFFF] text-[#111110]'
                  : 'text-[#6E6A62] hover:text-[#111110]'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              id="auth-tab-signup"
              onClick={() => {
                setAuthModalMode('signup');
                clearAuthError();
              }}
              className={`flex-1 py-1.5 text-xs font-mono-editorial uppercase tracking-wider font-semibold transition-colors rounded-xs cursor-pointer whitespace-nowrap ${
                authModalMode === 'signup'
                  ? 'bg-[#FFFFFF] text-[#111110]'
                  : 'text-[#6E6A62] hover:text-[#111110]'
              }`}
            >
              Sign Up
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {currentUser ? (
            <div className="space-y-4 text-center">
              <div className="flex items-center justify-center">
                {currentUser.avatar ? (
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full object-cover border border-[#E8E5DF]"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-[#111110] text-white flex items-center justify-center font-serif-editorial text-lg font-bold">
                    {currentUser.name?.charAt(0) || 'R'}
                  </div>
                )}
              </div>

              <div>
                <h2 id="auth-modal-heading" className="font-serif-editorial text-xl font-medium text-[#111110]">
                  Signed in as {currentUser.name}
                </h2>
                <p className="text-xs font-mono-editorial text-[#6E6A62] mt-1">
                  {currentUser.email}
                </p>
                <p className="text-[11px] font-mono-editorial uppercase tracking-wider text-[#EA580C] font-semibold mt-2">
                  {isOwner ? 'Verified Publication Owner' : 'Reader Account Active'}
                </p>
              </div>

              <div className="pt-2 space-y-2">
                {isOwner && (
                  <button
                    type="button"
                    onClick={() => {
                      closeAuthModal();
                      window.location.hash = '/admin/overview';
                    }}
                    className="w-full py-2.5 bg-[#111110] hover:bg-[#EA580C] text-white text-xs font-mono-editorial uppercase tracking-wider font-semibold rounded-xs transition-colors flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>Open Owner Dashboard</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={closeAuthModal}
                  className="w-full py-2 border border-[#E8E5DF] hover:bg-[#F9F8F6] text-[#111110] text-xs font-mono-editorial uppercase tracking-wider font-semibold rounded-xs transition-colors cursor-pointer"
                >
                  Continue Reading
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="text-center space-y-1.5">
                <h2 id="auth-modal-heading" className="font-serif-editorial text-xl font-medium text-[#111110]">
                  {authModalMode === 'login' ? 'Welcome Back to The Folded Page' : 'Create Your Reader Account'}
                </h2>
                <p className="text-xs text-[#6E6A62] leading-relaxed font-sans-editorial">
                  {authModalMode === 'login'
                    ? 'Sign in with Google to sync your saved stories and reading history. Publication owners receive direct dashboard access automatically.'
                    : 'Join with Google in one step to save stories across devices and manage your reading library.'}
                </p>
              </div>

              {authError && (
                <div className="p-3 bg-[#FEF2F2] border border-[#FECACA] rounded-xs flex items-start gap-2 text-xs text-[#DC2626]">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="leading-snug">{authError}</span>
                </div>
              )}

              <button
                type="button"
                id="auth-google-continue-btn"
                onClick={handleGoogleContinue}
                disabled={isSubmitting}
                className="w-full py-3 px-4 bg-[#111110] hover:bg-[#EA580C] disabled:opacity-60 text-white text-xs font-mono-editorial uppercase tracking-wider font-semibold rounded-xs transition-colors flex items-center justify-center gap-2.5 cursor-pointer whitespace-nowrap"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                    <span>Authenticating...</span>
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        fill="#FFFFFF"
                        d="M21.35 11.1h-9.17v2.73h6.51c-.33 3.81-3.5 5.44-6.5 5.44C8.36 19.27 5 16.25 5 12c0-4.1 3.2-7.27 7.2-7.27 3.09 0 4.9 1.97 4.9 1.97L19 4.72S16.56 2 12.1 2C6.42 2 2.03 6.8 2.03 12c0 5.05 4.13 10 10.22 10 5.35 0 9.25-3.67 9.25-9.09 0-1.15-.15-1.81-.15-1.81z"
                      />
                    </svg>
                    <span>
                      {authModalMode === 'login' ? 'Sign In with Google' : 'Sign Up with Google'}
                    </span>
                  </>
                )}
              </button>

              <div className="pt-3 border-t border-[#E8E5DF] space-y-2 text-[11px] font-sans-editorial text-[#6E6A62]">
                <div className="flex items-start gap-2">
                  <BookmarkCheck className="w-3.5 h-3.5 text-[#EA580C] shrink-0 mt-0.5" />
                  <span>Saved stories and reading progress stay synced to your profile.</span>
                </div>
                <div className="flex items-start gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#111110] shrink-0 mt-0.5" />
                  <span>Authorized owner accounts unlock the Owner Dashboard upon sign-in.</span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
