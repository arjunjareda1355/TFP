import React, { useEffect, useState, Component, ErrorInfo, ReactNode } from 'react';
import { X, AlertCircle, RefreshCw, Mail, KeyRound, Shield, Loader2, ArrowRight } from 'lucide-react';
import { SignIn, SignUp } from '@clerk/clerk-react';
import { useMagazine } from '../../context/MagazineContext';
import { BrandLogo } from '../BrandLogo';

interface ClerkModalErrorBoundaryProps {
  children: ReactNode;
  onFallbackToDirect?: () => void;
}

interface ClerkModalErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
}

class ClerkModalErrorBoundary extends Component<ClerkModalErrorBoundaryProps, ClerkModalErrorBoundaryState> {
  public override state: ClerkModalErrorBoundaryState = {
    hasError: false,
    errorMessage: '',
  };

  public static getDerivedStateFromError(error: Error): ClerkModalErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: error?.message || 'Unable to load Clerk authentication.',
    };
  }

  public override componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.warn('[AuthModal] Clerk notice:', error, errorInfo);
  }

  public override render() {
    if (this.state.hasError) {
      return (
        <div className="p-4 sm:p-5 bg-[#FAF9F6] border border-[#E8E5DF] rounded-xs text-center space-y-2.5 my-2 w-full">
          <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#FFF7ED] text-[#EA580C]">
            <AlertCircle className="w-4 h-4" />
          </div>
          <h3 className="text-xs font-serif-editorial font-bold text-[#111110]">
            Clerk Authentication Notice
          </h3>
          <p className="text-[11px] font-serif-editorial text-[#55524B] leading-relaxed max-w-xs mx-auto">
            {this.state.errorMessage}
          </p>
          <div className="flex flex-col gap-1.5 pt-1">
            {this.props.onFallbackToDirect && (
              <button
                type="button"
                onClick={this.props.onFallbackToDirect}
                className="w-full py-2 bg-[#111110] hover:bg-[#EA580C] text-white text-[11px] font-mono-editorial uppercase tracking-wider font-semibold rounded-xs transition-colors cursor-pointer inline-flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Continue with Email & Password</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => this.setState({ hasError: false, errorMessage: '' })}
              className="w-full py-1.5 text-[#6E6A62] hover:text-[#111110] text-[11px] font-mono-editorial inline-flex items-center justify-center gap-1 cursor-pointer transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry Clerk</span>
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalMode,
    setAuthModalMode,
    currentUser,
    loginAsAdmin,
    registerUser,
  } = useMagazine();

  const [authMethod, setAuthMethod] = useState<'clerk' | 'email'>('clerk');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [nameInput, setNameInput] = useState('');
  const [directLoading, setDirectLoading] = useState(false);
  const [directError, setDirectError] = useState('');

  // Close modal if already authenticated
  useEffect(() => {
    if (currentUser && isAuthModalOpen) {
      const timer = setTimeout(() => {
        closeAuthModal();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [currentUser, isAuthModalOpen, closeAuthModal]);

  // Handle ESC key and scroll lock
  useEffect(() => {
    if (!isAuthModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeAuthModal();
    };
    window.addEventListener('keydown', handleKeyDown);
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = originalOverflow;
    };
  }, [isAuthModalOpen, closeAuthModal]);

  const handleDirectAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput.trim()) {
      setDirectError('Please enter an email address');
      return;
    }
    setDirectError('');
    setDirectLoading(true);

    try {
      if (authModalMode === 'login') {
        await loginAsAdmin(emailInput.trim(), passwordInput);
      } else {
        await registerUser({
          email: emailInput.trim(),
          name: nameInput.trim() || undefined,
          password: passwordInput || undefined,
        });
      }
      closeAuthModal();
    } catch (err: any) {
      setDirectError(err?.message || 'Authentication failed. Please verify your credentials.');
    } finally {
      setDirectLoading(false);
    }
  };

  if (!isAuthModalOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-2.5 sm:p-4 bg-[#111110]/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeAuthModal();
      }}
    >
      {/* Modal Container: responsive to all device screen sizes */}
      <div
        className="relative w-full max-w-[420px] my-auto max-h-[calc(100dvh-1.5rem)] flex flex-col bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={closeAuthModal}
          className="absolute top-3 right-3 p-1.5 text-[#8E8A81] hover:text-[#111110] hover:bg-[#F5F4F0] rounded-xs transition-colors cursor-pointer z-20"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="shrink-0 pt-5 pb-3 px-4 sm:px-6 text-center bg-[#FAF9F6] border-b border-[#E8E5DF]">
          <div className="flex justify-center mb-2.5">
            <BrandLogo />
          </div>

          {/* Mode Switcher Tabs (Sign In vs Create Account) */}
          <div className="flex bg-[#EFECE6] p-0.5 rounded-xs max-w-[240px] mx-auto mb-2">
            <button
              type="button"
              id="auth-tab-login"
              onClick={() => {
                setAuthModalMode('login');
                setDirectError('');
              }}
              className={`flex-1 py-1 text-xs font-mono-editorial uppercase tracking-wider font-semibold transition-all rounded-xs cursor-pointer ${
                authModalMode === 'login'
                  ? 'bg-white text-[#111110] shadow-xs'
                  : 'text-[#6E6A62] hover:text-[#111110]'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              id="auth-tab-signup"
              onClick={() => {
                setAuthModalMode('signup');
                setDirectError('');
              }}
              className={`flex-1 py-1 text-xs font-mono-editorial uppercase tracking-wider font-semibold transition-all rounded-xs cursor-pointer ${
                authModalMode === 'signup'
                  ? 'bg-white text-[#111110] shadow-xs'
                  : 'text-[#6E6A62] hover:text-[#111110]'
              }`}
            >
              Create Account
            </button>
          </div>

          {/* Method selector: Clerk vs Direct Email */}
          <div className="flex justify-center gap-2 text-[10px] font-mono-editorial uppercase text-[#8E8A81]">
            <button
              type="button"
              onClick={() => setAuthMethod('clerk')}
              className={`pb-0.5 border-b transition-colors cursor-pointer flex items-center gap-1 ${
                authMethod === 'clerk'
                  ? 'border-[#111110] text-[#111110] font-bold'
                  : 'border-transparent hover:text-[#111110]'
              }`}
            >
              <Shield className="w-3 h-3" />
              <span>Clerk SSO</span>
            </button>
            <span>•</span>
            <button
              type="button"
              onClick={() => setAuthMethod('email')}
              className={`pb-0.5 border-b transition-colors cursor-pointer flex items-center gap-1 ${
                authMethod === 'email'
                  ? 'border-[#111110] text-[#111110] font-bold'
                  : 'border-transparent hover:text-[#111110]'
              }`}
            >
              <Mail className="w-3 h-3" />
              <span>Email & Password</span>
            </button>
          </div>
        </div>

        {/* Modal Body with proper scrolling */}
        <div className="flex-1 overflow-y-auto overscroll-contain p-3.5 sm:p-5 flex flex-col justify-start items-center">
          {authMethod === 'clerk' ? (
            <div className="w-full max-w-full flex flex-col justify-center">
              <ClerkModalErrorBoundary onFallbackToDirect={() => setAuthMethod('email')}>
                {authModalMode === 'login' ? (
                  <SignIn
                    routing="virtual"
                    fallbackRedirectUrl="/"
                    appearance={{
                      elements: {
                        rootBox: 'w-full max-w-full flex justify-center mx-auto',
                        cardBox: 'w-full max-w-full shadow-none flex justify-center mx-auto',
                        card: 'border-0 shadow-none p-0 w-full max-w-full bg-transparent mx-auto',
                        socialButtonsBlockButton:
                          'w-full rounded-xs border border-[#E8E5DF] hover:bg-[#F5F4F0] text-xs transition-colors py-2',
                        formButtonPrimary:
                          'w-full bg-[#111110] hover:bg-[#EA580C] text-xs font-semibold rounded-xs shadow-xs transition-colors py-2.5',
                        footerActionLink: 'text-[#EA580C] hover:text-[#C2410C]',
                      },
                    }}
                  />
                ) : (
                  <SignUp
                    routing="virtual"
                    fallbackRedirectUrl="/"
                    appearance={{
                      elements: {
                        rootBox: 'w-full max-w-full flex justify-center mx-auto',
                        cardBox: 'w-full max-w-full shadow-none flex justify-center mx-auto',
                        card: 'border-0 shadow-none p-0 w-full max-w-full bg-transparent mx-auto',
                        socialButtonsBlockButton:
                          'w-full rounded-xs border border-[#E8E5DF] hover:bg-[#F5F4F0] text-xs transition-colors py-2',
                        formButtonPrimary:
                          'w-full bg-[#111110] hover:bg-[#EA580C] text-xs font-semibold rounded-xs shadow-xs transition-colors py-2.5',
                        footerActionLink: 'text-[#EA580C] hover:text-[#C2410C]',
                      },
                    }}
                  />
                )}
              </ClerkModalErrorBoundary>

              <div className="mt-3 pt-2 text-center border-t border-[#E8E5DF]/60">
                <button
                  type="button"
                  onClick={() => setAuthMethod('email')}
                  className="text-[10px] text-[#8E8A81] hover:text-[#EA580C] font-mono-editorial inline-flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>Or use email and password</span>
                  <ArrowRight className="w-2.5 h-2.5" />
                </button>
              </div>
            </div>
          ) : (
            /* Email & Password Direct Option */
            <form onSubmit={handleDirectAuthSubmit} className="w-full space-y-3">
              {authModalMode === 'signup' && (
                <div>
                  <label className="block text-[11px] font-mono-editorial uppercase text-[#55524B] mb-1 font-semibold">
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    placeholder="E.g. Elena Vance"
                    className="w-full text-xs px-3 py-2 border border-[#E8E5DF] rounded-xs bg-[#F9F8F6] focus:bg-white focus:border-[#EA580C] outline-none"
                  />
                </div>
              )}

              <div>
                <label className="block text-[11px] font-mono-editorial uppercase text-[#55524B] mb-1 font-semibold">
                  Email Address
                </label>
                <input
                  type="email"
                  value={emailInput}
                  onChange={(e) => {
                    setEmailInput(e.target.value);
                    setDirectError('');
                  }}
                  placeholder="reader@example.com"
                  className="w-full text-xs font-mono px-3 py-2 border border-[#E8E5DF] rounded-xs bg-[#F9F8F6] focus:bg-white focus:border-[#EA580C] outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono-editorial uppercase text-[#55524B] mb-1 font-semibold">
                  Password / Passcode
                </label>
                <input
                  type="password"
                  value={passwordInput}
                  onChange={(e) => {
                    setPasswordInput(e.target.value);
                    setDirectError('');
                  }}
                  placeholder="Enter your password"
                  className="w-full text-xs font-mono px-3 py-2 border border-[#E8E5DF] rounded-xs bg-[#F9F8F6] focus:bg-white focus:border-[#EA580C] outline-none"
                  required
                />
              </div>

              {directError && (
                <div className="p-2 bg-[#FEF2F2] border border-[#FECACA] rounded-xs flex items-center gap-2 text-xs text-[#DC2626]">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span className="leading-snug">{directError}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={directLoading}
                className="w-full py-2.5 bg-[#111110] hover:bg-[#EA580C] text-white text-xs font-mono-editorial uppercase tracking-wider font-semibold rounded-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs disabled:opacity-50"
              >
                {directLoading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>{authModalMode === 'login' ? 'Sign In' : 'Create Account'}</span>
                  </>
                )}
              </button>

              <div className="text-center pt-1.5 border-t border-[#E8E5DF]/60">
                <button
                  type="button"
                  onClick={() => setAuthMethod('clerk')}
                  className="text-[10px] text-[#8E8A81] hover:text-[#EA580C] font-mono-editorial inline-flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>Switch back to Clerk SSO</span>
                  <ArrowRight className="w-2.5 h-2.5" />
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
