import React, { useState } from 'react';

export interface BrandLogoProps {
  variant?: 'masthead' | 'header-brand' | 'full' | 'horizontal' | 'emblem' | 'wordmark';
  theme?: 'light' | 'dark' | 'cream' | 'monochrome';
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number;
  showTagline?: boolean;
  className?: string;
  id?: string;
}

const LOCAL_LOGO_SRC = '/brand-logo.png';
const REMOTE_LOGO_FALLBACK = 'https://i.postimg.cc/LsD9MLtx/logo-2-outline-serif.png';

const LOCAL_WORDMARK_SRC = '/brand-wordmark.png';
const REMOTE_WORDMARK_FALLBACK = 'https://i.postimg.cc/1zBmZwG7/wm-C-two-tone-bodoni.png';

export const BrandLogo: React.FC<BrandLogoProps> = ({
  variant = 'header-brand',
  theme = 'light',
  size = 'md',
  className = '',
  id,
}) => {
  const isDark = theme === 'dark';
  const [logoSrc, setLogoSrc] = useState(LOCAL_LOGO_SRC);
  const [wordmarkSrc, setWordmarkSrc] = useState(LOCAL_WORDMARK_SRC);

  const getEmblemDimension = (): number => {
    if (typeof size === 'number') return size;
    switch (size) {
      case 'xs':
        return 22;
      case 'sm':
        return 32;
      case 'md':
        return 42;
      case 'lg':
        return 64;
      case 'xl':
        return 96;
      default:
        return 42;
    }
  };

  const getWordmarkHeight = (): number => {
    if (typeof size === 'number') return Math.max(28, Math.round(size * 1.15));
    switch (size) {
      case 'xs':
        return 28;
      case 'sm':
        return 38;
      case 'md':
        return 48;
      case 'lg':
        return 68;
      case 'xl':
        return 96;
      default:
        return 48;
    }
  };

  const renderEmblem = (dim: number, customClass: string = '') => (
    <img
      src={logoSrc}
      alt="The Folded Page logo"
      referrerPolicy="no-referrer"
      draggable={false}
      width={dim}
      height={dim}
      onError={() => {
        if (logoSrc !== REMOTE_LOGO_FALLBACK) {
          setLogoSrc(REMOTE_LOGO_FALLBACK);
        }
      }}
      onContextMenu={(e) => e.preventDefault()}
      style={{ width: dim, height: dim }}
      className={`object-contain shrink-0 select-none brand-emblem no-copy ${
        isDark ? 'brightness-0 invert' : ''
      } ${customClass}`}
    />
  );

  const renderWordmark = (height: number, customClass: string = '') => (
    <img
      src={wordmarkSrc}
      alt="The Folded Page — What's Worth Knowing"
      referrerPolicy="no-referrer"
      draggable={false}
      onError={() => {
        if (wordmarkSrc !== REMOTE_WORDMARK_FALLBACK) {
          setWordmarkSrc(REMOTE_WORDMARK_FALLBACK);
        }
      }}
      onContextMenu={(e) => e.preventDefault()}
      style={{ height }}
      className={`w-auto max-w-full object-contain shrink-0 select-none brand-masthead no-copy pointer-events-none ${
        isDark ? 'brightness-0 invert' : ''
      } ${customClass}`}
    />
  );

  const emblemDim = getEmblemDimension();
  const wordmarkHeight = getWordmarkHeight();

  // Emblem only
  if (variant === 'emblem') {
    return (
      <div
        id={id}
        className={`inline-flex items-center justify-center select-none brand-logo no-copy ${className}`}
        draggable={false}
        onContextMenu={(e) => e.preventDefault()}
      >
        {renderEmblem(emblemDim)}
      </div>
    );
  }

  // Masthead wordmark lockup
  if (variant === 'masthead') {
    const mastheadHeight =
      typeof size === 'number'
        ? Math.max(40, size)
        : size === 'xl'
          ? 128
          : size === 'lg'
            ? 104
            : size === 'sm'
              ? 44
              : 88;
    return (
      <div
        id={id}
        className={`inline-flex items-center select-none brand-logo no-copy ${className}`}
        draggable={false}
        onContextMenu={(e) => e.preventDefault()}
      >
        {renderWordmark(mastheadHeight)}
      </div>
    );
  }

  // Header Brand / Horizontal: Logo Emblem + Two-Tone Bodoni Wordmark
  if (variant === 'header-brand' || variant === 'horizontal') {
    const headerEmblem =
      typeof size === 'number'
        ? Math.max(24, Math.round(size * 0.92))
        : size === 'lg'
          ? 46
          : size === 'sm'
            ? 30
            : 38;
    const headerWordmark =
      typeof size === 'number'
        ? Math.max(32, Math.round(size * 1.15))
        : size === 'lg'
          ? 56
          : size === 'sm'
            ? 38
            : 46;

    return (
      <div
        id={id}
        className={`inline-flex items-center gap-2 sm:gap-2.5 select-none brand-logo no-copy ${className}`}
        draggable={false}
        onContextMenu={(e) => e.preventDefault()}
      >
        {renderEmblem(headerEmblem)}
        {renderWordmark(headerWordmark)}
      </div>
    );
  }

  // Full stacked brand mark (splash / colophon)
  if (variant === 'full') {
    const fullEmblem = size === 'xl' ? 104 : size === 'lg' ? 80 : 60;
    const fullWordmark = size === 'xl' ? 88 : size === 'lg' ? 68 : 54;
    return (
      <div
        id={id}
        className={`flex flex-col items-center text-center select-none brand-logo no-copy ${className}`}
        draggable={false}
        onContextMenu={(e) => e.preventDefault()}
      >
        <div className="mb-3 select-none">{renderEmblem(fullEmblem)}</div>
        <div className="select-none pointer-events-none">{renderWordmark(fullWordmark)}</div>
      </div>
    );
  }

  // Wordmark only
  return (
    <div
      id={id}
      className={`inline-flex items-center select-none brand-logo no-copy ${className}`}
      draggable={false}
      onContextMenu={(e) => e.preventDefault()}
    >
      {renderWordmark(wordmarkHeight)}
    </div>
  );
};
