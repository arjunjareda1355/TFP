import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  UserPlus,
  CheckCircle2,
  AlertCircle,
  Trash2,
  Lock,
  Unlock,
  Copy,
  RefreshCw,
  Edit3,
  X,
} from 'lucide-react';
import { useMagazine } from '../../context/MagazineContext';
import { api } from '../../services/api';
import { fetchAllUsersFromFirestore } from '../../services/firestoreSync';
import { User, RoleName } from '../../types';
import { AdminConfirmDialog } from './AdminConfirmDialog';

export const AdminUsersRoles: React.FC = () => {
  const { currentUser } = useMagazine();
  const [users, setUsers] = useState<User[]>([]);
  const [invitations, setInvitations] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const [invitationToRevoke, setInvitationToRevoke] = useState<{ id: string; email: string } | null>(null);
  const [userToSuspend, setUserToSuspend] = useState<{ user: User; willSuspend: boolean } | null>(null);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [isProcessingAction, setIsProcessingAction] = useState(false);

  const [showInviteModal, setShowInviteModal] = useState(false);
  const [activateImmediately, setActivateImmediately] = useState(true);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteName, setInviteName] = useState('');
  const [inviteRole, setInviteRole] = useState<RoleName>('EDITOR');
  const [customPermissions, setCustomPermissions] = useState<string[]>([]);
  const [lastGeneratedInvite, setLastGeneratedInvite] = useState<{
    email: string;
    token: string;
    inviteUrl: string;
  } | null>(null);

  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [selectedRole, setSelectedRole] = useState<RoleName>('EDITOR');
  const [userCustomPermissions, setUserCustomPermissions] = useState<string[]>([]);

  const loadUsersAndInvitations = async () => {
    setIsLoading(true);
    try {
      const [apiRes, fsUsers] = await Promise.allSettled([api.getUsers(), fetchAllUsersFromFirestore()]);
      const apiUsers = apiRes.status === 'fulfilled' && Array.isArray(apiRes.value.users) ? apiRes.value.users : [];
      const apiInvs = apiRes.status === 'fulfilled' && Array.isArray(apiRes.value.invitations) ? apiRes.value.invitations : [];
      const firestoreUsers = fsUsers.status === 'fulfilled' && Array.isArray(fsUsers.value) ? fsUsers.value : [];

      const byEmailOrId = new Map<string, User>();
      for (const u of apiUsers) {
        const key = (u.email || u.id).toLowerCase();
        byEmailOrId.set(key, u);
      }
      for (const u of firestoreUsers) {
        const key = (u.email || u.id).toLowerCase();
        const existing = byEmailOrId.get(key);
        byEmailOrId.set(key, existing ? { ...existing, ...u, email: u.email || existing.email } : u);
      }

      setUsers(Array.from(byEmailOrId.values()));
      setInvitations(apiInvs);
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to load user records.' });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadUsersAndInvitations();
  }, []);

  const handleSendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail.trim()) {
      setFeedback({ type: 'error', message: 'Please provide a valid email address.' });
      return;
    }

    if (activateImmediately) {
      try {
        const res = await api.createUser({
          email: inviteEmail.trim(),
          name: inviteName.trim() || undefined,
          role: inviteRole,
          customPermissions: customPermissions.length > 0 ? customPermissions : undefined,
        });
        setFeedback({
          type: 'success',
          message: `Added ${res.user.name} (${res.user.email}) as ${res.user.role}.`,
        });
        setShowInviteModal(false);
        setInviteEmail('');
        setInviteName('');
        setCustomPermissions([]);
        await loadUsersAndInvitations();
        return;
      } catch (err: any) {
        setFeedback({ type: 'error', message: err.message || 'Failed to add user.' });
        return;
      }
    }

    try {
      const res = await api.inviteUser({
        email: inviteEmail.trim(),
        name: inviteName.trim() || undefined,
        role: inviteRole,
        customPermissions: customPermissions.length > 0 ? customPermissions : undefined,
      });

      setLastGeneratedInvite({
        email: res.invitation.email,
        token: res.invitation.token,
        inviteUrl: res.inviteUrl,
      });
      setFeedback({
        type: 'success',
        message: `Invitation created for ${res.invitation.email}.`,
      });
      setShowInviteModal(false);
      setInviteEmail('');
      setInviteName('');
      setCustomPermissions([]);
      await loadUsersAndInvitations();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to create invitation.' });
    }
  };

  const handleConfirmRevokeInvitation = async () => {
    if (!invitationToRevoke) return;
    setIsProcessingAction(true);
    try {
      await api.revokeInvitation(invitationToRevoke.id);
      setFeedback({ type: 'success', message: `Invitation for ${invitationToRevoke.email} revoked.` });
      setInvitationToRevoke(null);
      loadUsersAndInvitations();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to revoke invitation.' });
    } finally {
      setIsProcessingAction(false);
    }
  };

  const handleConfirmToggleSuspend = async () => {
    if (!userToSuspend) return;
    setIsProcessingAction(true);
    const { user, willSuspend } = userToSuspend;
    try {
      await api.suspendUser(user.id, willSuspend);
      setFeedback({
        type: 'success',
        message: `${user.name} is now ${willSuspend ? 'suspended' : 'active'}.`,
      });
      setUserToSuspend(null);
      loadUsersAndInvitations();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Action failed.' });
    } finally {
      setIsProcessingAction(false);
    }
  };

  const handleConfirmDeleteUser = async () => {
    if (!userToDelete) return;
    setIsProcessingAction(true);
    try {
      await api.deleteUser(userToDelete.id);
      setFeedback({ type: 'success', message: `${userToDelete.name} removed.` });
      setUserToDelete(null);
      loadUsersAndInvitations();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to remove user.' });
    } finally {
      setIsProcessingAction(false);
    }
  };

  const handleUpdateUserRole = async () => {
    if (!editingUser) return;
    try {
      await api.updateUserRole(
        editingUser.id,
        selectedRole,
        userCustomPermissions.length > 0 ? userCustomPermissions : undefined
      );
      setFeedback({
        type: 'success',
        message: `Role for ${editingUser.name} updated to ${selectedRole}.`,
      });
      setEditingUser(null);
      loadUsersAndInvitations();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to update role.' });
    }
  };

  const availablePermissions = [
    { key: 'articles.create', label: 'Create Stories' },
    { key: 'articles.edit_all', label: 'Edit All Stories' },
    { key: 'articles.publish', label: 'Publish Stories' },
    { key: 'articles.delete', label: 'Delete Stories' },
    { key: 'trash.restore', label: 'Restore from Trash' },
    { key: 'trash.purge', label: 'Permanent Purge' },
    { key: 'website.manage_social', label: 'Edit Social Links' },
    { key: 'website.manage_navigation', label: 'Edit Site Menus' },
    { key: 'users.manage_roles', label: 'Manage Roles & Access' },
    { key: 'security.view_logs', label: 'View Activity Log' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-5 border-b border-[#E8E5DF]">
        <div>
          <p className="text-[11px] font-mono-editorial uppercase tracking-widest text-[#EA580C] font-semibold">
            Access Control
          </p>
          <h1 className="font-serif-editorial text-2xl sm:text-3xl font-medium text-[#111110] mt-1">
            Users & Roles
          </h1>
          <p className="text-xs text-[#6E6A62] mt-1 font-sans-editorial">
            Authorized publication owners, editorial team members, and signed-in reader accounts.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={loadUsersAndInvitations}
            className="p-2 bg-[#FFFFFF] border border-[#E8E5DF] hover:border-[#111110] text-[#55524B] rounded-xs transition-colors cursor-pointer"
            title="Refresh users"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
          <button
            type="button"
            onClick={() => setShowInviteModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#EA580C] hover:bg-[#C2410C] text-white text-xs font-mono-editorial uppercase tracking-wider font-semibold rounded-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Add Team Member</span>
          </button>
        </div>
      </div>

      {/* Co-Owners Strip */}
      <div className="grid grid-cols-1 md:grid-cols-2 bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs divide-y md:divide-y-0 md:divide-x divide-[#E8E5DF]">
        <div className="p-5 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono-editorial uppercase tracking-wider font-bold text-[#EA580C]">
              Editorial Owner
            </span>
            <ShieldCheck className="w-4 h-4 text-[#EA580C]" />
          </div>
          <div className="font-serif-editorial text-base font-semibold text-[#111110]">
            arjunjareda2007@gmail.com
          </div>
          <p className="text-xs text-[#6E6A62]">
            Full editorial direction, story publishing, and front-page curation authority.
          </p>
        </div>

        <div className="p-5 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono-editorial uppercase tracking-wider font-bold text-[#111110]">
              Operations Owner
            </span>
            <ShieldCheck className="w-4 h-4 text-[#111110]" />
          </div>
          <div className="font-serif-editorial text-base font-semibold text-[#111110]">
            arjunjareda1355@gmail.com
          </div>
          <p className="text-xs text-[#6E6A62]">
            Full platform administration, user roles, integrations, and repository sync authority.
          </p>
        </div>
      </div>

      {/* Feedback Banner */}
      {feedback && (
        <div
          className={`p-3.5 rounded-xs border flex items-center justify-between text-xs font-mono-editorial ${
            feedback.type === 'success'
              ? 'bg-[#F0FDF4] border-[#BBF7D0] text-[#166534]'
              : 'bg-[#FEF2F2] border-[#FECACA] text-[#991B1B]'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-[#16A34A]" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-[#DC2626]" />
            )}
            <span>{feedback.message}</span>
          </div>
          <button type="button" onClick={() => setFeedback(null)} className="hover:opacity-70 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Generated Invite Link */}
      {lastGeneratedInvite && (
        <div className="bg-[#FFFBEB] border border-[#FDE68A] p-4 rounded-xs space-y-2.5">
          <div className="flex items-center justify-between text-xs font-mono-editorial">
            <span className="font-bold text-[#92400E] uppercase">
              Invitation Ready — {lastGeneratedInvite.email}
            </span>
            <button
              type="button"
              onClick={() => setLastGeneratedInvite(null)}
              className="text-[#92400E] hover:underline cursor-pointer"
            >
              Dismiss
            </button>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              readOnly
              value={lastGeneratedInvite.inviteUrl}
              className="flex-1 bg-[#FFFFFF] border border-[#FCD34D] px-3 py-2 text-xs font-mono-editorial text-[#111110] rounded-xs"
            />
            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText(lastGeneratedInvite.inviteUrl);
                setFeedback({ type: 'success', message: 'Invite link copied.' });
              }}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-[#111110] hover:bg-[#EA580C] text-white text-xs font-mono-editorial uppercase font-semibold rounded-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Copy Link</span>
            </button>
          </div>
        </div>
      )}

      {/* Users Table */}
      <div className="bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E8E5DF] flex items-center justify-between">
          <h2 className="font-serif-editorial text-lg font-medium text-[#111110]">
            Registered Accounts ({users.length})
          </h2>
          <span className="text-[11px] font-mono-editorial text-[#6E6A62]">
            Automatic owner & reader classification
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse min-w-[680px]">
            <thead>
              <tr className="bg-[#FAF9F6] border-b border-[#E8E5DF] text-[10px] font-mono-editorial uppercase tracking-wider text-[#6E6A62]">
                <th className="py-2.5 px-5 font-semibold">User</th>
                <th className="py-2.5 px-4 font-semibold">Role</th>
                <th className="py-2.5 px-4 font-semibold">Status</th>
                <th className="py-2.5 px-4 font-semibold">Last Sign-In</th>
                <th className="py-2.5 px-5 text-right font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E8E5DF]">
              {users.map((user) => {
                const isPermanent = Boolean(user.isPermanentOwner);
                const isCurrent = Boolean(
                  currentUser?.email && user.email && currentUser.email.toLowerCase() === user.email.toLowerCase()
                );

                return (
                  <tr key={user.id} className="hover:bg-[#FAF9F6] transition-colors">
                    <td className="py-3.5 px-5">
                      <div className="flex items-center gap-3 min-w-0">
                        {user.avatar ? (
                          <img
                            src={user.avatar}
                            alt={user.name}
                            referrerPolicy="no-referrer"
                            className="w-8 h-8 rounded-full object-cover border border-[#E8E5DF] shrink-0"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-[#111110] text-white flex items-center justify-center text-xs font-bold font-serif-editorial shrink-0">
                            {user.name?.charAt(0) || 'U'}
                          </div>
                        )}
                        <div className="min-w-0">
                          <div className="font-medium text-sm text-[#111110] flex items-center gap-1.5">
                            <span className="truncate">{user.name}</span>
                            {isPermanent && <ShieldCheck className="w-3.5 h-3.5 text-[#EA580C] shrink-0" />}
                            {isCurrent && (
                              <span className="text-[10px] font-mono-editorial text-[#EA580C] uppercase font-semibold">
                                (You)
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-[#6E6A62] font-mono-editorial truncate">
                            {user.email || user.id}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono-editorial text-[11px] uppercase font-semibold">
                      <span
                        className={
                          isPermanent || user.role === 'EDITORIAL_OWNER' || user.role === 'OPERATIONS_OWNER'
                            ? 'text-[#EA580C]'
                            : user.role === 'READER'
                            ? 'text-[#6E6A62]'
                            : 'text-[#111110]'
                        }
                      >
                        {user.role}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 font-mono-editorial text-[11px] uppercase font-semibold">
                      <span className={user.status === 'SUSPENDED' ? 'text-[#DC2626]' : 'text-[#15803D]'}>
                        {user.status || 'ACTIVE'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 font-mono-editorial text-xs text-[#6E6A62] tabular-nums">
                      {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : '—'}
                    </td>

                    <td className="py-3.5 px-5 text-right whitespace-nowrap">
                      {isPermanent ? (
                        <span className="text-[11px] font-mono-editorial text-[#8E8A81]">Protected Owner</span>
                      ) : (
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingUser(user);
                              setSelectedRole(user.role);
                              setUserCustomPermissions(user.customPermissions || []);
                            }}
                            className="p-1.5 text-[#6E6A62] hover:text-[#111110] hover:bg-[#F4F1EA] rounded-xs transition-colors cursor-pointer"
                            title="Edit Role"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => setUserToSuspend({ user, willSuspend: user.status !== 'SUSPENDED' })}
                            className="p-1.5 text-[#6E6A62] hover:text-[#D97706] hover:bg-[#FFFBEB] rounded-xs transition-colors cursor-pointer"
                            title={user.status === 'SUSPENDED' ? 'Restore' : 'Suspend'}
                          >
                            {user.status === 'SUSPENDED' ? (
                              <Unlock className="w-3.5 h-3.5 text-[#16A34A]" />
                            ) : (
                              <Lock className="w-3.5 h-3.5 text-[#D97706]" />
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => setUserToDelete(user)}
                            className="p-1.5 text-[#6E6A62] hover:text-[#DC2626] hover:bg-[#FEF2F2] rounded-xs transition-colors cursor-pointer"
                            title="Remove User"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pending Invitations */}
      {invitations.length > 0 && (
        <div className="bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs overflow-hidden">
          <div className="px-5 py-4 border-b border-[#E8E5DF]">
            <h3 className="font-serif-editorial text-base font-medium text-[#111110]">
              Pending Invitations ({invitations.length})
            </h3>
          </div>
          <div className="divide-y divide-[#E8E5DF]">
            {invitations.map((inv) => (
              <div
                key={inv.id}
                className="px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <div className="text-sm font-medium text-[#111110] truncate">
                    {inv.name || inv.email}{' '}
                    <span className="text-xs font-mono-editorial text-[#EA580C] uppercase ml-1">{inv.role}</span>
                  </div>
                  <div className="text-[11px] text-[#6E6A62] font-mono-editorial">{inv.email}</div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      const url = `${window.location.origin}/#accept-invite?token=${inv.token}`;
                      navigator.clipboard.writeText(url);
                      setFeedback({ type: 'success', message: 'Invite link copied.' });
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-[#FFFFFF] border border-[#E8E5DF] text-xs font-mono-editorial rounded-xs hover:border-[#111110] cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copy Link</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setInvitationToRevoke({ id: inv.id, email: inv.email })}
                    className="p-1.5 text-[#DC2626] hover:bg-[#FEF2F2] rounded-xs transition-colors cursor-pointer"
                    title="Revoke invitation"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add User Modal */}
      {showInviteModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#111110]/60 backdrop-blur-xs"
          onClick={() => setShowInviteModal(false)}
        >
          <div
            className="bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs shadow-2xl max-w-lg w-full p-6 space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-[#E8E5DF] pb-3.5">
              <h3 className="font-serif-editorial text-xl font-medium text-[#111110]">Add Team Member</h3>
              <button
                type="button"
                onClick={() => setShowInviteModal(false)}
                className="text-[#8E8A81] hover:text-[#111110] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendInvite} className="space-y-4">
              <div>
                <label className="block text-[11px] font-mono-editorial uppercase font-semibold text-[#6E6A62] mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  placeholder="editor@foldedpage.in"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  className="w-full bg-[#F9F8F6] border border-[#E8E5DF] px-3 py-2 text-xs font-mono-editorial rounded-xs focus:bg-white focus:border-[#EA580C] outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono-editorial uppercase font-semibold text-[#6E6A62] mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  placeholder="Elena Rostova"
                  value={inviteName}
                  onChange={(e) => setInviteName(e.target.value)}
                  className="w-full bg-[#F9F8F6] border border-[#E8E5DF] px-3 py-2 text-xs rounded-xs focus:bg-white focus:border-[#EA580C] outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono-editorial uppercase font-semibold text-[#6E6A62] mb-1">
                  Role
                </label>
                <select
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value as RoleName)}
                  className="w-full bg-[#F9F8F6] border border-[#E8E5DF] px-3 py-2 text-xs rounded-xs font-mono-editorial outline-none"
                >
                  <option value="MANAGING_EDITOR">Managing Editor</option>
                  <option value="SENIOR_EDITOR">Senior Editor</option>
                  <option value="EDITOR">Editor</option>
                  <option value="CONTRIBUTOR">Contributor</option>
                  <option value="OPERATIONS_SPECIALIST">Operations Specialist</option>
                  <option value="READER">Reader</option>
                </select>
              </div>

              <label className="flex items-center justify-between p-3 bg-[#FAF9F6] border border-[#E8E5DF] rounded-xs cursor-pointer">
                <span className="text-xs text-[#111110]">Activate immediately</span>
                <input
                  type="checkbox"
                  checked={activateImmediately}
                  onChange={(e) => setActivateImmediately(e.target.checked)}
                  className="w-4 h-4 text-[#EA580C]"
                />
              </label>

              <div className="pt-3 border-t border-[#E8E5DF] flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowInviteModal(false)}
                  className="px-4 py-2 text-xs font-mono-editorial text-[#6E6A62] hover:text-[#111110] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#EA580C] hover:bg-[#C2410C] text-white text-xs font-mono-editorial uppercase font-semibold rounded-xs transition-colors cursor-pointer"
                >
                  {activateImmediately ? 'Add User' : 'Create Invite'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Role Modal */}
      {editingUser && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#111110]/60 backdrop-blur-xs"
          onClick={() => setEditingUser(null)}
        >
          <div
            className="bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs shadow-2xl max-w-md w-full p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-[#E8E5DF] pb-3">
              <h3 className="font-serif-editorial text-lg font-medium text-[#111110]">
                Update Role — {editingUser.name}
              </h3>
              <button type="button" onClick={() => setEditingUser(null)} className="cursor-pointer">
                <X className="w-4 h-4 text-[#8E8A81]" />
              </button>
            </div>

            <div>
              <label className="block text-[11px] font-mono-editorial uppercase font-semibold text-[#6E6A62] mb-1">
                Role
              </label>
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value as RoleName)}
                className="w-full bg-[#F9F8F6] border border-[#E8E5DF] px-3 py-2 text-xs rounded-xs font-mono-editorial"
              >
                <option value="MANAGING_EDITOR">Managing Editor</option>
                <option value="SENIOR_EDITOR">Senior Editor</option>
                <option value="EDITOR">Editor</option>
                <option value="CONTRIBUTOR">Contributor</option>
                <option value="OPERATIONS_SPECIALIST">Operations Specialist</option>
                <option value="READER">Reader</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-mono-editorial uppercase font-semibold text-[#6E6A62] mb-1.5">
                Custom Permissions
              </label>
              <div className="grid grid-cols-1 gap-1.5 max-h-44 overflow-y-auto p-2.5 bg-[#F9F8F6] border border-[#E8E5DF] rounded-xs">
                {availablePermissions.map((perm) => (
                  <label key={perm.key} className="flex items-center gap-2 text-xs text-[#2C2A26] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={userCustomPermissions.includes(perm.key)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setUserCustomPermissions([...userCustomPermissions, perm.key]);
                        } else {
                          setUserCustomPermissions(userCustomPermissions.filter((p) => p !== perm.key));
                        }
                      }}
                    />
                    <span className="text-[11px]">{perm.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-[#E8E5DF] flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="px-3 py-1.5 text-xs font-mono-editorial text-[#6E6A62] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleUpdateUserRole}
                className="px-4 py-1.5 bg-[#111110] hover:bg-[#EA580C] text-white text-xs font-mono-editorial uppercase font-semibold rounded-xs cursor-pointer"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      <AdminConfirmDialog
        isOpen={Boolean(invitationToRevoke)}
        title="Revoke Invitation"
        message={invitationToRevoke ? `Revoke pending invitation for "${invitationToRevoke.email}"?` : ''}
        confirmLabel="Revoke"
        cancelLabel="Cancel"
        variant="danger"
        isLoading={isProcessingAction}
        onConfirm={handleConfirmRevokeInvitation}
        onClose={() => setInvitationToRevoke(null)}
      />

      <AdminConfirmDialog
        isOpen={Boolean(userToSuspend)}
        title={userToSuspend?.willSuspend ? 'Suspend Account' : 'Restore Account'}
        message={
          userToSuspend
            ? `${userToSuspend.willSuspend ? 'Suspend' : 'Restore'} access for ${userToSuspend.user.name} (${
                userToSuspend.user.email
              })?`
            : ''
        }
        confirmLabel={userToSuspend?.willSuspend ? 'Suspend' : 'Restore'}
        cancelLabel="Cancel"
        variant={userToSuspend?.willSuspend ? 'warning' : 'primary'}
        isLoading={isProcessingAction}
        onConfirm={handleConfirmToggleSuspend}
        onClose={() => setUserToSuspend(null)}
      />

      <AdminConfirmDialog
        isOpen={Boolean(userToDelete)}
        title="Remove Account"
        message={
          userToDelete ? `Remove ${userToDelete.name} (${userToDelete.email}) from user records?` : ''
        }
        confirmLabel="Remove"
        cancelLabel="Cancel"
        variant="danger"
        isLoading={isProcessingAction}
        onConfirm={handleConfirmDeleteUser}
        onClose={() => setUserToDelete(null)}
      />
    </div>
  );
};
