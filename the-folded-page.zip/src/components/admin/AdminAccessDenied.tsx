import React, { useState } from 'react';
import { ShieldAlert, ArrowLeft, LogOut, RefreshCw } from 'lucide-react';
import { useMagazine } from '../../context/MagazineContext';
import { BrandLogo } from '../BrandLogo';

interface AdminAccessDeniedProps {
  onBackToSite: () => void;
}

export const AdminAccessDenied: React.FC<AdminAccessDeniedProps> = ({ onBackToSite }) => {
  const { currentUser, logout, signInWithGoogle } = useMagazine();
  const [isSwitching, setIsSwitching] = useState(false);

  const handleSignOutAndExit = async () => {
    await logout();
    onBackToSite();
  };

  const handleSwitchAccount = async () => {
    setIsSwitching(true);
    try {
      await logout();
      await signInWithGoogle();
    } finally {
      setIsSwitching(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F9F8F6] flex flex-col justify-center items-center px-4 py-12 select-none">
      <div className="w-full max-w-md bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs p-8 text-center space-y-6">
        <div className="flex justify-center">
          <BrandLogo variant="emblem" size={42} theme="light" />
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center justify-center w-10 h-10 rounded-xs bg-[#FEF2F2] border border-[#FECACA] text-[#DC2626] mx-auto">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <p className="text-[11px] font-mono-editorial uppercase text-[#DC2626] font-bold tracking-widest">
            Owner Authorization Required
          </p>
          <h1 className="font-serif-editorial text-2xl font-medium text-[#111110]">
            Restricted Owner Dashboard
          </h1>
          <p className="text-xs text-[#55524B] font-sans-editorial leading-relaxed">
            This workspace is restricted to verified publication owners. Your current session is recognized as a reader account.
          </p>
        </div>

        <div className="bg-[#FAF9F6] border border-[#E8E5DF] rounded-xs p-4 text-left font-mono-editorial text-xs space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[#6E6A62]">Account</span>
            <span className="text-[#111110] font-semibold truncate">{currentUser?.email || 'Reader'}</span>
          </div>
          <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#E8E5DF]">
            <span className="text-[#6E6A62]">Detected Role</span>
            <span className="text-[#55524B] uppercase">{currentUser?.role || 'READER'}</span>
          </div>
        </div>

        <div className="space-y-2.5">
          <button
            type="button"
            onClick={handleSwitchAccount}
            disabled={isSwitching}
            className="w-full py-2.5 bg-[#111110] hover:bg-[#EA580C] disabled:opacity-60 text-white font-mono-editorial font-semibold text-xs uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSwitching ? 'animate-spin' : ''}`} />
            <span>Switch Google Account</span>
          </button>

          <button
            type="button"
            onClick={onBackToSite}
            className="w-full py-2.5 bg-[#FFFFFF] border border-[#E8E5DF] hover:border-[#111110] text-[#111110] font-mono-editorial font-semibold text-xs uppercase tracking-wider rounded-xs flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Live Magazine</span>
          </button>

          <button
            type="button"
            onClick={handleSignOutAndExit}
            className="w-full py-2 text-[#6E6A62] hover:text-[#DC2626] font-mono-editorial text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};
