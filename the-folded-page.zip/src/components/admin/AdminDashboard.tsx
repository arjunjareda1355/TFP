import React, { useEffect, useState } from 'react';
import {
  PlusCircle,
  ArrowRight,
  ExternalLink,
  Layers,
  Users,
  Mail,
  Key,
  FileEdit,
} from 'lucide-react';
import { useMagazine } from '../../context/MagazineContext';
import { api } from '../../services/api';
import { AnalyticsStats } from '../../types';
import { AdminTab } from './AdminLayout';

interface AdminDashboardProps {
  onNavigateTab: (tab: AdminTab) => void;
  onEditArticle: (id: string) => void;
  onPreviewArticle?: (slug: string) => void;
  onCreateArticle?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onNavigateTab,
  onEditArticle,
  onPreviewArticle,
}) => {
  const { articles, currentUser, subscriberCount: contextSubCount } = useMagazine();
  const [stats, setStats] = useState<AnalyticsStats>({
    totalViews: 0,
    totalSaves: 0,
    totalShares: 0,
    topArticles: [],
  });
  const [subscriberCount, setSubscriberCount] = useState(contextSubCount || 0);

  useEffect(() => {
    api.getAnalytics().then(setStats).catch(() => {});
    api
      .getNewsletterSubscribers()
      .then((subs) => setSubscriberCount(subs.length))
      .catch(() => {});
  }, []);

  const totalArticles = articles.length;
  const publishedCount = articles.filter((a) => a.status === 'PUBLISHED' || !a.status).length;
  const draftArticles = articles.filter((a) => a.status === 'DRAFT');
  const recentArticles = [...articles].slice(0, 7);

  const liveViewsTotal = articles.reduce((sum, a) => sum + (a.views || a.viewCount || 0), 0);
  const displayViews = Math.max(stats.totalViews || 0, liveViewsTotal);

  const statusTextClass = (status: string) => {
    if (status === 'PUBLISHED') return 'text-[#15803D]';
    if (status === 'SCHEDULED') return 'text-[#B45309]';
    if (status === 'ARCHIVED') return 'text-[#DC2626]';
    return 'text-[#6E6A62]';
  };

  return (
    <div className="space-y-8">
      {/* Clean Editorial Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#E8E5DF]">
        <div>
          <p className="text-[11px] font-mono-editorial uppercase tracking-widest text-[#EA580C] font-semibold">
            Owner Overview
          </p>
          <h1 className="font-serif-editorial text-2xl sm:text-3xl font-medium text-[#111110] mt-1">
            Welcome back, {currentUser?.name || 'Owner'}
          </h1>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => onNavigateTab('homepage')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#FFFFFF] border border-[#E8E5DF] hover:border-[#111110] text-[#111110] text-xs font-mono-editorial uppercase tracking-wider font-semibold rounded-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5 text-[#55524B]" />
            <span>Front Page</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigateTab('editor')}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#EA580C] hover:bg-[#C2410C] text-white text-xs font-mono-editorial uppercase tracking-wider font-semibold rounded-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>New Story</span>
          </button>
        </div>
      </div>

      {/* Unified 4-Column Hairline KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs divide-y lg:divide-y-0 lg:divide-x divide-[#E8E5DF]">
        <div className="p-5 space-y-1">
          <span className="text-[11px] font-mono-editorial uppercase tracking-wider text-[#6E6A62] block">
            Total Stories
          </span>
          <div className="text-2xl sm:text-3xl font-serif-editorial font-semibold text-[#111110] tabular-nums">
            {totalArticles}
          </div>
          <span className="text-[11px] font-mono-editorial text-[#8E8A81] block tabular-nums">
            {articles.filter((a) => a.isCoverStory).length} cover featured
          </span>
        </div>

        <div className="p-5 space-y-1">
          <span className="text-[11px] font-mono-editorial uppercase tracking-wider text-[#6E6A62] block">
            Published / Drafts
          </span>
          <div className="text-2xl sm:text-3xl font-serif-editorial font-semibold text-[#111110] tabular-nums">
            {publishedCount} <span className="text-[#D4CEBF] font-light">/</span> {draftArticles.length}
          </div>
          <span className="text-[11px] font-mono-editorial text-[#8E8A81] block">
            Active editorial ledger
          </span>
        </div>

        <div className="p-5 space-y-1">
          <span className="text-[11px] font-mono-editorial uppercase tracking-wider text-[#6E6A62] block">
            Subscribers
          </span>
          <div className="text-2xl sm:text-3xl font-serif-editorial font-semibold text-[#111110] tabular-nums">
            {subscriberCount.toLocaleString()}
          </div>
          <span className="text-[11px] font-mono-editorial text-[#8E8A81] block">
            The Folded Letter
          </span>
        </div>

        <div className="p-5 space-y-1">
          <span className="text-[11px] font-mono-editorial uppercase tracking-wider text-[#6E6A62] block">
            Total Views
          </span>
          <div className="text-2xl sm:text-3xl font-serif-editorial font-semibold text-[#111110] tabular-nums">
            {displayViews.toLocaleString()}
          </div>
          <span className="text-[11px] font-mono-editorial text-[#8E8A81] block tabular-nums">
            {(stats.totalSaves || 0).toLocaleString()} reader saves
          </span>
        </div>
      </div>

      {/* Main 2-Column Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Recent Stories Table */}
        <div className="lg:col-span-8 bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs overflow-hidden">
          <div className="px-5 py-4 border-b border-[#E8E5DF] flex items-center justify-between gap-2">
            <h2 className="font-serif-editorial text-lg font-medium text-[#111110]">
              Recent Stories
            </h2>
            <button
              type="button"
              onClick={() => onNavigateTab('articles')}
              className="text-xs font-mono-editorial uppercase tracking-wider font-semibold text-[#EA580C] hover:underline inline-flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>All Stories ({totalArticles})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs min-w-[580px]">
              <thead className="bg-[#FAF9F6] border-b border-[#E8E5DF] text-[10px] font-mono-editorial uppercase tracking-wider text-[#6E6A62]">
                <tr>
                  <th className="py-2.5 px-5 font-semibold">Story</th>
                  <th className="py-2.5 px-4 font-semibold">Status</th>
                  <th className="py-2.5 px-4 font-semibold">Date</th>
                  <th className="py-2.5 px-5 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E8E5DF]">
                {recentArticles.map((article) => {
                  const status = article.status || 'PUBLISHED';
                  return (
                    <tr key={article.id} className="hover:bg-[#FAF9F6] transition-colors">
                      <td className="py-3 px-5 max-w-xs">
                        <div className="flex items-center gap-3 min-w-0">
                          <img
                            src={article.heroImage}
                            alt=""
                            referrerPolicy="no-referrer"
                            className="w-10 h-10 object-cover rounded-xs border border-[#E8E5DF] shrink-0"
                          />
                          <div className="min-w-0">
                            <button
                              type="button"
                              onClick={() => onEditArticle(article.id)}
                              className="font-serif-editorial text-sm font-medium text-[#111110] hover:text-[#EA580C] transition-colors block truncate text-left w-full cursor-pointer"
                            >
                              {article.title}
                            </button>
                            <span className="text-[11px] font-mono-editorial text-[#8E8A81] block truncate">
                              {article.category} · {article.readTime}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono-editorial text-[11px] uppercase font-semibold whitespace-nowrap">
                        <span className={statusTextClass(status)}>{status}</span>
                      </td>

                      <td className="py-3 px-4 font-mono-editorial text-[#6E6A62] whitespace-nowrap">
                        {article.publishedDate}
                      </td>

                      <td className="py-3 px-5 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => onEditArticle(article.id)}
                            className="px-2.5 py-1 bg-[#111110] hover:bg-[#EA580C] text-white text-[11px] font-mono-editorial uppercase font-semibold rounded-xs transition-colors cursor-pointer"
                          >
                            Edit
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (onPreviewArticle) {
                                onPreviewArticle(article.slug);
                              } else {
                                window.location.hash = `/story/${article.slug}`;
                              }
                            }}
                            className="p-1 text-[#6E6A62] hover:text-[#111110] transition-colors cursor-pointer"
                            title="Open story"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: Draft Queue & Workspace Shortcuts */}
        <div className="lg:col-span-4 space-y-6">
          {/* Editorial Drafts Queue */}
          <div className="bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs overflow-hidden">
            <div className="px-5 py-4 border-b border-[#E8E5DF] flex items-center justify-between">
              <h2 className="font-serif-editorial text-lg font-medium text-[#111110]">
                Draft Queue
              </h2>
              <span className="text-xs font-mono-editorial text-[#6E6A62] tabular-nums">
                {draftArticles.length}
              </span>
            </div>

            {draftArticles.length === 0 ? (
              <div className="p-5 text-xs text-[#6E6A62] font-sans-editorial">
                No unpublished drafts waiting in queue.
              </div>
            ) : (
              <div className="divide-y divide-[#E8E5DF]">
                {draftArticles.slice(0, 4).map((draft) => (
                  <button
                    key={draft.id}
                    type="button"
                    onClick={() => onEditArticle(draft.id)}
                    className="w-full px-5 py-3 text-left hover:bg-[#FAF9F6] transition-colors flex items-center justify-between gap-3 cursor-pointer"
                  >
                    <div className="min-w-0">
                      <span className="font-serif-editorial text-sm font-medium text-[#111110] block truncate">
                        {draft.title}
                      </span>
                      <span className="text-[11px] font-mono-editorial text-[#8E8A81] block truncate">
                        {draft.category}
                      </span>
                    </div>
                    <FileEdit className="w-3.5 h-3.5 text-[#EA580C] shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Direct Workspace Shortcuts */}
          <div className="bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#E8E5DF]">
              <h3 className="text-xs font-mono-editorial uppercase tracking-wider font-bold text-[#6E6A62]">
                Workspace Controls
              </h3>
            </div>
            <div className="divide-y divide-[#E8E5DF]">
              {[
                { tab: 'homepage' as AdminTab, label: 'Curate Front Page', desc: 'Cover story & featured slots', icon: Layers },
                { tab: 'users' as AdminTab, label: 'Users & Roles', desc: 'Owners, editors & reader accounts', icon: Users },
                { tab: 'subscribers' as AdminTab, label: 'Subscribers & Inquiries', desc: 'Newsletter list & contact messages', icon: Mail },
                { tab: 'api-keys' as AdminTab, label: 'API & GitHub Sync', desc: 'Publishing keys & repository push', icon: Key },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.tab}
                    type="button"
                    onClick={() => onNavigateTab(item.tab)}
                    className="w-full px-5 py-3.5 text-left hover:bg-[#FAF9F6] transition-colors flex items-center justify-between gap-3 group cursor-pointer"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Icon className="w-4 h-4 text-[#EA580C] shrink-0" />
                      <div className="min-w-0">
                        <span className="text-xs font-semibold text-[#111110] group-hover:text-[#EA580C] transition-colors block">
                          {item.label}
                        </span>
                        <span className="text-[11px] text-[#6E6A62] block truncate">{item.desc}</span>
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-[#8E8A81] group-hover:text-[#EA580C] shrink-0" />
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
