import React, { useState } from 'react';
import { ArrowLeft, UserCheck, UserPlus, KeyRound, Shield, Sparkles, AlertCircle, ArrowRight, Loader2 } from 'lucide-react';
import { SignIn, SignUp } from '@clerk/clerk-react';
import { BrandLogo } from '../BrandLogo';
import { useMagazine } from '../../context/MagazineContext';

interface AdminLoginProps {
  onSuccess?: () => void;
  onCancel?: () => void;
  onBackToSite?: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onSuccess, onCancel, onBackToSite }) => {
  const { loginAsAdmin } = useMagazine();
  const [authMethod, setAuthMethod] = useState<'clerk' | 'direct'>('clerk');
  const [clerkTab, setClerkTab] = useState<'login' | 'signup'>('login');
  
  // Direct Editorial Desk form state
  const [email, setEmail] = useState('arjunjareda1355@gmail.com');
  const [passcode, setPasscode] = useState('');
  const [directLoading, setDirectLoading] = useState(false);
  const [directError, setDirectError] = useState('');

  const handleExit = onBackToSite || onCancel || (() => (window.location.hash = ''));

  const handleDirectLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setDirectError('Please enter your editorial email address');
      return;
    }
    setDirectError('');
    setDirectLoading(true);
    try {
      await loginAsAdmin(email.trim(), passcode);
      if (onSuccess) {
        onSuccess();
      } else {
        window.location.hash = '/admin/overview';
      }
    } catch (err: any) {
      setDirectError(err?.message || 'Login failed. Please verify your credentials.');
    } finally {
      setDirectLoading(false);
    }
  };

  const handleQuickFill = (targetEmail: string) => {
    setEmail(targetEmail);
    setDirectError('');
  };

  return (
    <div className="min-h-[100dvh] w-full bg-[#F9F8F6] flex flex-col justify-center items-center p-3 sm:p-6 py-4 sm:py-8 select-none overflow-y-auto">
      {/* Container with responsive fitting according to device screen */}
      <div className="w-full max-w-[440px] my-auto bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs shadow-md p-4 sm:p-7 max-h-[calc(100dvh-2rem)] overflow-y-auto">
        {/* Header */}
        <div className="text-center mb-4 sm:mb-5 pb-3 sm:pb-4 border-b border-[#E8E5DF]">
          <div className="flex justify-center mb-3">
            <BrandLogo variant="emblem" size={40} theme="light" />
          </div>

          <h1 className="font-serif-editorial text-xl sm:text-2xl font-bold tracking-tight text-[#111110]">
            The Folded Page
          </h1>
          <p className="font-serif-editorial italic text-xs text-[#6E6A62] mt-0.5">
            Publication Desk & CMS Portal
          </p>

          {/* Primary Method Switcher: Clerk SSO vs Editorial Desk */}
          <div className="flex items-center justify-center gap-1 mt-3 p-1 bg-[#F9F8F6] border border-[#E8E5DF] rounded-xs max-w-sm mx-auto">
            <button
              type="button"
              id="admin-method-clerk"
              onClick={() => setAuthMethod('clerk')}
              className={`flex-1 py-1.5 px-2 text-[11px] font-semibold uppercase tracking-wider transition-all rounded-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                authMethod === 'clerk'
                  ? 'bg-[#111110] text-white shadow-xs'
                  : 'text-[#55524B] hover:text-[#111110]'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Clerk SSO</span>
            </button>
            <button
              type="button"
              id="admin-method-direct"
              onClick={() => setAuthMethod('direct')}
              className={`flex-1 py-1.5 px-2 text-[11px] font-semibold uppercase tracking-wider transition-all rounded-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                authMethod === 'direct'
                  ? 'bg-[#111110] text-white shadow-xs'
                  : 'text-[#55524B] hover:text-[#111110]'
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Editorial Desk</span>
            </button>
          </div>
        </div>

        {/* METHOD 1: CLERK AUTHENTICATION */}
        {authMethod === 'clerk' && (
          <div className="space-y-3">
            {/* Secondary tabs for Clerk: Log In vs Sign Up */}
            <div className="flex items-center justify-center gap-1 p-0.5 bg-[#FAF9F6] border border-[#E8E5DF] rounded-xs max-w-xs mx-auto">
              <button
                type="button"
                id="admin-clerk-tab-login"
                onClick={() => setClerkTab('login')}
                className={`flex-1 py-1 text-[10px] font-mono-editorial uppercase tracking-wider transition-all rounded-xs flex items-center justify-center gap-1 cursor-pointer ${
                  clerkTab === 'login'
                    ? 'bg-white text-[#111110] font-bold shadow-xs'
                    : 'text-[#6E6A62] hover:text-[#111110]'
                }`}
              >
                <UserCheck className="w-3 h-3" />
                <span>Log In</span>
              </button>
              <button
                type="button"
                id="admin-clerk-tab-signup"
                onClick={() => setClerkTab('signup')}
                className={`flex-1 py-1 text-[10px] font-mono-editorial uppercase tracking-wider transition-all rounded-xs flex items-center justify-center gap-1 cursor-pointer ${
                  clerkTab === 'signup'
                    ? 'bg-white text-[#111110] font-bold shadow-xs'
                    : 'text-[#6E6A62] hover:text-[#111110]'
                }`}
              >
                <UserPlus className="w-3 h-3" />
                <span>Sign Up</span>
              </button>
            </div>

            {/* Clerk Form Embed with responsive options */}
            <div className="flex justify-center my-1 min-h-[260px] w-full">
              {clerkTab === 'login' ? (
                <div className="w-full">
                  <SignIn
                    routing="virtual"
                    fallbackRedirectUrl="/admin"
                    appearance={{
                      elements: {
                        rootBox: 'w-full max-w-full flex justify-center mx-auto',
                        cardBox: 'w-full max-w-full shadow-none flex justify-center mx-auto',
                        card: 'border-0 shadow-none p-0 w-full max-w-full bg-transparent mx-auto',
                        socialButtonsBlockButton:
                          'w-full rounded-xs border border-[#E8E5DF] hover:bg-[#F5F4F0] text-xs transition-colors py-2',
                        formButtonPrimary:
                          'w-full bg-[#111110] hover:bg-[#EA580C] text-xs font-semibold rounded-xs shadow-xs transition-colors py-2.5',
                        footerActionLink: 'text-[#EA580C] hover:text-[#C2410C]',
                      },
                    }}
                  />
                </div>
              ) : (
                <div className="w-full">
                  <SignUp
                    routing="virtual"
                    fallbackRedirectUrl="/admin"
                    appearance={{
                      elements: {
                        rootBox: 'w-full max-w-full flex justify-center mx-auto',
                        cardBox: 'w-full max-w-full shadow-none flex justify-center mx-auto',
                        card: 'border-0 shadow-none p-0 w-full max-w-full bg-transparent mx-auto',
                        socialButtonsBlockButton:
                          'w-full rounded-xs border border-[#E8E5DF] hover:bg-[#F5F4F0] text-xs transition-colors py-2',
                        formButtonPrimary:
                          'w-full bg-[#111110] hover:bg-[#EA580C] text-xs font-semibold rounded-xs shadow-xs transition-colors py-2.5',
                        footerActionLink: 'text-[#EA580C] hover:text-[#C2410C]',
                      },
                    }}
                  />
                </div>
              )}
            </div>

            {/* Helpful alternative hint */}
            <div className="text-center pt-2 border-t border-[#E8E5DF]/60">
              <button
                type="button"
                onClick={() => setAuthMethod('direct')}
                className="text-[11px] text-[#8E8A81] hover:text-[#EA580C] font-mono-editorial inline-flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span>Prefer direct editorial login? Click here</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        )}

        {/* METHOD 2: DIRECT EDITORIAL DESK LOGIN (Zero dependency on third-party cookies or domain mismatch) */}
        {authMethod === 'direct' && (
          <form onSubmit={handleDirectLogin} className="space-y-3.5 pt-1">
            <div className="p-2.5 bg-[#FAF9F6] border border-[#E8E5DF] rounded-xs">
              <div className="text-[10px] font-mono-editorial uppercase text-[#8E8A81] tracking-wider mb-1.5 flex items-center gap-1 font-semibold">
                <Sparkles className="w-3 h-3 text-[#EA580C]" />
                <span>Quick Authorized Owners</span>
              </div>
              <div className="flex flex-col gap-1.5">
                <button
                  type="button"
                  onClick={() => handleQuickFill('arjunjareda1355@gmail.com')}
                  className={`text-left px-2.5 py-1.5 rounded-xs text-[11px] border transition-colors flex items-center justify-between cursor-pointer ${
                    email === 'arjunjareda1355@gmail.com'
                      ? 'bg-[#111110] text-white border-[#111110]'
                      : 'bg-white text-[#55524B] border-[#E8E5DF] hover:border-[#111110]'
                  }`}
                >
                  <span className="font-mono truncate">arjunjareda1355@gmail.com</span>
                  <span className="text-[9px] uppercase tracking-wider font-semibold opacity-80 ml-2">
                    Operations
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickFill('arjunjareda2007@gmail.com')}
                  className={`text-left px-2.5 py-1.5 rounded-xs text-[11px] border transition-colors flex items-center justify-between cursor-pointer ${
                    email === 'arjunjareda2007@gmail.com'
                      ? 'bg-[#111110] text-white border-[#111110]'
                      : 'bg-white text-[#55524B] border-[#E8E5DF] hover:border-[#111110]'
                  }`}
                >
                  <span className="font-mono truncate">arjunjareda2007@gmail.com</span>
                  <span className="text-[9px] uppercase tracking-wider font-semibold opacity-80 ml-2">
                    Editorial
                  </span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-mono-editorial uppercase text-[#55524B] mb-1 font-semibold">
                Staff Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setDirectError('');
                }}
                placeholder="editor@foldedpage.in"
                className="w-full text-xs font-mono px-3 py-2 border border-[#E8E5DF] rounded-xs bg-[#F9F8F6] focus:bg-white focus:border-[#EA580C] outline-none"
                required
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[11px] font-mono-editorial uppercase text-[#55524B] font-semibold">
                  Passcode / Password <span className="text-[#8E8A81] font-normal">(Optional for owners)</span>
                </label>
              </div>
              <input
                type="password"
                value={passcode}
                onChange={(e) => {
                  setPasscode(e.target.value);
                  setDirectError('');
                }}
                placeholder="Leave blank for owner instant login"
                className="w-full text-xs font-mono px-3 py-2 border border-[#E8E5DF] rounded-xs bg-[#F9F8F6] focus:bg-white focus:border-[#EA580C] outline-none"
              />
            </div>

            {directError && (
              <div className="p-2.5 bg-[#FEF2F2] border border-[#FECACA] rounded-xs flex items-center gap-2 text-xs text-[#DC2626]">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span className="leading-snug">{directError}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={directLoading}
              className="w-full py-2.5 bg-[#111110] hover:bg-[#EA580C] text-white text-xs font-mono-editorial uppercase tracking-wider font-semibold rounded-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
            >
              {directLoading ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Signing In...</span>
                </>
              ) : (
                <>
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Enter Publication Desk</span>
                </>
              )}
            </button>
          </form>
        )}

        {/* Navigation Return */}
        <div className="mt-4 sm:mt-5 pt-3 border-t border-[#E8E5DF] text-center">
          <button
            type="button"
            onClick={handleExit}
            className="text-xs text-[#6E6A62] hover:text-[#111110] font-mono-editorial inline-flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Live Magazine</span>
          </button>
        </div>
      </div>
    </div>
  );
};
