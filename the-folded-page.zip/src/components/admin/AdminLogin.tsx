import React, { useState } from 'react';
import { ArrowLeft, ShieldCheck, AlertCircle, Loader2 } from 'lucide-react';
import { BrandLogo } from '../BrandLogo';
import { useMagazine } from '../../context/MagazineContext';

interface AdminLoginProps {
  onSuccess?: () => void;
  onCancel?: () => void;
  onBackToSite?: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onSuccess, onCancel, onBackToSite }) => {
  const { signInWithGoogle, authError, clearAuthError } = useMagazine();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleExit = onBackToSite || onCancel || (() => (window.location.hash = '/'));

  const handleSignIn = async () => {
    if (isSubmitting) return;
    clearAuthError();
    setIsSubmitting(true);
    try {
      const user = await signInWithGoogle();
      if (user) {
        if (onSuccess) {
          onSuccess();
        } else {
          window.location.hash = '/admin/overview';
        }
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-[100dvh] w-full bg-[#F9F8F6] flex flex-col justify-center items-center p-4 sm:p-6 select-none">
      <div className="w-full max-w-[420px] bg-[#FFFFFF] border border-[#E8E5DF] rounded-xs p-7 sm:p-8 space-y-6">
        <div className="text-center pb-5 border-b border-[#E8E5DF] space-y-2">
          <div className="flex justify-center mb-3">
            <BrandLogo variant="emblem" size={38} theme="light" />
          </div>
          <p className="text-[11px] font-mono-editorial uppercase tracking-widest text-[#EA580C] font-semibold">
            Owner Workspace
          </p>
          <h1 className="font-serif-editorial text-2xl font-medium text-[#111110]">
            The Folded Page
          </h1>
          <p className="text-xs text-[#6E6A62] font-sans-editorial leading-relaxed">
            Sign in with an authorized owner Google account to open the editorial and publication dashboard.
          </p>
        </div>

        {authError && (
          <div className="p-3 bg-[#FEF2F2] border border-[#FECACA] rounded-xs flex items-start gap-2 text-xs text-[#DC2626]">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span className="leading-snug">{authError}</span>
          </div>
        )}

        <div className="space-y-4">
          <button
            type="button"
            id="admin-google-signin-btn"
            onClick={handleSignIn}
            disabled={isSubmitting}
            className="w-full py-3 px-4 bg-[#111110] hover:bg-[#EA580C] disabled:opacity-60 text-white text-xs font-mono-editorial uppercase tracking-wider font-semibold rounded-xs transition-colors flex items-center justify-center gap-2.5 cursor-pointer whitespace-nowrap"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                <span>Verifying Account...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>Sign In with Google</span>
              </>
            )}
          </button>

          <div className="p-3.5 bg-[#FAF9F6] border border-[#E8E5DF] rounded-xs text-[11px] font-sans-editorial text-[#55524B] space-y-1">
            <div className="font-mono-editorial uppercase text-[10px] font-bold text-[#111110]">
              Automatic Role Verification
            </div>
            <p className="leading-relaxed">
              Owner accounts are verified automatically upon sign-in. Standard reader accounts remain restricted to the public reading experience.
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-[#E8E5DF] text-center">
          <button
            type="button"
            onClick={handleExit}
            className="text-xs text-[#6E6A62] hover:text-[#111110] font-mono-editorial inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Live Magazine</span>
          </button>
        </div>
      </div>
    </div>
  );
};
