import React, { useState } from 'react';
import {
  FileText,
  PlusCircle,
  Image as ImageIcon,
  FolderTree,
  Users,
  BookMarked,
  LayoutGrid,
  Mail,
  BarChart3,
  ExternalLink,
  ShieldCheck,
  Activity,
  Layers,
  Share2,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  Compass,
  Trash2,
  Key,
  LogOut,
} from 'lucide-react';
import { useMagazine } from '../../context/MagazineContext';
import { BrandLogo } from '../BrandLogo';

export type AdminTab =
  | 'overview'
  | 'articles'
  | 'editor'
  | 'users'
  | 'social'
  | 'navigation'
  | 'trash'
  | 'logs'
  | 'media'
  | 'homepage'
  | 'categories'
  | 'authors'
  | 'series-issues'
  | 'subscribers'
  | 'analytics'
  | 'api-keys';

interface AdminLayoutProps {
  currentTab: AdminTab;
  onSelectTab: (tab: AdminTab) => void;
  onNavigateHome: () => void;
  onEditArticle?: (id: string) => void;
  children: React.ReactNode;
}

interface NavItem {
  id: AdminTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  count?: number;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const TAB_LABELS: Record<AdminTab, string> = {
  overview: 'Overview',
  articles: 'Stories',
  editor: 'Story Editor',
  homepage: 'Front Page',
  categories: 'Categories & Tags',
  authors: 'Authors',
  'series-issues': 'Series & Issues',
  media: 'Media Library',
  subscribers: 'Subscribers & Inquiries',
  analytics: 'Analytics',
  social: 'Social & Channels',
  users: 'Users & Roles',
  'api-keys': 'API & GitHub Sync',
  navigation: 'Site Menus',
  logs: 'Activity Log',
  trash: 'Trash Vault',
};

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentTab,
  onSelectTab,
  onNavigateHome,
  children,
}) => {
  const { currentUser, articles, logout } = useMagazine();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);

  const draftCount = articles.filter((a) => a.status === 'DRAFT').length;

  const navSections: NavSection[] = [
    {
      title: 'Editorial',
      items: [
        { id: 'overview', label: 'Overview', icon: LayoutGrid },
        { id: 'articles', label: 'Stories', icon: FileText, count: draftCount > 0 ? draftCount : undefined },
        { id: 'editor', label: 'Story Editor', icon: PlusCircle },
        { id: 'homepage', label: 'Front Page', icon: Layers },
      ],
    },
    {
      title: 'Taxonomy & Archive',
      items: [
        { id: 'categories', label: 'Categories & Tags', icon: FolderTree },
        { id: 'authors', label: 'Authors', icon: Users },
        { id: 'series-issues', label: 'Series & Issues', icon: BookMarked },
        { id: 'media', label: 'Media Library', icon: ImageIcon },
      ],
    },
    {
      title: 'Audience',
      items: [
        { id: 'subscribers', label: 'Subscribers & Inquiries', icon: Mail },
        { id: 'analytics', label: 'Analytics', icon: BarChart3 },
        { id: 'social', label: 'Social & Channels', icon: Share2 },
      ],
    },
    {
      title: 'Governance',
      items: [
        { id: 'users', label: 'Users & Roles', icon: ShieldCheck },
        { id: 'api-keys', label: 'API & GitHub Sync', icon: Key },
        { id: 'navigation', label: 'Site Menus', icon: Compass },
        { id: 'logs', label: 'Activity Log', icon: Activity },
        { id: 'trash', label: 'Trash Vault', icon: Trash2 },
      ],
    },
  ];

  const handleSelectTab = (tab: AdminTab) => {
    onSelectTab(tab);
    setIsMobileDrawerOpen(false);
  };

  const roleLabel =
    currentUser?.role === 'OPERATIONS_OWNER'
      ? 'Operations Owner'
      : currentUser?.role === 'EDITORIAL_OWNER'
      ? 'Editorial Owner'
      : 'Owner';

  return (
    <div className="min-h-screen bg-[#F9F8F6] text-[#111110] flex flex-col font-sans-editorial">
      {/* Top 56px Utility Header */}
      <header className="sticky top-0 z-40 h-14 bg-[#FFFFFF] border-b border-[#E8E5DF] px-4 sm:px-6 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => setIsMobileDrawerOpen(!isMobileDrawerOpen)}
            className="lg:hidden p-1.5 text-[#55524B] hover:text-[#111110] hover:bg-[#F5F4F0] rounded-xs transition-colors shrink-0"
            aria-label="Toggle dashboard navigation"
          >
            {isMobileDrawerOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <button
            type="button"
            onClick={() => handleSelectTab('overview')}
            className="flex items-center gap-2.5 text-left group min-w-0 cursor-pointer"
          >
            <BrandLogo variant="emblem" size={26} theme="light" />
            <span className="font-serif-editorial font-semibold text-base text-[#111110] group-hover:text-[#EA580C] transition-colors truncate">
              The Folded Page
            </span>
          </button>

          <span className="hidden sm:inline text-[#D4CEBF]">/</span>
          <span className="hidden sm:inline text-xs font-mono-editorial uppercase tracking-wider text-[#6E6A62] truncate">
            {TAB_LABELS[currentTab] || 'Overview'}
          </span>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            type="button"
            onClick={() => handleSelectTab('editor')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#EA580C] hover:bg-[#C2410C] text-white text-xs font-mono-editorial font-semibold uppercase tracking-wider rounded-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5 shrink-0" />
            <span>New Story</span>
          </button>

          <button
            type="button"
            onClick={onNavigateHome}
            className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 bg-[#FFFFFF] border border-[#E8E5DF] hover:border-[#111110] text-[#111110] text-xs font-mono-editorial rounded-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5 text-[#EA580C] shrink-0" />
            <span className="hidden md:inline">Live Site</span>
          </button>

          <div className="flex items-center gap-2 pl-2 sm:pl-3 border-l border-[#E8E5DF] shrink-0">
            {currentUser?.avatar ? (
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                referrerPolicy="no-referrer"
                className="w-7 h-7 rounded-full object-cover border border-[#E8E5DF] shrink-0"
              />
            ) : (
              <div className="w-7 h-7 rounded-full bg-[#111110] text-white flex items-center justify-center text-xs font-bold font-serif-editorial shrink-0">
                {currentUser?.name?.charAt(0) || 'O'}
              </div>
            )}

            <div className="hidden md:block text-left leading-tight">
              <div className="text-xs font-medium text-[#111110] truncate max-w-[140px]">
                {currentUser?.name || 'Owner'}
              </div>
              <div className="text-[10px] font-mono-editorial uppercase text-[#EA580C]">
                {roleLabel}
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                logout();
                onNavigateHome();
              }}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 border border-[#E8E5DF] hover:border-[#DC2626] text-[11px] font-mono-editorial text-[#55524B] hover:text-[#DC2626] rounded-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Workspace Body */}
      <div className="flex-1 flex min-w-0">
        {/* Desktop 248px Collapsible Sidebar */}
        <aside
          className={`hidden lg:flex flex-col bg-[#FFFFFF] border-r border-[#E8E5DF] transition-all duration-200 shrink-0 ${
            isSidebarCollapsed ? 'w-16' : 'w-[248px]'
          }`}
        >
          <div className="px-3 py-2.5 border-b border-[#E8E5DF] flex items-center justify-between">
            {!isSidebarCollapsed && (
              <span className="text-[10px] font-mono-editorial font-bold uppercase tracking-widest text-[#8E8A81] px-1">
                Owner Desk
              </span>
            )}
            <button
              type="button"
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
              className="p-1 text-[#8E8A81] hover:text-[#111110] hover:bg-[#F5F4F0] rounded-xs transition-colors ml-auto cursor-pointer"
              title={isSidebarCollapsed ? 'Expand navigation' : 'Collapse navigation'}
            >
              {isSidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          </div>

          <nav className="flex-1 overflow-y-auto p-3 space-y-5">
            {navSections.map((section) => (
              <div key={section.title} className="space-y-0.5">
                {!isSidebarCollapsed && (
                  <h4 className="px-2.5 text-[10px] font-mono-editorial font-bold uppercase tracking-widest text-[#8E8A81] mb-1.5">
                    {section.title}
                  </h4>
                )}
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelectTab(item.id)}
                      title={item.label}
                      className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xs text-xs transition-colors text-left cursor-pointer ${
                        isActive
                          ? 'bg-[#111110] text-[#FFFFFF] font-semibold'
                          : 'text-[#55524B] hover:text-[#111110] hover:bg-[#F5F4F0]'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#EA580C]' : 'text-[#8E8A81]'}`} />
                      {!isSidebarCollapsed && (
                        <span className="flex-1 truncate font-sans-editorial">{item.label}</span>
                      )}
                      {!isSidebarCollapsed && item.count !== undefined && (
                        <span
                          className={`text-[10px] font-mono-editorial tabular-nums ${
                            isActive ? 'text-[#F59E0B]' : 'text-[#EA580C]'
                          }`}
                        >
                          {item.count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            ))}
          </nav>

          {!isSidebarCollapsed && (
            <div className="px-4 py-3 border-t border-[#E8E5DF] bg-[#FAF9F6] text-[11px] font-mono-editorial text-[#6E6A62] truncate">
              {currentUser?.email}
            </div>
          )}
        </aside>

        {/* Mobile Sidebar Drawer */}
        {isMobileDrawerOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              onClick={() => setIsMobileDrawerOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            />
            <div className="relative w-72 max-w-[85vw] bg-[#FFFFFF] border-r border-[#E8E5DF] flex flex-col h-full z-10 shadow-xl">
              <div className="p-4 border-b border-[#E8E5DF] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <BrandLogo variant="emblem" size={24} theme="light" />
                  <span className="font-serif-editorial font-semibold text-sm text-[#111110]">Owner Desk</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsMobileDrawerOpen(false)}
                  className="p-1 text-[#6E6A62] hover:text-[#111110]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-5">
                {navSections.map((section) => (
                  <div key={section.title} className="space-y-0.5">
                    <h4 className="px-2 text-[10px] font-mono-editorial font-bold uppercase tracking-widest text-[#8E8A81] mb-1">
                      {section.title}
                    </h4>
                    {section.items.map((item) => {
                      const Icon = item.icon;
                      const isActive = currentTab === item.id;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => handleSelectTab(item.id)}
                          className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xs text-xs transition-colors text-left ${
                            isActive
                              ? 'bg-[#111110] text-[#FFFFFF] font-semibold'
                              : 'text-[#55524B] hover:text-[#111110] hover:bg-[#F5F4F0]'
                          }`}
                        >
                          <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#EA580C]' : 'text-[#8E8A81]'}`} />
                          <span className="flex-1 truncate">{item.label}</span>
                          {item.count !== undefined && (
                            <span className="text-[10px] font-mono-editorial text-[#EA580C] tabular-nums">
                              {item.count}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                ))}
              </div>

              <div className="p-4 border-t border-[#E8E5DF] bg-[#FAF9F6] space-y-2">
                <button
                  type="button"
                  onClick={onNavigateHome}
                  className="w-full py-2 bg-[#111110] text-white text-xs font-mono-editorial uppercase font-semibold rounded-xs flex items-center justify-center gap-2"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-[#EA580C]" />
                  <span>Live Site</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main Viewport */}
        <main className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 max-w-7xl w-full mx-auto min-w-0">
          {children}
        </main>
      </div>
    </div>
  );
};
