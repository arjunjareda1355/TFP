import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import type { UserRole } from '../types';

export const OWNER_EMAILS = [
  'arjunjareda1355@gmail.com',
  'arjunjareda2007@gmail.com',
] as const;

export function isOwnerEmail(email?: string | null): boolean {
  if (!email) return false;
  const clean = email.trim().toLowerCase();
  return (OWNER_EMAILS as readonly string[]).includes(clean);
}

export function resolveRoleForEmail(
  email?: string | null,
  existingRole?: UserRole
): UserRole {
  const clean = (email || '').trim().toLowerCase();
  if (clean === 'arjunjareda2007@gmail.com') return 'EDITORIAL_OWNER';
  if (clean === 'arjunjareda1355@gmail.com') return 'OPERATIONS_OWNER';
  if (existingRole && existingRole !== 'READER') return existingRole;
  return 'READER';
}

export function isStaffRole(role?: string | null, email?: string | null): boolean {
  if (isOwnerEmail(email)) return true;
  if (!role) return false;
  return [
    'EDITORIAL_OWNER',
    'OPERATIONS_OWNER',
    'OWNER',
    'MANAGING_EDITOR',
    'SENIOR_EDITOR',
    'EDITOR',
    'CONTRIBUTOR',
    'WRITER',
    'DESIGNER',
    'WEBSITE_MANAGER',
    'OPERATIONS_SPECIALIST',
  ].includes(role);
}

export function isOwnerRole(role?: string | null, email?: string | null): boolean {
  if (isOwnerEmail(email)) return true;
  if (!role) return false;
  return ['EDITORIAL_OWNER', 'OPERATIONS_OWNER', 'OWNER'].includes(role);
}

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

export const firebaseApp = app;
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData.map((provider) => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

let connectionTested = false;
export async function testConnection(): Promise<boolean> {
  if (connectionTested) return true;
  connectionTested = true;
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration. The Firestore client is offline.');
    }
    return false;
  }
}
