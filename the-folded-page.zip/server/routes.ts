import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { db } from './db';
import { User, UserRole } from '../src/types';
import { sendVerificationEmail, sendWelcomeEmail, sendStoryNewsletter } from './email';
import { geminiService } from './gemini';
import {
  uploadObjectToR2,
  downloadObjectFromR2,
  deleteObjectFromR2,
  generateR2UploadUrl,
  isR2Configured,
  R2_BUCKET_NAME,
  R2_PUBLIC_DOMAIN,
  saveArticleToCloudflareR2,
  deleteArticleFromCloudflareR2,
} from './cloudflareR2';
import {
  isD1Configured,
  syncDatabaseToCloudflareD1,
  generateD1SqlDump,
  StoredFileRecord,
} from './cloudflareD1';

import firebaseAppletConfig from '../firebase-applet-config.json';

const FIREBASE_PROJECT_ID = firebaseAppletConfig.projectId || 'emerald-iris-hlcf1';
const GOOGLE_CERTS_URL = 'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';

let cachedGoogleCerts: Record<string, string> = {};
let googleCertsExpiry = 0;

async function getGooglePublicCerts(): Promise<Record<string, string>> {
  const now = Date.now();
  if (now < googleCertsExpiry && Object.keys(cachedGoogleCerts).length > 0) {
    return cachedGoogleCerts;
  }
  const res = await fetch(GOOGLE_CERTS_URL, { signal: AbortSignal.timeout(5000) });
  if (!res.ok) {
    throw new Error(`Failed to fetch Google public keys: ${res.status}`);
  }
  const cacheControl = res.headers.get('cache-control') || '';
  const maxAgeMatch = cacheControl.match(/max-age=(\d+)/);
  const maxAgeSec = maxAgeMatch ? parseInt(maxAgeMatch[1], 10) : 3600;
  cachedGoogleCerts = (await res.json()) as Record<string, string>;
  googleCertsExpiry = now + maxAgeSec * 1000;
  return cachedGoogleCerts;
}

interface VerifiedFirebaseToken {
  uid: string;
  email: string;
  emailVerified: boolean;
  name?: string;
  picture?: string;
}

async function verifyFirebaseIdToken(idToken: string): Promise<VerifiedFirebaseToken | null> {
  try {
    const parts = idToken.split('.');
    if (parts.length !== 3) return null;

    const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
    const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));

    if (header.alg !== 'RS256' || !header.kid) return null;

    const nowSec = Math.floor(Date.now() / 1000);
    if (typeof payload.exp !== 'number' || payload.exp <= nowSec) return null;
    if (typeof payload.iat !== 'number' || payload.iat > nowSec + 300) return null;
    if (payload.aud !== FIREBASE_PROJECT_ID) return null;
    if (payload.iss !== `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`) return null;
    if (typeof payload.sub !== 'string' || !payload.sub) return null;

    const certs = await getGooglePublicCerts();
    const cert = certs[header.kid];
    if (!cert) return null;

    const verifier = crypto.createVerify('RSA-SHA256');
    verifier.update(`${parts[0]}.${parts[1]}`);
    const signatureValid = verifier.verify(cert, Buffer.from(parts[2], 'base64url'));
    if (!signatureValid) return null;

    const email = typeof payload.email === 'string' ? payload.email.trim().toLowerCase() : '';
    const emailVerified = payload.email_verified === true;
    if (!email || !emailVerified) return null;

    return {
      uid: payload.sub,
      email,
      emailVerified,
      name: typeof payload.name === 'string' ? payload.name : undefined,
      picture: typeof payload.picture === 'string' ? payload.picture : undefined,
    };
  } catch {
    return null;
  }
}

const router = express.Router();

// Ensure public/uploads directory exists
const UPLOADS_DIR = path.join(process.cwd(), 'public', 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Multer storage engine
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (!fs.existsSync(UPLOADS_DIR)) {
      fs.mkdirSync(UPLOADS_DIR, { recursive: true });
    }
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    let ext = path.extname(file.originalname).toLowerCase();
    if (!ext || ext === '.') ext = '.jpg';
    const cleanName = path
      .basename(file.originalname, ext)
      .replace(/[^a-zA-Z0-9_-]/g, '-')
      .toLowerCase() || 'image';
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e5)}`;
    cb(null, `${cleanName}-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB max
  fileFilter: (req, file, cb) => {
    const allowedExts = /\.(jpg|jpeg|png|webp|gif|svg|avif|heic|heif|jfif|bmp|tiff|mp4|webm|mov|ogg)$/i;
    const isAllowedExt = allowedExts.test(path.extname(file.originalname));
    const isAllowedMime =
      file.mimetype.startsWith('image/') ||
      file.mimetype.startsWith('video/') ||
      file.mimetype === 'application/octet-stream';
    if (isAllowedExt || isAllowedMime) {
      cb(null, true);
    } else {
      cb(new Error('Supported formats: JPG, PNG, WebP, GIF, SVG, AVIF, HEIC, MP4, WebM.'));
    }
  },
});

// Publication Owner emails
const OWNER_EMAILS = ['arjunjareda1355@gmail.com', 'arjunjareda2007@gmail.com'];

// Helper to check if a user is the publication owner or authorized editor
function isOwnerUser(user: User | null): boolean {
  if (!user) return false;
  const email = (user.email || '').toLowerCase().trim();
  const role = String(user.role || '');
  return (
    user.isPermanentOwner === true ||
    role === 'EDITORIAL_OWNER' ||
    role === 'OPERATIONS_OWNER' ||
    role === 'OWNER' ||
    role === 'MANAGING_EDITOR' ||
    role === 'SENIOR_EDITOR' ||
    role === 'EDITOR' ||
    role === 'ADMIN' ||
    OWNER_EMAILS.includes(email)
  );
}

function resolveUserFromVerifiedToken(verified: VerifiedFirebaseToken): User {
  const cleanEmail = verified.email.toLowerCase();
  const isEditorialOwner = cleanEmail === 'arjunjareda2007@gmail.com';
  const isOpsOwner = cleanEmail === 'arjunjareda1355@gmail.com';
  const isOwner = isEditorialOwner || isOpsOwner;
  const ownerRole: UserRole = isEditorialOwner ? 'EDITORIAL_OWNER' : 'OPERATIONS_OWNER';

  let user = db.getUserByEmail(cleanEmail) || db.getUserById(verified.uid);
  if (user) {
    if (isOwner) {
      user.role = ownerRole;
      user.isPermanentOwner = true;
      user.status = 'ACTIVE';
    }
    return user;
  }

  return {
    id: verified.uid,
    email: cleanEmail,
    name: verified.name || (isOwner ? 'Arjun Jareda' : cleanEmail.split('@')[0] || 'Reader'),
    role: isOwner ? ownerRole : 'READER',
    isPermanentOwner: isOwner,
    status: 'ACTIVE',
    avatar: verified.picture || undefined,
    bio: isOwner ? 'Publication Owner' : 'Verified Reader',
  };
}

async function resolveAuthUser(req: express.Request): Promise<User | null> {
  let rawToken: string | null = null;
  const authHeader = req.headers.authorization;
  if (authHeader) {
    if (authHeader.startsWith('Bearer ') || authHeader.startsWith('bearer ')) {
      rawToken = authHeader.substring(7).trim();
    } else if (!authHeader.includes(' ')) {
      rawToken = authHeader.trim();
    }
  }
  if (!rawToken && req.headers['x-api-key']) {
    rawToken = String(req.headers['x-api-key']).trim();
  }
  if (!rawToken && req.headers['api-key']) {
    rawToken = String(req.headers['api-key']).trim();
  }
  if (!rawToken && req.headers['x-auth-token']) {
    rawToken = String(req.headers['x-auth-token']).trim();
  }
  if (!rawToken && req.query) {
    if (req.query.apiKey) rawToken = String(req.query.apiKey).trim();
    else if (req.query.api_key) rawToken = String(req.query.api_key).trim();
  }
  if (!rawToken && req.body && typeof req.body === 'object') {
    if (req.body.apiKey) rawToken = String(req.body.apiKey).trim();
    else if (req.body.api_key) rawToken = String(req.body.api_key).trim();
  }

  if (!rawToken || rawToken === 'null' || rawToken === 'undefined' || rawToken === '""') {
    return null;
  }

  rawToken = rawToken.replace(/^["']|["']$/g, '');

  // 1. API Key Authentication (e.g. tfp_live_...)
  const apiKey = db.getApiKeyByKey(rawToken);
  if (apiKey && apiKey.status === 'ACTIVE') {
    db.recordApiKeyUsage(apiKey.id);
    return {
      id: `api-client-${apiKey.id}`,
      email: apiKey.createdBy || 'arjunjareda2007@gmail.com',
      name: `API Client (${apiKey.name})`,
      role: apiKey.role || 'EDITORIAL_OWNER',
      isPermanentOwner: true,
      customPermissions: apiKey.scopes && apiKey.scopes.length > 0 ? apiKey.scopes : ['*'],
      status: 'ACTIVE',
      bio: `External Editorial & Publishing Controller: ${apiKey.name}`,
    };
  }

  // 2. Cryptographically verified Firebase ID Token
  if (rawToken.split('.').length === 3) {
    const verified = await verifyFirebaseIdToken(rawToken);
    if (verified) {
      return resolveUserFromVerifiedToken(verified);
    }
  }

  return null;
}

function getAuthUser(req: express.Request): User | null {
  return ((req as any).authUser as User | null) || null;
}

// Editorial & Owner Middleware
function requireOwner() {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const user = getAuthUser(req);
    if (!user) {
      return res.status(401).json({
        error: 'Authentication required. Please sign in with an authorized publisher account.',
      });
    }
    if (!isOwnerUser(user)) {
      db.logActivity({
        userId: user.id,
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'ACCESS_DENIED',
        resource: 'Owner Restricted',
        details: `Access restricted: role ${user.role} does not have publication owner privileges.`,
        result: 'FAILURE',
      });
      return res.status(403).json({
        error: 'Access Denied: Only authorized publication owners or editors are authorized to make editorial changes.',
        userRole: user.role,
      });
    }
    (req as any).user = user;
    next();
  };
}

// RBAC Middleware
function requirePermission(permission: string) {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const user = getAuthUser(req);
    if (!user) {
      return res.status(401).json({
        error: 'Authentication required. Please sign in to access this resource.',
        requiredPermission: permission,
      });
    }
    if (!db.hasPermission(user, permission)) {
      db.logActivity({
        userId: user.id,
        userEmail: user.email,
        userName: user.name,
        userRole: user.role,
        action: 'ACCESS_DENIED',
        resource: permission,
        details: `Access restricted: role ${user.role} does not hold '${permission}' permission.`,
        result: 'FAILURE',
      });
      return res.status(403).json({
        error: `Access Denied: Your account role (${user.role}) lacks the required '${permission}' permission.`,
        requiredPermission: permission,
        userRole: user.role,
      });
    }
    (req as any).user = user;
    next();
  };
}

// Ensure database state is synced and auth identity resolved before serving API traffic
router.use(async (req, res, next) => {
  try {
    await db.ensureSynced();
  } catch (err) {
    console.warn('[Database] Sync before request notice:', err);
  }
  try {
    (req as any).authUser = await resolveAuthUser(req);
  } catch {
    (req as any).authUser = null;
  }
  next();
});

// ====================== AUTH ROUTES ======================
router.post('/auth/firebase-sync', async (req, res) => {
  try {
    const authHeader = req.headers.authorization || '';
    const bearer = authHeader.startsWith('Bearer ') ? authHeader.substring(7).trim() : '';
    const idToken = bearer || req.body?.idToken;
    if (!idToken || typeof idToken !== 'string') {
      return res.status(401).json({ error: 'Missing Firebase ID token.' });
    }

    const verified = await verifyFirebaseIdToken(idToken);
    if (!verified) {
      return res.status(401).json({ error: 'Invalid or expired authentication token.' });
    }

    const cleanEmail = verified.email.toLowerCase();
    const isEditorialOwner = cleanEmail === 'arjunjareda2007@gmail.com';
    const isOpsOwner = cleanEmail === 'arjunjareda1355@gmail.com';
    const isOwner = isEditorialOwner || isOpsOwner;
    const ownerRole: UserRole = isEditorialOwner ? 'EDITORIAL_OWNER' : 'OPERATIONS_OWNER';

    let user = db.getUserByEmail(cleanEmail) || db.getUserById(verified.uid);
    if (user) {
      user.status = user.status === 'SUSPENDED' && !isOwner ? 'SUSPENDED' : 'ACTIVE';
      if (verified.name) user.name = verified.name;
      if (verified.picture) user.avatar = verified.picture;
      if (isOwner) {
        user.role = ownerRole;
        user.isPermanentOwner = true;
      }
      user.lastLogin = new Date().toISOString();
      db.save();
    } else {
      user = {
        id: verified.uid,
        email: cleanEmail,
        name: verified.name || (isOwner ? 'Arjun Jareda' : cleanEmail.split('@')[0] || 'Reader'),
        role: isOwner ? ownerRole : 'READER',
        isPermanentOwner: isOwner,
        status: 'ACTIVE',
        avatar: verified.picture || undefined,
        bio: isOwner ? 'Publication Owner' : 'Verified Reader',
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
      };
      db.addUser(user);
    }

    db.logActivity({
      userId: user.id,
      userEmail: user.email,
      userName: user.name,
      userRole: user.role,
      action: 'User Sign In',
      resource: 'Authentication',
      details: `Authenticated via Firebase (${user.role}).`,
      result: 'SUCCESS',
    });

    return res.json({
      success: true,
      user,
      isOwner: isOwner || isOwnerUser(user),
      isStaff: isOwner || ['MANAGING_EDITOR', 'SENIOR_EDITOR', 'EDITOR', 'CONTRIBUTOR', 'WRITER', 'DESIGNER', 'WEBSITE_MANAGER', 'OPERATIONS_SPECIALIST'].includes(user.role),
    });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Failed to synchronize session' });
  }
});

router.get('/auth/me', (req, res) => {
  const user = getAuthUser(req);
  if (user) {
    return res.json({
      user,
      authenticated: true,
      isOwner: isOwnerUser(user),
    });
  }
  return res.json({ user: null, authenticated: false, isOwner: false });
});

// ====================== ARTICLE ROUTES ======================
router.get('/articles', async (req, res) => {
  try {
    const {
      status,
      category,
      tag,
      authorId,
      seriesId,
      issueId,
      flag,
      search,
      limit,
      offset,
      includeDrafts,
    } = req.query;

    await db.ensureSynced();
    const result = db.getArticles({
      status: status as string,
      category: category as string,
      tag: tag as string,
      authorId: authorId as string,
      seriesId: seriesId as string,
      issueId: issueId as string,
      flag: flag as string,
      search: search as string,
      limit: limit ? parseInt(limit as string, 10) : undefined,
      offset: offset ? parseInt(offset as string, 10) : undefined,
      includeDrafts: includeDrafts === 'true' || Boolean(status && status !== 'PUBLISHED'),
    });

    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/articles/:id_or_slug', async (req, res) => {
  try {
    await db.ensureSynced();
    const article = db.getArticleByIdOrSlug(req.params.id_or_slug);
    if (!article) {
      return res.status(404).json({ error: 'Article not found.' });
    }
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.json(article);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/articles', requireOwner(), async (req, res) => {
  try {
    await db.ensureSynced();
    const user = (req as any).user;
    const newArticle = db.createArticle(req.body, user);
    // Non-blocking background cloud sync
    saveArticleToCloudflareR2(newArticle).catch(() => {});
    db.saveAsync().catch(() => {});
    res.status(201).json(newArticle);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/articles/:id', requireOwner(), async (req, res) => {
  try {
    await db.ensureSynced();
    const user = (req as any).user;
    const updated = db.updateArticle(req.params.id, req.body, user);
    if (!updated) {
      return res.status(404).json({ error: 'Article not found.' });
    }
    // Non-blocking background cloud sync
    saveArticleToCloudflareR2(updated).catch(() => {});
    db.saveAsync().catch(() => {});
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/articles/:id/duplicate', requireOwner(), async (req, res) => {
  try {
    await db.ensureSynced();
    const user = (req as any).user;
    const duplicated = db.duplicateArticle(req.params.id, user);
    if (!duplicated) {
      return res.status(404).json({ error: 'Article not found to duplicate.' });
    }
    // Non-blocking background cloud sync
    saveArticleToCloudflareR2(duplicated).catch(() => {});
    db.saveAsync().catch(() => {});
    res.status(201).json(duplicated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/articles/:id/publish', requireOwner(), async (req, res) => {
  try {
    await db.ensureSynced();
    const user = (req as any).user;
    const now = new Date();
    const nowStr = now.toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });
    const nowIso = now.toISOString();
    
    // Merge any incoming body updates with PUBLISHED status
    const updates = {
      ...(req.body || {}),
      status: 'PUBLISHED' as const,
      publishedDate: req.body?.publishedDate || nowStr,
      publishedAt: req.body?.publishedAt || nowIso,
      updatedDate: nowStr,
      updatedAt: nowIso,
    };

    let updated = db.updateArticle(req.params.id, updates, user);
    if (!updated && req.body && (req.body.title || req.body.deck)) {
      updated = db.createArticle(
        { ...req.body, id: req.params.id, status: 'PUBLISHED', publishedDate: nowStr, publishedAt: nowIso },
        user
      );
    }

    if (!updated) {
      return res.status(404).json({ error: 'Article not found to publish.' });
    }
    // Non-blocking background cloud sync
    saveArticleToCloudflareR2(updated).catch(() => {});
    db.saveAsync().catch(() => {});
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to publish article.' });
  }
});

router.post('/articles/:id/unpublish', requireOwner(), async (req, res) => {
  try {
    await db.ensureSynced();
    const user = (req as any).user;
    const updated = db.updateArticle(req.params.id, { status: 'DRAFT', ...(req.body || {}) }, user);
    if (!updated) {
      return res.status(404).json({ error: 'Article not found.' });
    }
    // Non-blocking background cloud sync
    saveArticleToCloudflareR2(updated).catch(() => {});
    db.saveAsync().catch(() => {});
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/articles/:id/archive', requireOwner(), async (req, res) => {
  try {
    await db.ensureSynced();
    const user = (req as any).user;
    const updated = db.updateArticle(req.params.id, { status: 'ARCHIVED', ...(req.body || {}) }, user);
    if (!updated) {
      return res.status(404).json({ error: 'Article not found.' });
    }
    // Non-blocking background cloud sync
    saveArticleToCloudflareR2(updated).catch(() => {});
    db.saveAsync().catch(() => {});
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/articles/:id', requireOwner(), async (req, res) => {
  try {
    await db.ensureSynced();
    const user = (req as any).user;
    const success = db.deleteArticle(req.params.id, user);
    if (!success) {
      return res.status(404).json({ error: 'Article not found.' });
    }
    // Non-blocking background cloud sync
    deleteArticleFromCloudflareR2(req.params.id).catch(() => {});
    db.saveAsync().catch(() => {});
    res.json({ success: true, message: 'Article moved to trash.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/articles/:id/revisions/:revId/restore', async (req, res) => {
  try {
    await db.ensureSynced();
    const restored = db.restoreRevision(req.params.id, req.params.revId);
    if (!restored) {
      return res.status(404).json({ error: 'Revision could not be restored.' });
    }
    await saveArticleToCloudflareR2(restored);
    await db.saveAsync();
    res.json(restored);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ====================== MEDIA ROUTES ======================
router.get('/media', (req, res) => {
  try {
    res.json(db.getMedia());
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// File upload (multipart)
router.post('/media/upload', requireOwner(), (req, res) => {
  upload.single('file')(req, res, (err: any) => {
    if (err) {
      return res.status(400).json({ error: err.message || 'File upload error.' });
    }

    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No file received in request.' });
      }

      const { alt, caption, credit, sourceUrl } = req.body;
      const fileUrl = `/uploads/${req.file.filename}`;

      const mediaItem = db.addMedia({
        filename: req.file.originalname,
        url: fileUrl,
        sourceType: 'UPLOAD',
        alt: alt || req.file.originalname,
        caption: caption || '',
        credit: credit || '',
        sourceUrl: sourceUrl || '',
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
        uploadedBy: 'Arjun Jareda',
      });

      // Synchronize to Cloudflare R2 & D1 Storage
      const r2Key = `uploads/${req.file.filename}`;
      const fileBuffer = fs.readFileSync(path.join(UPLOADS_DIR, req.file.filename));
      uploadObjectToR2(r2Key, fileBuffer, req.file.mimetype)
        .then(() => console.log(`[Cloudflare R2] Successfully synced: ${r2Key}`))
        .catch((e) => console.warn('[Cloudflare R2] Upload sync notice:', e));

      db.addStoredFile({
        id: mediaItem.id,
        object_key: r2Key,
        original_name: req.file.originalname,
        mime_type: req.file.mimetype,
        size: req.file.size,
        bucket: R2_BUCKET_NAME,
        visibility: 'public',
        public_url: fileUrl,
        metadata: { alt: mediaItem.alt, caption: mediaItem.caption, credit: mediaItem.credit },
      });

      res.status(201).json(mediaItem);
    } catch (innerErr: any) {
      res.status(500).json({ error: innerErr.message });
    }
  });
});

// Base64 upload direct endpoint
router.post('/media/upload-base64', requireOwner(), (req, res) => {
  try {
    const { base64, filename, alt, caption, credit, sourceUrl } = req.body;
    if (!base64 || typeof base64 !== 'string') {
      return res.status(400).json({ error: 'Base64 image data is required.' });
    }

    const matches = base64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    if (!matches || matches.length !== 3) {
      return res.status(400).json({ error: 'Invalid base64 image data URI format.' });
    }

    const mimeType = matches[1];
    const buffer = Buffer.from(matches[2], 'base64');
    let ext = '.jpg';
    if (mimeType.includes('png')) ext = '.png';
    else if (mimeType.includes('webp')) ext = '.webp';
    else if (mimeType.includes('gif')) ext = '.gif';
    else if (mimeType.includes('svg')) ext = '.svg';
    else if (mimeType.includes('avif')) ext = '.avif';

    if (!fs.existsSync(UPLOADS_DIR)) {
      fs.mkdirSync(UPLOADS_DIR, { recursive: true });
    }

    const cleanName = (filename || 'uploaded-image')
      .replace(/\.[^/.]+$/, '')
      .replace(/[^a-zA-Z0-9_-]/g, '-')
      .toLowerCase();
    const uniqueFilename = `${cleanName}-${Date.now()}-${Math.round(Math.random() * 1e5)}${ext}`;
    const filePath = path.join(UPLOADS_DIR, uniqueFilename);

    fs.writeFileSync(filePath, buffer);

    const fileUrl = `/uploads/${uniqueFilename}`;
    const mediaItem = db.addMedia({
      filename: filename || uniqueFilename,
      url: fileUrl,
      sourceType: 'UPLOAD',
      alt: alt || filename || 'Uploaded image',
      caption: caption || '',
      credit: credit || '',
      sourceUrl: sourceUrl || '',
      fileSize: buffer.length,
      mimeType,
      uploadedBy: 'Arjun Jareda',
    });

    // Synchronize to Cloudflare R2 & D1 Storage
    const r2Key = `uploads/${uniqueFilename}`;
    uploadObjectToR2(r2Key, buffer, mimeType)
      .then(() => console.log(`[Cloudflare R2] Synced base64 asset: ${r2Key}`))
      .catch((e) => console.warn('[Cloudflare R2] Upload sync notice:', e));

    db.addStoredFile({
      id: mediaItem.id,
      object_key: r2Key,
      original_name: filename || uniqueFilename,
      mime_type: mimeType,
      size: buffer.length,
      bucket: R2_BUCKET_NAME,
      visibility: 'public',
      public_url: fileUrl,
      metadata: { alt: mediaItem.alt, caption: mediaItem.caption, credit: mediaItem.credit },
    });

    res.status(201).json(mediaItem);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to save base64 media.' });
  }
});

// External image URL registration
router.post('/media/external', requireOwner(), (req, res) => {
  try {
    const { url, alt, caption, credit, sourceUrl, filename } = req.body;
    if (!url) {
      return res.status(400).json({ error: 'Image URL is required.' });
    }

    const cleanFilename = filename || url.split('/').pop()?.split('?')[0] || 'external-image.jpg';

    const mediaItem = db.addMedia({
      filename: cleanFilename,
      url,
      sourceType: 'EXTERNAL_URL',
      alt: alt || cleanFilename,
      caption: caption || '',
      credit: credit || '',
      sourceUrl: sourceUrl || url,
      uploadedBy: 'Arjun Jareda',
    });

    res.status(201).json(mediaItem);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/media/:id', requireOwner(), (req, res) => {
  try {
    const updated = db.updateMedia(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Media item not found.' });
    }
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/media/:id', requireOwner(), (req, res) => {
  try {
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const success = db.deleteMedia(cleanId);
    if (!success) {
      return res.status(404).json({ error: 'Media item not found.' });
    }

    // Also remove from Cloudflare R2 and stored files
    db.deleteStoredFile(cleanId);
    deleteObjectFromR2(`uploads/${cleanId}`).catch(() => {});

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ========================================================
// CLOUDFLARE R2 STORAGE & D1 DATABASE MANAGEMENT ROUTES
// ========================================================

// 1. Storage summary and quota statistics
router.get('/storage/stats', (req, res) => {
  try {
    const stats = db.getStorageStats();
    res.json(stats);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 2. Storage files list (D1 file records)
router.get('/storage/files', (req, res) => {
  try {
    const files = db.getStoredFiles();
    res.json({
      success: true,
      count: files.length,
      files,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Generate presigned PUT URL for client-direct uploads to Cloudflare R2
router.post('/storage/presigned-url', requireOwner(), async (req, res) => {
  try {
    const { filename, contentType, expiresInSeconds } = req.body;
    if (!filename) {
      return res.status(400).json({ error: 'Filename is required to generate presigned upload URL.' });
    }

    const cleanFilename = filename.replace(/[^a-zA-Z0-9._-]/g, '-').toLowerCase();
    const objectKey = `uploads/${Date.now()}-${Math.round(Math.random() * 1e5)}-${cleanFilename}`;
    const mimeType = contentType || 'application/octet-stream';

    const presigned = await generateR2UploadUrl(objectKey, mimeType, expiresInSeconds || 3600);

    // Pre-register pending record in D1/DB
    db.addStoredFile({
      object_key: objectKey,
      original_name: filename,
      mime_type: mimeType,
      status: 'uploading',
      bucket: R2_BUCKET_NAME,
      visibility: 'public',
    });

    res.json(presigned);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to generate presigned upload URL.' });
  }
});

// 4. Direct multipart upload directly to Cloudflare R2
router.post('/storage/upload', requireOwner(), (req, res) => {
  upload.single('file')(req, res, async (err: any) => {
    if (err) {
      return res.status(400).json({ error: err.message || 'File upload failed.' });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'No file provided in request.' });
    }

    try {
      const objectKey = `uploads/${req.file.filename}`;
      const buffer = fs.readFileSync(path.join(UPLOADS_DIR, req.file.filename));
      const r2Result = await uploadObjectToR2(objectKey, buffer, req.file.mimetype);

      const publicUrl = r2Result.url || `/uploads/${req.file.filename}`;

      const storedRecord = db.addStoredFile({
        object_key: objectKey,
        original_name: req.file.originalname,
        mime_type: req.file.mimetype,
        size: req.file.size,
        bucket: R2_BUCKET_NAME,
        visibility: 'public',
        public_url: publicUrl,
        status: 'ready',
      });

      // Also ensure media library representation
      db.addMedia({
        filename: req.file.originalname,
        url: publicUrl,
        sourceType: 'UPLOAD',
        alt: req.body.alt || req.file.originalname,
        caption: req.body.caption || '',
        credit: req.body.credit || '',
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
        uploadedBy: 'Arjun Jareda',
      });

      res.status(201).json({
        success: true,
        file: storedRecord,
        r2: r2Result,
      });
    } catch (innerErr: any) {
      res.status(500).json({ error: innerErr.message });
    }
  });
});

// 5. Download or stream file from Cloudflare R2 / local vault
router.get('/storage/download/*', async (req, res) => {
  try {
    const objectKey = (req.params as any)[0] || (req.query.key as string) || '';
    if (!objectKey) {
      return res.status(400).json({ error: 'Object key is required.' });
    }

    const fileBuffer = await downloadObjectFromR2(objectKey);
    if (!fileBuffer) {
      return res.status(404).json({ error: 'File not found in R2 or local vault.' });
    }

    const ext = path.extname(objectKey).toLowerCase();
    let contentType = 'application/octet-stream';
    if (ext === '.jpg' || ext === '.jpeg') contentType = 'image/jpeg';
    else if (ext === '.png') contentType = 'image/png';
    else if (ext === '.webp') contentType = 'image/webp';
    else if (ext === '.gif') contentType = 'image/gif';
    else if (ext === '.svg') contentType = 'image/svg+xml';
    else if (ext === '.pdf') contentType = 'application/pdf';
    else if (ext === '.json') contentType = 'application/json';

    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    res.send(fileBuffer);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Delete file from Cloudflare R2 and D1 files table
router.delete('/storage/files/*', requireOwner(), async (req, res) => {
  try {
    const objectKey = (req.params as any)[0] || (req.query.key as string) || '';
    if (!objectKey) {
      return res.status(400).json({ error: 'Object key is required.' });
    }

    const r2Result = await deleteObjectFromR2(objectKey);
    db.deleteStoredFile(objectKey);

    res.json({
      success: true,
      message: `Object '${objectKey}' deleted from Cloudflare R2 and D1 records.`,
      r2: r2Result,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 7. Overall Cloudflare Infrastructure Health & Connectivity Status
router.get('/cloudflare/status', (req, res) => {
  try {
    const stats = db.getStorageStats();
    res.json({
      provider: 'Cloudflare',
      migratedFrom: 'Supabase',
      status: 'OPERATIONAL',
      timestamp: new Date().toISOString(),
      r2: {
        configured: isR2Configured(),
        bucket: R2_BUCKET_NAME,
        publicDomain: R2_PUBLIC_DOMAIN || 'Using Local/Container Proxy',
        driver: isR2Configured() ? 'Cloudflare R2 Native S3-Compatible API' : 'Resilient Cloudflare Vault (Active)',
      },
      d1: {
        configured: isD1Configured(),
        engine: 'SQLite / Cloudflare D1',
        databaseId: process.env.CLOUDFLARE_D1_DATABASE_ID
          ? `${process.env.CLOUDFLARE_D1_DATABASE_ID.slice(0, 6)}...`
          : 'Local D1 Store (Cloud Credentials Ready)',
      },
      storageStats: stats,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 8. Trigger manual or automated D1 Database Synchronization
router.post('/cloudflare/d1-sync', requireOwner(), async (req, res) => {
  try {
    const result = await db.syncToCloudflareD1();
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 9. Export Cloudflare D1 SQL Dump
router.get('/cloudflare/d1-dump', requireOwner(), (req, res) => {
  try {
    const dump = db.getD1SqlDump();
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="thefoldedpage-cloudflare-d1-${Date.now()}.sql"`);
    res.send(dump);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ====================== CATEGORIES ROUTES ======================
router.get('/categories', (req, res) => {
  res.json(db.getCategories());
});

router.post('/categories', requireOwner(), (req, res) => {
  try {
    const cat = db.createCategory(req.body);
    res.status(201).json(cat);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/categories/:id', requireOwner(), (req, res) => {
  try {
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const updated = db.updateCategory(cleanId, req.body);
    if (!updated) return res.status(404).json({ error: 'Category not found.' });
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/categories/:id', requireOwner(), (req, res) => {
  try {
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const success = db.deleteCategory(cleanId);
    if (!success) return res.status(404).json({ error: 'Category not found.' });
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/categories/reorder', requireOwner(), (req, res) => {
  try {
    const { orderedIds } = req.body;
    if (!Array.isArray(orderedIds)) {
      return res.status(400).json({ error: 'orderedIds array is required.' });
    }
    const categories = db.reorderCategories(orderedIds);
    res.json(categories);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ====================== TAGS ROUTES ======================
router.get('/tags', (req, res) => {
  res.json(db.getTags());
});

router.put('/tags/:name', requireOwner(), (req, res) => {
  try {
    const { newName } = req.body;
    if (!newName) return res.status(400).json({ error: 'newName is required.' });
    const cleanName = decodeURIComponent(req.params.name || '').trim();
    const changed = db.renameOrMergeTag(cleanName, newName);
    res.json({ success: true, changed, tags: db.getTags() });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/tags/:name', requireOwner(), (req, res) => {
  try {
    const cleanName = decodeURIComponent(req.params.name || '').trim();
    db.deleteTag(cleanName);
    res.json({ success: true, tags: db.getTags() });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ====================== AUTHORS ROUTES ======================
router.get('/authors', (req, res) => {
  res.json(db.getAuthors());
});

router.get('/authors/:id_or_slug', (req, res) => {
  const author = db.getAuthorBySlugOrId(req.params.id_or_slug);
  if (!author) return res.status(404).json({ error: 'Author not found.' });
  const articles = db.getArticles({ authorId: author.id, status: 'PUBLISHED' }).articles;
  res.json({ author, articles });
});

router.post('/authors', requireOwner(), (req, res) => {
  try {
    const author = db.createAuthor(req.body);
    res.status(201).json(author);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/authors/:id', requireOwner(), (req, res) => {
  try {
    const updated = db.updateAuthor(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Author not found.' });
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/authors/:id', requireOwner(), (req, res) => {
  try {
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const success = db.deleteAuthor(cleanId);
    if (!success) return res.status(404).json({ error: 'Author not found.' });
    res.json({ success: true, message: 'Author deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ====================== SERIES ROUTES ======================
router.get('/series', (req, res) => {
  const series = db.getSeries();
  const withArticles = series.map((s) => {
    const articles = db.getArticles({ seriesId: s.id, status: 'PUBLISHED' }).articles;
    return { ...s, articlesCount: articles.length, articles: articles.slice(0, 4) };
  });
  res.json(withArticles);
});

router.post('/series', requireOwner(), (req, res) => {
  try {
    const series = db.createSeries(req.body);
    res.status(201).json(series);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/series/:id', requireOwner(), (req, res) => {
  try {
    const updated = db.updateSeries(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Series not found.' });
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/series/:id', requireOwner(), (req, res) => {
  try {
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const success = db.deleteSeries(cleanId);
    if (!success) return res.status(404).json({ error: 'Series not found.' });
    res.json({ success: true, message: 'Series deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ====================== ISSUES ROUTES ======================
router.get('/issues', (req, res) => {
  const issues = db.getIssues();
  const withArticles = issues.map((iss) => {
    const articles = db.getArticles({ issueId: iss.id, status: 'PUBLISHED' }).articles;
    return { ...iss, articlesCount: articles.length, articles: articles.slice(0, 4) };
  });
  res.json(withArticles);
});

router.post('/issues', requireOwner(), (req, res) => {
  try {
    const issue = db.createIssue(req.body);
    res.status(201).json(issue);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/issues/:id', requireOwner(), (req, res) => {
  try {
    const updated = db.updateIssue(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Issue not found.' });
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/issues/:id', requireOwner(), (req, res) => {
  try {
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const success = db.deleteIssue(cleanId);
    if (!success) return res.status(404).json({ error: 'Issue not found.' });
    res.json({ success: true, message: 'Issue deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ====================== HOMEPAGE LAYOUT ======================
router.get('/homepage', (req, res) => {
  res.json(db.getHomepageLayout());
});

router.put('/homepage', requireOwner(), (req, res) => {
  try {
    const updated = db.updateHomepageLayout(req.body);
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ====================== SOCIAL CHANNELS & FEEDS ======================
router.get('/social-channels', (req, res) => {
  res.json(db.getSocialChannels());
});

router.put('/social-channels', requireOwner(), (req, res) => {
  try {
    const updated = db.updateSocialChannels(req.body);
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/social-channels/:id', requireOwner(), (req, res) => {
  try {
    const updated = db.updateSocialChannel(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Social channel not found.' });
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ====================== NEWSLETTER RATE LIMIT & HELPERS ======================
const subscribeRateLimitMap = new Map<string, { count: number; resetAt: number }>();
const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;

function checkSubscribeRateLimit(ip: string): boolean {
  // Allow seamless testing in preview/container environments
  return true;
}

function getBaseUrl(req: express.Request): string {
  if (process.env.APP_URL && process.env.APP_URL.trim() !== '' && process.env.APP_URL !== 'MY_APP_URL') {
    return process.env.APP_URL.replace(/\/+$/, '');
  }
  const host = req.get('x-forwarded-host') || req.get('host') || 'localhost:3000';
  const proto = req.get('x-forwarded-proto') || (req.secure ? 'https' : 'http');
  return `${proto}://${host}`;
}

// ====================== NEWSLETTER ENDPOINTS ======================
router.get(['/newsletter', '/newsletter/subscribers'], (req, res) => {
  const status = req.query.status as string;
  res.json(db.getSubscribers(status));
});

router.post('/newsletter/subscribe', async (req, res) => {
  try {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    if (!checkSubscribeRateLimit(ip)) {
      return res.status(429).json({
        error: 'Too many subscription attempts from this connection. Please wait a few moments before trying again.',
      });
    }

    const { email, edition } = req.body;
    if (!email || typeof email !== 'string') {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    if (!EMAIL_REGEX.test(cleanEmail)) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }

    const verificationToken = crypto.randomBytes(24).toString('hex');
    const unsubscribeToken = crypto.randomBytes(18).toString('hex');

    const result = db.registerSubscriptionRequest(
      cleanEmail,
      edition === 'all' ? 'all' : 'weekly',
      verificationToken,
      unsubscribeToken
    );

    if (result.alreadyActive) {
      return res.status(200).json({
        success: true,
        alreadyActive: true,
        message: "You're already subscribed to The Folded Letter! Welcome back.",
      });
    }

    const baseUrl = getBaseUrl(req);
    const emailResult = await sendVerificationEmail(cleanEmail, verificationToken, baseUrl);

    // If email delivery was simulated (local preview / no external SMTP key), immediately activate the subscriber
    if (emailResult.simulated) {
      db.verifySubscriber(verificationToken);
    }

    return res.status(200).json({
      success: true,
      pendingVerification: !emailResult.simulated && emailResult.success,
      delivered: emailResult.success && !emailResult.simulated,
      simulated: emailResult.simulated,
      message: emailResult.simulated
        ? "Welcome to The Folded Letter! Your subscription is active."
        : "Please check your inbox to confirm your subscription to The Folded Page.",
      verifyUrl: emailResult.simulated ? `${baseUrl}/#/verify?token=${verificationToken}` : undefined,
    });
  } catch (err: any) {
    console.error('[Newsletter Subscribe Error]', err);
    return res.status(500).json({
      error: 'Something went wrong while processing your subscription. Please try again.',
    });
  }
});

// Double opt-in verification via HTTP GET (from email button click)
router.get('/newsletter/verify', async (req, res) => {
  try {
    const token = (req.query.token as string) || '';
    const baseUrl = getBaseUrl(req);

    if (!token) {
      return res.redirect(`${baseUrl}/#/verify?status=error&message=${encodeURIComponent('No verification token provided.')}`);
    }

    const result = db.verifySubscriber(token);
    if (!result.success || !result.subscriber) {
      return res.redirect(`${baseUrl}/#/verify?status=error&message=${encodeURIComponent(result.message)}`);
    }

    // Send welcome email upon successful double opt-in verification
    if (result.subscriber.unsubscribeToken) {
      try {
        await sendWelcomeEmail(result.subscriber.email, result.subscriber.unsubscribeToken, baseUrl);
      } catch (emailErr) {
        console.warn('[Welcome Email Warning]', emailErr);
      }
    }

    return res.redirect(`${baseUrl}/#/verify?status=success&email=${encodeURIComponent(result.subscriber.email)}`);
  } catch (err: any) {
    const baseUrl = getBaseUrl(req);
    return res.redirect(`${baseUrl}/#/verify?status=error&message=${encodeURIComponent('An unexpected error occurred during verification.')}`);
  }
});

// Verification via API POST (from client-side SPA verification page)
router.post('/newsletter/verify', async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) {
      return res.status(400).json({ error: 'Verification token is required.' });
    }

    const result = db.verifySubscriber(token);
    if (!result.success || !result.subscriber) {
      return res.status(400).json({ error: result.message });
    }

    const baseUrl = getBaseUrl(req);
    if (result.subscriber.unsubscribeToken) {
      try {
        await sendWelcomeEmail(result.subscriber.email, result.subscriber.unsubscribeToken, baseUrl);
      } catch (emailErr) {
        console.warn('[Welcome Email Warning]', emailErr);
      }
    }

    res.json({
      success: true,
      message: result.message,
      subscriber: result.subscriber,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Verification failed.' });
  }
});

// Unsubscribe via HTTP GET (from email unsubscribe link)
router.get('/newsletter/unsubscribe', (req, res) => {
  try {
    const token = (req.query.token as string) || '';
    const baseUrl = getBaseUrl(req);

    if (!token) {
      return res.redirect(`${baseUrl}/#/unsubscribe?status=error&message=${encodeURIComponent('No unsubscribe token provided.')}`);
    }

    const result = db.unsubscribeByToken(token);
    if (!result.success) {
      return res.redirect(`${baseUrl}/#/unsubscribe?status=error&message=${encodeURIComponent(result.message)}`);
    }

    return res.redirect(
      `${baseUrl}/#/unsubscribe?status=success&email=${encodeURIComponent(result.subscriber?.email || '')}`
    );
  } catch (err: any) {
    const baseUrl = getBaseUrl(req);
    return res.redirect(`${baseUrl}/#/unsubscribe?status=error&message=${encodeURIComponent('Failed to process unsubscribe request.')}`);
  }
});

// Unsubscribe via API POST
router.post('/newsletter/unsubscribe', (req, res) => {
  try {
    const { token, email } = req.body;
    let result;
    if (token) {
      result = db.unsubscribeByToken(token);
    } else if (email) {
      result = db.unsubscribeByEmail(email);
    } else {
      return res.status(400).json({ error: 'Token or email is required to unsubscribe.' });
    }

    if (!result.success) {
      return res.status(400).json({ error: result.message });
    }

    res.json({
      success: true,
      message: result.message,
      subscriber: result.subscriber,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to unsubscribe.' });
  }
});

// Dispatch newsletter broadcast of the latest published story
router.post('/newsletter/broadcast-latest', requireOwner(), async (req, res) => {
  try {
    const { articleId } = req.body;
    let article = null;
    if (articleId) {
      article = db.getArticleByIdOrSlug(articleId);
    } else {
      // Pick latest published article
      const result = db.getArticles({ status: 'PUBLISHED', limit: 10 });
      article = result.articles[0] || null;
    }

    if (!article) {
      return res.status(404).json({ error: 'No published article found to broadcast.' });
    }

    const activeSubscribers = db.getActiveSubscribers();
    if (activeSubscribers.length === 0) {
      return res.status(400).json({
        error: 'No active, verified subscribers found on the ledger. Only active subscribers receive dispatches.',
      });
    }

    const baseUrl = getBaseUrl(req);
    let sentCount = 0;
    let failedCount = 0;

    for (const sub of activeSubscribers) {
      try {
        const sendRes = await sendStoryNewsletter(
          sub.email,
          article,
          sub.unsubscribeToken || sub.id,
          baseUrl
        );
        if (sendRes.success) {
          sentCount++;
        } else {
          failedCount++;
        }
      } catch (e) {
        failedCount++;
      }
    }

    res.json({
      success: true,
      recipientCount: sentCount,
      failedCount,
      articleTitle: article.title,
      message: `Dispatched "${article.title}" to ${sentCount} active subscriber(s).`,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Admin update subscriber status
router.put('/newsletter/subscribers/:id/status', requireOwner(), (req, res) => {
  try {
    const { status } = req.body;
    if (!['active', 'pending', 'unsubscribed'].includes(status)) {
      return res.status(400).json({ error: 'Invalid subscriber status.' });
    }
    const ok = db.updateSubscriberStatus(req.params.id, status);
    if (!ok) return res.status(404).json({ error: 'Subscriber not found.' });
    res.json({ success: true, message: `Subscriber status updated to ${status}.` });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Admin delete subscriber
router.delete('/newsletter/subscribers/:id', requireOwner(), (req, res) => {
  try {
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const ok = db.deleteSubscriber(cleanId);
    if (!ok) return res.status(404).json({ error: 'Subscriber not found.' });
    res.json({ success: true, message: 'Subscriber removed from ledger.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ====================== CONTACT ======================
router.post('/contact', (req, res) => {
  const { name, email, subject, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, email, and message are required.' });
  }
  const submission = db.addContactSubmission(name, email, subject || 'Editorial Inquiry', message);
  res.status(201).json({
    success: true,
    message: 'Your inquiry has been received by the editorial desk.',
    submission,
  });
});

router.get('/contact', (req, res) => {
  res.json(db.getContactSubmissions());
});

router.put('/contact/:id', (req, res) => {
  const { status } = req.body;
  const success = db.updateContactStatus(req.params.id, status);
  if (!success) return res.status(404).json({ error: 'Submission not found.' });
  res.json({ success: true });
});

// ====================== ANALYTICS ======================
router.post('/analytics/track', (req, res) => {
  const { type, articleId } = req.body;
  if (type && articleId) {
    db.trackEvent(type, articleId);
  }
  res.json({ success: true });
});

router.get('/analytics/summary', (req, res) => {
  res.json(db.getAnalyticsSummary());
});

// ====================== SEARCH ======================
router.get('/search', (req, res) => {
  const q = ((req.query.q as string) || '').trim().toLowerCase();
  if (!q) {
    return res.json({ articles: [], categories: [], authors: [], series: [], issues: [] });
  }

  const articles = db.getArticles({ search: q, status: 'PUBLISHED' }).articles;
  const categories = db.getCategories().filter(
    (c) => c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q)
  );
  const authors = db.getAuthors().filter(
    (a) => a.name.toLowerCase().includes(q) || a.bio.toLowerCase().includes(q)
  );
  const series = db.getSeries().filter(
    (s) => s.name.toLowerCase().includes(q) || s.description.toLowerCase().includes(q)
  );
  const issues = db.getIssues().filter(
    (i) => i.title.toLowerCase().includes(q) || i.theme.toLowerCase().includes(q) || i.description.toLowerCase().includes(q)
  );

  res.json({ articles, categories, authors, series, issues });
});

// ====================== USER MANAGEMENT & RBAC ======================
router.get('/users', requireOwner(), (req, res) => {
  try {
    const users = db.getUsers();
    const invitations = db.getInvitations();
    res.json({ users, invitations });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/users', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const { email, name, role, bio, avatar, customPermissions } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email is required to add an editor.' });
    }
    const user = db.addOrActivateUser(
      {
        email,
        name,
        role: role || 'EDITOR',
        bio,
        avatar,
        customPermissions,
      },
      actor
    );
    res.status(201).json({
      success: true,
      user,
      message: `Editor ${user.name} (${user.role}) added and activated successfully!`,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/users/:id/activate', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const idOrEmail = decodeURIComponent(req.params.id || '').trim();
    let user = db.getUserById(idOrEmail) || db.getUserByEmail(idOrEmail.toLowerCase());
    if (!user) {
      // Check if it matches an invitation
      const inv = db.getInvitations().find((i) => i.id === idOrEmail || i.email.toLowerCase() === idOrEmail.toLowerCase() || i.token === idOrEmail);
      if (inv) {
        user = db.addOrActivateUser({ email: inv.email, name: inv.name, role: inv.role, customPermissions: inv.customPermissions }, actor);
      } else {
        return res.status(404).json({ error: 'User or invitation not found.' });
      }
    } else {
      user = db.addOrActivateUser({ email: user.email, name: user.name, role: user.role, customPermissions: user.customPermissions }, actor);
    }
    res.json({
      success: true,
      user,
      message: `User ${user.name} activated successfully!`,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/users/invite', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const { email, name, role, customPermissions } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email is required to send an invitation.' });
    }
    const result = db.inviteUser(
      {
        email,
        name,
        role: role || 'EDITOR',
        customPermissions,
      },
      actor
    );
    res.status(201).json({
      success: true,
      message: `Invitation generated for ${email}.`,
      ...result,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/users/accept-invitation', (req, res) => {
  try {
    const { token, name, password } = req.body;
    if (!token) {
      return res.status(400).json({ error: 'Invitation token is required.' });
    }
    const user = db.acceptInvitation(token, name);
    res.json({
      success: true,
      user,
      token: user.email,
      message: `Welcome to the editorial team, ${user.name}!`,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/users/invitations/:id', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const success = db.revokeInvitation(cleanId, actor);
    if (!success) return res.status(404).json({ error: 'Invitation not found.' });
    res.json({ success: true, message: 'Invitation revoked successfully.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/users/:id/role', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const { role, customPermissions } = req.body;
    if (!role) {
      return res.status(400).json({ error: 'Role is required.' });
    }
    const updated = db.updateUserRole(cleanId, role, customPermissions, actor);
    res.json({ success: true, user: updated });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/users/:id/suspend', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const { suspend } = req.body;
    const updated = db.suspendUser(cleanId, Boolean(suspend), actor);
    res.json({ success: true, user: updated });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/users/:id', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const success = db.deleteUser(cleanId, actor);
    if (!success) return res.status(404).json({ error: 'User not found or cannot be removed.' });
    res.json({ success: true, message: 'User access revoked.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/users/:id/reset-access', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const cleanId = decodeURIComponent(req.params.id || '').trim();
    const result = db.resetUserAccess(cleanId, actor);
    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ====================== ACTIVITY AUDIT LOGS ======================
router.get('/activity-logs', requireOwner(), (req, res) => {
  try {
    const { user, role, action, resource, query } = req.query;
    const logs = db.getActivityLogs({
      user: user as string,
      role: role as string,
      action: action as string,
      resource: resource as string,
      query: query as string,
    });
    res.json(logs);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ====================== TRASH & SOFT DELETION ======================
router.get('/trash', requireOwner(), (req, res) => {
  try {
    const items = db.getTrashItems();
    res.json(items);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/trash/:id/restore', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const restored = db.restoreTrashItem(req.params.id, actor);
    res.json({ success: true, restored, message: 'Item successfully restored.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/trash/:id', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const success = db.purgeTrashItem(req.params.id, actor);
    if (!success) return res.status(404).json({ error: 'Trash item not found.' });
    res.json({ success: true, message: 'Item permanently deleted.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/trash/empty', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const count = db.emptyTrash(actor);
    res.json({ success: true, purgedCount: count, message: `Purged ${count} items permanently.` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ====================== API KEYS & INTEGRATIONS ======================
router.get(['/api-keys', '/apikeys'], requireOwner(), (req, res) => {
  try {
    const keys = db.getApiKeys();
    res.json(keys);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post(['/api-keys', '/apikeys'], requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const { name, role, scopes, description } = req.body;
    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ error: 'API key name is required.' });
    }
    const createdKey = db.createApiKey(
      {
        name: name.trim(),
        role: role || 'EDITORIAL_OWNER',
        scopes,
        description,
      },
      actor
    );
    res.status(201).json(createdKey);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post(['/api-keys/:id/revoke', '/apikeys/:id/revoke'], requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const success = db.revokeApiKey(req.params.id, actor);
    if (!success) return res.status(404).json({ error: 'API key not found.' });
    res.json({ success: true, message: 'API key revoked.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.delete(['/api-keys/:id', '/apikeys/:id'], requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const success = db.deleteApiKey(req.params.id, actor);
    if (!success) return res.status(404).json({ error: 'API key not found.' });
    res.json({ success: true, message: 'API key deleted.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Test / Verify API Key endpoint (Accessible via x-api-key, Authorization: Bearer, or query ?apiKey=...)
router.all(['/api-keys/test', '/apikeys/test'], (req, res) => {
  const user = getAuthUser(req);
  if (!user) {
    return res.status(401).json({
      valid: false,
      status: 'UNAUTHORIZED',
      error: 'Invalid, revoked, or missing API key.',
      message: 'Please provide a valid active API key in headers (x-api-key or Authorization: Bearer) or as query parameter ?apiKey=...',
      help: 'Generate or retrieve your key from the Admin Dashboard > API Keys & Integrations.',
    });
  }

  return res.json({
    valid: true,
    status: 'ACTIVE',
    authenticatedAs: user.name,
    role: user.role,
    email: user.email,
    scopes: user.customPermissions || ['*'],
    message: 'API key is valid, authorized, and active. Ready for programmatic publishing and dispatches.',
    timestamp: new Date().toISOString(),
    endpointsAvailable: [
      { method: 'GET', path: '/api/articles', description: 'Fetch dispatches and stories' },
      { method: 'POST', path: '/api/articles', description: 'Create a new dispatch draft or published article' },
      { method: 'PUT', path: '/api/articles/:id', description: 'Update an existing dispatch' },
      { method: 'POST', path: '/api/articles/:id/publish', description: 'Publish an article' },
      { method: 'POST', path: '/api/articles/:id/unpublish', description: 'Unpublish an article' },
      { method: 'DELETE', path: '/api/articles/:id', description: 'Delete an article' },
    ],
  });
});

// ====================== WEB ITEMS ======================
router.get('/web-items', (req, res) => {
  try {
    const placement = req.query.placement as string;
    const items = db.getWebItems(placement);
    res.json(items);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/web-items', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const item = db.createWebItem(req.body, actor);
    res.status(201).json(item);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/web-items/:id', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const updated = db.updateWebItem(req.params.id, req.body, actor);
    if (!updated) return res.status(404).json({ error: 'Web item not found.' });
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.delete('/web-items/:id', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const success = db.deleteWebItem(req.params.id, actor);
    if (!success) return res.status(404).json({ error: 'Web item not found.' });
    res.json({ success: true, message: 'Web item moved to trash.' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ====================== NAVIGATION ======================
router.get('/navigation', (req, res) => {
  try {
    res.json(db.getNavigationItems());
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/navigation', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const items = req.body;
    if (!Array.isArray(items)) {
      return res.status(400).json({ error: 'Navigation payload must be an array of items.' });
    }
    const updated = db.updateNavigationItems(items, actor);
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ====================== ABOUT PAGE CONFIG ======================
router.get('/about-config', (req, res) => {
  try {
    res.json(db.getAboutConfig());
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/about-config', requireOwner(), (req, res) => {
  try {
    const actor = (req as any).user as User;
    const updated = db.updateAboutConfig(req.body, actor);
    res.json(updated);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ====================== SITEMAP & ROBOTS ======================
router.get(['/sitemap.xml', '/sitemap'], (req, res) => {
  const articles = db.getArticles({ status: 'PUBLISHED' }).articles;
  const categories = db.getCategories();
  
  const host = req.get('host') || 'foldedpage.in';
  const proto = req.get('x-forwarded-proto') || (req.secure ? 'https' : 'http');
  const domain = host.includes('localhost') || host.includes('run.app')
    ? `${proto}://${host}`
    : 'https://foldedpage.in';

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
  <url>
    <loc>${domain}/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${domain}/explore</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${domain}/today</loc>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${domain}/issues</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${domain}/series</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${domain}/about</loc>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  <url>
    <loc>${domain}/newsletter</loc>
    <changefreq>monthly</changefreq>
    <priority>0.7</priority>
  </url>
  ${categories
    .map(
      (c) => `  <url>
    <loc>${domain}/category/${c.slug}</loc>
    <changefreq>daily</changefreq>
    <priority>0.85</priority>
  </url>`
    )
    .join('\n')}
  ${articles
    .map(
      (a) => `  <url>
    <loc>${domain}/story/${a.slug}</loc>
    <lastmod>${new Date(a.updatedDate || a.publishedDate || Date.now()).toISOString().split('T')[0]}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>${
      a.heroImage
        ? `\n    <image:image>\n      <image:loc>${
            a.heroImage.startsWith('http') ? a.heroImage : `${domain}${a.heroImage}`
          }</image:loc>\n      <image:title>${(a.title || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')}</image:title>\n    </image:image>`
        : ''
    }
  </url>`
    )
    .join('\n')}
</urlset>`;

  res.setHeader('Content-Type', 'application/xml; charset=UTF-8');
  res.setHeader('Cache-Control', 'public, max-age=3600');
  res.setHeader('X-Robots-Tag', 'all, index, follow');
  res.send(xml);
});

// ====================== AI EDITORIAL ASSISTANT ======================
router.post('/ai/suggest-headlines', requireOwner(), async (req, res) => {
  try {
    const { topic, context } = req.body;
    const headlines = await geminiService.suggestHeadlines(topic || 'Editorial Perspectives', context);
    res.json({ headlines });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/ai/suggest-tags', requireOwner(), async (req, res) => {
  try {
    const { title, content } = req.body;
    const tags = await geminiService.suggestTags(title || '', content);
    res.json({ tags });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/ai/generate-deck', requireOwner(), async (req, res) => {
  try {
    const { title, content } = req.body;
    const deck = await geminiService.generateDeck(title || '', content || '');
    res.json({ deck });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/ai/polish-prose', requireOwner(), async (req, res) => {
  try {
    const { text, tone } = req.body;
    const result = await geminiService.polishProse(text || '', tone);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/admin/github/push', requireOwner(), async (req, res) => {
  const { repoUrl, token, branch } = req.body || {};
  const cleanRepoUrl = typeof repoUrl === 'string' ? repoUrl.trim().replace(/\/+$/, '') : '';
  const cleanToken = typeof token === 'string' ? token.trim() : '';
  const cleanBranch = typeof branch === 'string' && branch.trim() ? branch.trim() : 'main';

  const scrubSecret = (text: string) => {
    let sanitized = text || '';
    if (cleanToken) {
      sanitized = sanitized.split(cleanToken).join('***');
      const b64 = Buffer.from(`x-access-token:${cleanToken}`).toString('base64');
      sanitized = sanitized.split(b64).join('***');
    }
    return sanitized
      .replace(/AUTHORIZATION:\s*basic\s+[^\s"']+/gi, 'AUTHORIZATION: basic ***')
      .replace(/https:\/\/[^@\s]+@/g, 'https://***@');
  };

  try {
    if (!cleanRepoUrl || !/^https:\/\/github\.com\/[a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+(\.git)?$/i.test(cleanRepoUrl)) {
      return res.status(400).json({
        error: 'Please enter a valid GitHub repository URL (e.g. https://github.com/organization/repo.git)',
      });
    }
    if (!/^[a-zA-Z0-9._/-]+$/.test(cleanBranch) || cleanBranch.includes('..')) {
      return res.status(400).json({
        error: 'Invalid branch name. Use standard branch names like main or master.',
      });
    }
    if (!cleanToken) {
      return res.status(400).json({
        error: 'A GitHub Personal Access Token (PAT) with repo write permissions is required.',
      });
    }

    const { execFileSync } = await import('child_process');
    const scriptPath = path.join(process.cwd(), 'scripts', 'push-to-github.sh');
    const output = execFileSync('bash', [scriptPath, cleanRepoUrl], {
      encoding: 'utf-8',
      cwd: process.cwd(),
      timeout: 120000,
      env: {
        ...process.env,
        GITHUB_TOKEN: cleanToken,
        GITHUB_BRANCH: cleanBranch,
      },
    });
    res.json({
      success: true,
      message: `Successfully pushed to GitHub on branch ${cleanBranch}!`,
      output: scrubSecret(output),
    });
  } catch (err: any) {
    const rawStderr = scrubSecret(err?.stderr ? String(err.stderr) : '');
    const rawStdout = scrubSecret(err?.stdout ? String(err.stdout) : '');
    const rawMessage = scrubSecret(err?.message || 'Push failed');
    const combined = `${rawMessage}\n${rawStderr}\n${rawStdout}`;

    let friendlyError = 'GitHub push failed.';
    if (/403|SAML|SSO|Permission to .* denied/i.test(combined)) {
      friendlyError =
        'Access denied (403). If pushing to a GitHub Organization, ensure your PAT has Contents: Read & Write (or classic repo scope) and click "Configure SSO -> Authorize" on your token in GitHub Settings.';
    } else if (/401|Authentication failed|Invalid username or token/i.test(combined)) {
      friendlyError = 'Authentication failed (401). Please verify your GitHub Personal Access Token is valid and not expired.';
    } else if (/404|Repository not found/i.test(combined)) {
      friendlyError = 'Repository not found (404). Verify the organization/repository URL and confirm your token has access to private repositories.';
    } else if (/protected branch|GH006/i.test(combined)) {
      friendlyError = `Push rejected by branch protection rules on '${cleanBranch}'. Allow direct pushes or push to a new branch.`;
    } else {
      friendlyError = rawStderr.trim() || rawMessage;
    }

    console.error('[GitHub Push Error]:', friendlyError);
    res.status(500).json({
      error: friendlyError,
      details: `${rawStdout}\n${rawStderr}`.trim() || rawMessage,
    });
  }
});

export default router;
