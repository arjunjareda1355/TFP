/**
 * The Folded Page - Universal Server Entrypoint
 * Handles both local development (Vite middlewares) and production Cloud Run deployments.
 */
import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

// Load container environment configuration if present
const devEnvPath = '/app/.dev.env.json';
if (fs.existsSync(devEnvPath)) {
  try {
    const raw = fs.readFileSync(devEnvPath, 'utf-8');
    const parsed = JSON.parse(raw);
    for (const [k, v] of Object.entries(parsed)) {
      if (!process.env[k] && typeof v === 'string') {
        process.env[k] = v;
      }
    }
  } catch (envErr) {
    console.warn('[The Folded Page] Notice: skipping /app/.dev.env.json read:', envErr);
  }
}

// Catch unhandled errors globally
process.on('uncaughtException', (err) => {
  console.error('[The Folded Page] Uncaught exception:', err);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('[The Folded Page] Unhandled rejection at:', promise, 'reason:', reason);
});

const distDir = path.join(process.cwd(), 'dist');
const distServer = path.join(distDir, 'server.cjs');
const distHtml = path.join(distDir, 'index.html');

// In production / Cloud Run environments (not VITE_DEV_MODE)
if (!process.env.VITE_DEV_MODE) {
  // Ensure production bundles exist (handles environments where build step didn't run before npm start)
  if (!fs.existsSync(distServer) || !fs.existsSync(distHtml)) {
    console.log('[The Folded Page] Building production artifacts for Cloud Run...');
    try {
      execSync('npm run build', { stdio: 'inherit', env: process.env });
    } catch (buildErr) {
      console.warn('[The Folded Page] npm run build failed, attempting fallback server bundle with esbuild:', buildErr);
      if (!fs.existsSync(distDir)) {
        fs.mkdirSync(distDir, { recursive: true });
      }
      execSync('npx esbuild server/serverApp.ts --bundle --platform=node --format=cjs --packages=external --outfile=dist/server.cjs', { stdio: 'inherit', env: process.env });
    }
  }

  try {
    const mod = await import(distServer);
    const start = mod.startServer || mod.default?.startServer || mod.default;
    if (typeof start === 'function') {
      await start();
    }
  } catch (err: unknown) {
    console.error('[The Folded Page] Fatal error launching production server:', err);
    process.exit(1);
  }
} else {
  // In development: run through TS / Vite middlewares
  const { startServer } = await import('./server/serverApp.ts');
  await startServer();
}
